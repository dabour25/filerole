@extends('layouts.admin', ['title' =>__('strings.allows')])

@section('content')

    <!--<div class="page-title">-->
    <!--    <h3>@lang('strings.allows')</h3>-->
    <!--    <div class="page-breadcrumb">-->
    <!--        <ol class="breadcrumb">-->
    <!--            <li><a href="{{ route('home') }}">@lang('strings.Home')</a></li>-->
    <!--            <li><a href="{{url('admin/employee_pay_types')}}">@lang('strings.Search')</a></li>-->
    <!--            <li class="active">@lang('strings.allows')</li>-->
    <!--        </ol>-->
    <!--    </div>-->
    <!--</div>-->

    <div id="main-wrapper">
        <div class="row">
            <div class="col-md-12">

                <div class="panel panel-white">
                    @if (Session::has('message'))
                        <div class="alert alert-info">{{ Session::get('message') }}</div>
                    @endif


                        <form method="post" action="{{ url('admin/save_emp_type') }}" role="form"
                              enctype="multipart/form-data" id="search_form_add">
                            {{csrf_field()}}
                            <div class="col-md-6 form-group" id="code">

                                <label>@lang('strings.Date')</label>



								@if($mydate)
                                <input type="date" class="form-control datepicker" id="val_date"  value="{{$mydate}}" name="val_date">
                                 @else
                                <input type="date" class="form-control datepicker" id="val_date"  value="{{app('request')->input('val_date') }}" name="val_date">
                                @endif
                            </div>


                            <div class="col-md-6 form-group{{$errors->has('search_name') ? ' has-error' : ''}}"><strong
                                        class="text-danger">*</strong>
                                <label class="control-label" for="users">@lang('strings.Employee')</label>

                                <select class="form-control js-select" name="search_name" id="search_name">
                                    <option value="0">@lang('strings.Select_employee')</option>

                                    @php

                                        $users=App\User::where([ 'org_id' => Auth::user()->org_id, 'is_active'=>1,'type' => 1])->select('name','id','name_en')->get();

                                    @endphp


                                    @foreach($users as $user)
									@if($user_name)

							<option {{ $user_name == $user->id ? 'selected' : ''}}  value="{{$user->id}}">{{ app()->getLocale() == 'ar' ? $user->name  : $user->name_en  }}</option>
                                   @else
                      <option {{ app('request')->input('search_name') == $user->id ? 'selected' : ''}}  value="{{$user->id}}">{{ app()->getLocale() == 'ar' ? $user->name  : $user->name_en  }}</option>
                                 @endif
									@endforeach
                                </select>

                                @if ($errors->has('search_name'))
                                    <span class="help-block">
                                        <strong class="text-danger">{{ $errors->first('type') }}</strong>
                                    </span>
                                @endif
                            </div>
                             <div id="input_details" style="display:none">
                            <div class="col-md-6 form-group{{$errors->has('emp_val') ? ' has-error' : ''}}" id="code">
                                <label class="control-label" for="emp_val">@lang('strings.Value')</label>
                                <input type="text" id="emp_val" class="form-control" name="emp_val" value="{{old('emp_val') }}">
                                @if ($errors->has('emp_val'))
                                    <span class="help-block">
                                        <strong class="text-danger">{{ $errors->first('emp_val') }}</strong>
                                    </span>
                                @endif
                            </div>


                            <div class="col-md-6 form-group{{$errors->has('amount_type') ? ' has-error' : ''}}"><strong
                                        class="text-danger">*</strong>
                                <label class="control-label" for="amount_type">@lang('strings.allow_dedcted')</label>
                                <select class="form-control" name="amount_type" id="amount_type">
                                    @php
                                        $amounts=App\Pay_types::where(['org_id' => Auth::user()->org_id,'active'=>1])->select('name','id','name_en')->get();
                                    @endphp
                                    @foreach($amounts as $role)
                                        <option {{ app('request')->input('amount_type') == $role->id ? 'selected' : ''}}  value="{{$role->id}}">{{ app()->getLocale() == 'ar' ? $role->name  : $role->name_en  }}</option>
                                    @endforeach
                                </select>


                                @if ($errors->has('amount_type'))
                                    <span class="help-block">
                                        <strong class="text-danger">{{ $errors->first('type') }}</strong>
                                    </span>
                                @endif
                            </div>


                            <div class="col-md-6 form-group{{$errors->has('active') ? ' has-error' : ''}}"><strong
                                        class="text-danger">*</strong>
                                <label class="control-label" for="active">@lang('strings.Status')</label>
                                <select class="form-control" name="active">
                                    <option value="1">@lang('strings.Active')</option>
                                    <option value="0">@lang('strings.Deactivate')</option>
                                </select>
                                @if ($errors->has('active'))
                                    <span class="help-block">
                                        <strong class="text-danger">{{ $errors->first('active') }}</strong>
                                    </span>
                                @endif
                            </div>
                           </div>

                            <button name="save" value="1" type="submit" onclick="return show_valid_save()"
                                    class="btn btn-primary btn-lg">@lang('strings.Save')</button>


                            <button name="save" value="2" type="submit"  onclick="return show_valid_search()"
                                    class="btn btn-primary btn-lg">@lang('strings.Search')</button>
							 <a  onclick="show_input()"
                                    class="btn btn-primary btn-lg">@lang('strings.add')</a>
                        </form>
                    </br> </br>
                    <div class="panel-heading clearfix">
                        <h4 class="panel-title">@lang('strings.allows')</h4>
                    </div>
                    <table id="xtreme-table" class="display table" style="width: 100%; cellspacing: 0;">
                        <thead>
                        <tr>
                            <th>@lang('strings.allows_type')</th>
                            <th>@lang('strings.Value')</th>
                            <th>@lang('strings.Date')</th>
                            <th>@lang('strings.Status')</th>
                            <th>@lang('strings.Settings')</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tbody>

                        @php
                            $total_value=0;

                        @endphp
                        @foreach($employee_paytypes as $emp_pay_type)
                            @if($emp_pay_type->type==0)
                                <tr>
                                    @php
                                        $total_value +=$emp_pay_type->emp_val;

                                    @endphp

                                    <form method="post"
                                          action="{{ url('admin/update_emp_types_add', $emp_pay_type->id) }}"
                                          enctype="multipart/form-data" role="form"
                                          id="allows_form-{{$emp_pay_type->id}}">
                                        {{ csrf_field() }}


                                        <td>{{ app()->getLocale() == 'ar' ?  $emp_pay_type->name :$emp_pay_type->name_en }}</td>
                                        <td><input type="text" name="emp_val" value="{{ $emp_pay_type->emp_val }}"></td>
                                        <td>
                                            <input type="date" class="form-control datepicker" id="val_date"
                                                   value="{{ $emp_pay_type->val_date }}" name="val_date">
                                        </td>
                                        <td>
                                            <select class="form-control" name="active">
                                                <option {{ $emp_pay_type->active == 1 ? 'selected' : ''}} value="1">{{ __('strings.Active') }}</option>
                                                <option {{ $emp_pay_type->active == 0 ? 'selected' : ''}} value="0">{{ __('strings.Deactivate') }}</option>
                                            </select>
                                        </td>
                                        <td>

                                            <button type="submit" class="btn btn-primary btn-xs"
                                                    onclick="document.forms['allows_form-{{ $emp_pay_type->id}}'].submit(); return false;" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="حفظ">
                                                <i class="fas fa-save"></i></button>
                                        </td>


                                    </form>
                                </tr>

                            @endif
                        @endforeach
                        </tbody>
                        <tfoot>
                        <tr>
                            <td>{{ __('strings.Total') }}</td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td>{{ $total_value}}</td>
                            <td></td>
                        </tr>
                        </tfoot>


                    </table>


                    <div class="panel-heading clearfix">
                        <h4 class="panel-title">@lang('strings.deduction')</h4>
                    </div>

                    <table id="xtreme-table" class="display table" style="width: 100%; cellspacing: 0;">
                        <thead>
                        <tr>
                            <th>@lang('strings.deduction_type')</th>
                            <th>@lang('strings.Value')</th>
                            <th>@lang('strings.Date')</th>
                            <th>@lang('strings.Status')</th>
                            <th>@lang('strings.Settings')</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tbody>
                        @php
                            $total_value=0;

                        @endphp
                        @foreach($employee_paytypes as $emp_pay_type)
                            @if($emp_pay_type->type==1)
                                <tr>
                                @php
                                    $total_value +=$emp_pay_type->emp_val;

                                @endphp
                                <tr>
                                    <form method="post"
                                          action="{{ url('admin/update_emp_types_add', $emp_pay_type->id) }}"
                                          enctype="multipart/form-data" role="form"
                                          id="allows_form-{{$emp_pay_type->id}}">
                                        {{ csrf_field() }}

                                        <td>{{ app()->getLocale() == 'ar' ?  $emp_pay_type->name :$emp_pay_type->name_en }}</td>
                                        <td><input type="text" name="emp_val" value="{{ $emp_pay_type->emp_val }}"></td>
                                        <td>
                                            <input type="date" class="form-control datepicker" id="val_date"
                                                   value="{{ $emp_pay_type->val_date }}" name="val_date">
                                        </td>
                                        <td>
                                            <select class="form-control" name="active">
                                                <option {{ $emp_pay_type->active == 1 ? 'selected' : ''}} value="1">{{ __('strings.Active') }}</option>
                                                <option {{ $emp_pay_type->active == 0 ? 'selected' : ''}} value="0">{{ __('strings.Deactivate') }}</option>
                                            </select>

                                        </td>

                                        <td>
                                            <button type="submit" class="btn btn-primary btn-xs"
                                                    onclick="document.forms['allows_form-{{ $emp_pay_type->id}}'].submit(); return false;" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="حفظ">
                                                <i class="fas fa-save"></i></button>
                                        </td>
                                    </form>
                                </tr>



                            @endif
                        @endforeach
                        </tbody>
                        <tfoot>
                        <tr>
                            <td>{{ __('strings.Total') }}</td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td>{{ $total_value}}</td>
                            <td></td>
                        </tr>
                        </tfoot>

                    </table>


                </div>
            </div>
        </div>

        @endsection
        @section('scripts')
            <script src="https://unpkg.com/vue"></script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
            
@endsection

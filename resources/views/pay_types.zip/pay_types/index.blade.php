@extends('layouts.admin', ['title' =>__('strings.allows')])

@section('content')

    <!--<div class="page-title">-->
    <!--    <h3>@lang('strings.allows')</h3>-->
    <!--    <div class="page-breadcrumb">-->
    <!--        <ol class="breadcrumb">-->
    <!--            <li><a href="{{ route('home') }}">@lang('strings.Home')</a></li>-->
    <!--            <li class="active">@lang('strings.allows')</li>-->
    <!--        </ol>-->
    <!--    </div>-->
    <!--</div>-->

    <div id="main-wrapper">
        <div class="row">
            <div class="col-md-12">
                @include('alerts.index')
                <a class="btn btn-primary btn-lg btn-add" href="pay_types/savepay_type" ><i class="fa fa-plus"></i>&nbsp;&nbsp;@lang('strings.add_deduction')</a>
                <div role="tabpanel">
                    <!-- Nav tabs -->
                    <ul class="nav nav-pills" role="tablist">
                        <li role="presentation"  @if(Request::is('admin/pay_types')) class="active" @endif ><a href="#Benefits" role="tab" data-toggle="tab"><i class="icon-basket"></i>&nbsp;&nbsp;@lang('strings.allows') </a></li>
                        <li role="presentation" @if(Request::is('admin/pay_types/Deduction')) class="active" @endif ><a href="#Deduction" role="tab" data-toggle="tab"><i class="icon-basket"></i>&nbsp;&nbsp;@lang('strings.deduction')</a></li>
                        

                    </ul>
                    <!-- Tab panes -->
                    <div class="tab-content">
                        <div role="tabpanel" class="tab-pane @if(Request::is('admin/pay_types')) active @endif  fade in" id="Benefits">
                            <div class="panel panel-white">
                                <div class="panel-heading clearfix">
                                    <h4 class="panel-title">@lang('strings.allows')</h4>
                                </div>
                                <div class="panel-body">
                                    <table id="xtreme-table" class="display table" style="width: 100%; cellspacing: 0;">
                                        <thead>
                                        <tr>
                                          
                                            <th>@lang('strings.Name')</th>
                                            <th>@lang('strings.deduction_code')</th>
                                             <th>@lang('strings.allows_type')</th>
                                            <th>@lang('strings.Status')</th>
                                            <th>@lang('strings.Settings')</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                         @foreach(App\Pay_types::where(['org_id' => Auth::user()->org_id,	'type'=>'0' ])->get() as $pay_type)
                                            <tr>
                                                <td>{{ app()->getLocale() == 'ar' ?  $pay_type->name :$pay_type->name_en }}</td>
												 <td>{{$pay_type->code}}</td>
												<td>
												@if($pay_type->basic == 1){{__('strings.basic')}}
												@else {{__('strings.other')}}
												@endif
												</td>
                                                <td>
                                                    @if($pay_type->active)
                                                        <span class="label label-success" style="font-size:12px;">@lang('strings.Active')</span>
                                                    @else
                                                        <span class="label label-danger" style="font-size:12px;">@lang('strings.Deactivate')</span>
                                                    @endif
                                                </td>
                                                <td>
                                                     <a href="pay_types/{{ $pay_type->id }}/edit" class="btn btn-primary btn-xs" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="تعديل"> <i
                                                    class="fa fa-pencil"></i></a>
                                        
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div role="tabpanel" class="tab-pane @if(Request::is('admin/pay_types/Deduction')) active @endif  fade in" id="Deduction">
                            <div class="panel panel-white">
                                <div class="panel-heading clearfix">
                                    <h4 class="panel-title">@lang('strings.deduction')</h4>
                                </div>
                                <div class="panel-body">
                                    <table id="xtreme-table" class="display table" style="width: 100%; cellspacing: 0;">
                                        <thead>
                                        <tr>
                                            <th>@lang('strings.Name')</th>
                                            <th>@lang('strings.deduction_code')</th>
											 <th>@lang('strings.deduction_type')</th>
                                            <th>@lang('strings.Status')</th>
                                            <th>@lang('strings.Settings')</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                         @foreach(App\Pay_types::where(['org_id' => Auth::user()->org_id,	'type'=>'1' ])->get() as $pay_type)
                                            <tr>
                                                <td>{{ app()->getLocale() == 'ar' ?  $pay_type->name :$pay_type->name_en }}</td>
												 <td>{{$pay_type->code}}</td>
												<td>
												@if($pay_type->loan == 1){{__('strings.loan')}}
												@else {{__('strings.other')}}
												@endif
												</td>
                                                <td>
                                                    @if($pay_type->active)
                                                        <span class="label label-success" style="font-size:12px;">@lang('strings.Active')</span>
                                                    @else
                                                        <span class="label label-danger" style="font-size:12px;">@lang('strings.Deactivate')</span>
                                                    @endif
                                                </td>
                                                 <td>
                                                   <a href="pay_types/{{ $pay_type->id }}/edit" class="btn btn-primary btn-xs" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="تعديل">
                                                        <i
                                                    class="fa fa-pencil"></i></a>
                                         
                                                </td>   
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                       


            </div>
        </div>
    </div>

@endsection
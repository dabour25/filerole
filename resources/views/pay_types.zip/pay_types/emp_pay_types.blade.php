@extends('layouts.admin', ['title' =>__('strings.allows')])

@section('content')
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.8.0/css/bootstrap-datepicker.min.css">
    <!--<div class="page-title">-->


    <!--    <h3>@lang('strings.allows')</h3>-->
    <!--    <div class="page-breadcrumb">-->
    <!--        <ol class="breadcrumb">-->
    <!--            <li><a href="{{ route('home') }}">@lang('strings.Home')</a></li>-->

    <!--            <li class="active">@lang('strings.allows')</li>-->

    <!--        </ol>-->
    <!--    </div>-->
    <!--</div>-->

    <div id="main-wrapper">
        <div class="row">
            <div class="col-md-12">
             @if (Session::has('message'))
   <div class="alert alert-info">{{ Session::get('message') }}</div>
           @endif
                 <div class="panel panel-white">

                        <div class="panel-body">

				<form method="post" action="{{ url('admin/search_epmp_types') }}" enctype="multipart/form-data" id="search_form">
                            {{csrf_field()}}
							<div class="col-lg-3 col-md-4 col-sm-6 m-b-sm">
							<strong class="text-danger">*</strong>
                                  <label class="control-label" for="users">@lang('strings.Employee')</label>
                                    <select class="form-control js-select" name="search_name"  >
                                       <option value="0" >@lang('strings.Select_employee')</option>

		@php

$users=App\User::where([ 'org_id' => Auth::user()->org_id, 'is_active'=>1,'type' => 1])->select('name','id','name_en')->get();

@endphp

		@foreach($users as $role)

                      <option {{ app('request')->input('search_name') == $role->id ? 'selected' : ''}}  value="{{$role->id}}">{{ app()->getLocale() == 'ar' ? $role->name  : $role->name_en  }}</option>
                                        @endforeach
                                    </select>
                                </div>
				<div class="col-lg-6 col-md-4 col-sm-6 ">
                <div class="input-group text">
                  <label>{{__('strings.date')}}</label>
                  <input name="date_emp" type="date" class="form-control" value="{{ app('request')->input('date_emp') }}" required/>
                </div>
              </div>

                   <input type="hidden" name="test" value="{{ app('request')->input('search_name') }}">


						 </div>
					<button  type="submit" class="btn btn-primary btn-lg"> <i class="fa fa-search"></i> @lang('strings.Search')</button>
					</form>
					 <a href="{{ url('admin/add_emp_type') }}" class="btn btn-primary btn-lg"> <i class="fa fa-plus"></i> @lang('strings.add_allows')</a>
						</div>



						<div class="panel-heading clearfix">
                                    <h4 class="panel-title">@lang('strings.allows')</h4>
                            </div>
                                    <table id="xtreme-table" class="display table" style="width: 100%; cellspacing: 0;">
                                        <thead>
                                        <tr>
                                            <th>@lang('strings.allows_type')</th>
                                            <th>@lang('strings.Value')</th>
											<th>@lang('strings.Date')</th>
                                            <th>@lang('strings.Status')</th>
                                            <th>@lang('strings.Settings')</th>
                                        </tr>
                                        </thead>
                                        <tbody>

										@php
										$total_value=0;

										@endphp

                                         @foreach($employee_paytypes as $emp_pay_type)
										 @if($emp_pay_type->type==0)
											<tr>
										@php
										$total_value +=$emp_pay_type->emp_val;
										@endphp

										 <form method="post" action="{{ url('admin/update_emp_types', $emp_pay_type->id) }}" enctype="multipart/form-data" role="form" id="allows_form-{{$emp_pay_type->id}}">
												 {{ csrf_field() }}


												 <td>{{ app()->getLocale() == 'ar' ?  $emp_pay_type->name :$emp_pay_type->name_en }}</td>
												 <td><input type="text" name="emp_val" value="{{ $emp_pay_type->emp_val }}"></td>
												 <td>
                        <input type="date" class="form-control datepicker"  id="val_date" value="{{ $emp_pay_type->val_date }}"  name="val_date" >
                                                </td>
												 <td>
													<select class="form-control" name="active" >
													  <option {{ $emp_pay_type->active == 1 ? 'selected' : ''}} value="1">{{ __('strings.Active') }}</option>
													  <option {{ $emp_pay_type->active == 0 ? 'selected' : ''}} value="0">{{ __('strings.Deactivate') }}</option>
													 </select>
												 </td>
												 <td><button type="submit" class="btn btn-primary btn-xs" onclick="document.forms['allows_form-{{$emp_pay_type->id}}'].submit(); return false;"><i class="fa fa-pencil"></i></button></td>


											</tr>
			                              </form>
											@endif
                                        @endforeach

                                        </tbody>

										<tfoot>
                                        <tr>
                                            <td>{{ __('strings.Total') }}</td>
                                            <td></td>
                                            <td></td>
											<td></td>
                                            <td>{{ $total_value}}</td>
                                            <td></td>
                                        </tr>
                                        </tfoot>
                                    </table>


                                <div class="panel-heading clearfix">
                                    <h4 class="panel-title">@lang('strings.deduction')</h4>
                                </div>

                                <table id="xtreme-table" class="display table" style="width: 100%; cellspacing: 0;">
								<thead>
                                        <tr>
                                            <th>@lang('strings.deduction_type')</th>
                                            <th>@lang('strings.Value')</th>
											<th>@lang('strings.Date')</th>
                                            <th>@lang('strings.Status')</th>
                                            <th>@lang('strings.Settings')</th>
                                        </tr>
                                        </thead>
                                        <tbody>
										@php
										$total_value=0;

										@endphp
										@foreach($employee_paytypes as $emp_pay_type)
									    @if($emp_pay_type->type==1)
                                       <tr>
                                        @php
										$total_value +=$emp_pay_type->emp_val;
										@endphp

								    <form method="post" action="{{ url('admin/update_emp_types', $emp_pay_type->id) }}" enctype="multipart/form-data" role="form" id="allows_form-{{$emp_pay_type->id}}">


												 {{ csrf_field() }}

								<td>{{ app()->getLocale() == 'ar' ?  $emp_pay_type->name :$emp_pay_type->name_en }}</td>
								<td><input type="text" name="emp_val" value="{{ $emp_pay_type->emp_val }}"></td>
								<td>
                  <input type="date" class="form-control datepicker"  id="val_date" value="{{ $emp_pay_type->val_date }}"  name="val_date" >
                                </td>
											<td>
											<select class="form-control" name="active" >
											  <option {{ $emp_pay_type->active == 1 ? 'selected' : ''}} value="1">{{ __('strings.Active') }}</option>
											  <option {{ $emp_pay_type->active == 0 ? 'selected' : ''}} value="0">{{ __('strings.Deactivate') }}</option>
											  </select>

											</td>
											<td><button type="submit" class="btn btn-primary btn-xs" onclick="document.forms['allows_form-{{ $emp_pay_type->id}}'].submit(); return false;"><i class="fa fa-pencil"></i></button></td>

										 </form>
									   </tr>



										@endif
                                        @endforeach
										 </tbody>
                               <tfoot>
                                        <tr>
                                            <td>{{ __('strings.Total') }}</td>
                                            <td></td>
                                            <td></td>
											<td></td>
                                            <td>{{ $total_value}}</td>
                                            <td></td>
                                        </tr>
                                        </tfoot>

                        </table>




            </div>
        </div>
    </div>

@endsection
@section('scripts')
 <script src="https://unpkg.com/vue"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.8.0/js/bootstrap-datepicker.js"></script>

@endsection

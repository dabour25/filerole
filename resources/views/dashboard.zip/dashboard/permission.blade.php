@extends('layouts.admin', ['title' => __('strings.dashboard')])

@section('styles')
    <link href="{{ asset('plugins/morris/morris.css') }}" rel="stylesheet" type="text/css"/>
@endsection

@section('content')
   
@endsection



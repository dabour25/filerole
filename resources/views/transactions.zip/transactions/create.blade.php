@extends('layouts.admin', ['title' => __('strings.transactions_list_add')])
@section('styles')
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.0/css/select2.min.css" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/16.0.0/css/intlTelInput.css" rel="stylesheet" />
@endsection
@section('content')

<div class="alert_new">
        <span class="alertIcon">
            <i class="fas fa-exclamation-circle"></i>
         </span>
         <p>
             @if (app()->getLocale() == 'ar')
            {{ DB::table('function_new')->where('id',6)->value('description') }}
            @else
            {{ DB::table('function_new')->where('id',6)->value('description_en') }}
            @endif
         </p>
         <a href="#" onclick="close_alert()" class="close_alert">  <i class="fas fa-times-circle"></i> </a>
         
    </div>
    @if ($errors->has('products') || $errors->has('price.*'))
        <div class="alert alert-danger"  role="alert">
            <h4 class="alert-heading">{{ __('strings.error') }}</h4>
            <p>{{ $errors->first('products') }}</p>
            <p>{{ $errors->first('price.*') }}</p>
        </div>
    @endif

    <style>
        #tab_logic .form-control[readonly], #tab_logic_total .form-control[readonly] {
            border: 0;
            background: transparent;
            box-shadow: none;
            padding: 0 10px;
            font-size: 15px;
        }
    </style>

    <!--<div class="page-title">
        @if(Request::is('admin/transactions/*/edit')) <h3> @lang('strings.transactions_list') </h3> @else <h3> @lang('strings.transactions_list_add') </h3> @endif
        <div class="page-breadcrumb">
            <ol class="breadcrumb">
                <li><a href="{{ route('home') }}">@lang('strings.Home')</a></li>
                <li><a href="{{ route('transactions.index') }}"> @lang('strings.transactions_list')</a></li>
                <li><a href="{{ url('admin/search') }}"> @lang('strings.Search')</a></li>
                @if(Request::is('admin/transactions/*/edit')) <li class="active"> @lang('strings.transactions_list')</li> @else <li class="active">@lang('strings.transactions_list_add')</li> @endif
            </ol>
        </div>
    </div>-->

    <div class="modal fade newModel" id="addclient" role="dialog">
        <div class="modal-dialog">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-body" style="overflow: hidden">
                    <form method="post" action="#" enctype="multipart/form-data" id="add_customer_store">
                        {{csrf_field()}}
                        <input type="hidden" class="form-control" name="user_id" value="{{  Auth::user()->id }}">
                        <input type="hidden" class="form-control" name="active" value="1">

                        <div class="col-md-6 form-group{{$errors->has('name') ? ' has-error' : ''}}"> <strong class="text-danger">*</strong>
                            <label class="control-label" for="name">{{ __('strings.Arabic_name') }}</label>
                            <input type="text" class="form-control" name="name" value="{{old('name')}}" required>
                            @if ($errors->has('name'))
                                <span class="help-block">
                                    <strong class="text-danger">{{ $errors->first('name') }}</strong>
                                </span>
                            @endif
                        </div>

                        <div class="col-md-6 form-group{{$errors->has('name_en') ? ' has-error' : ''}}">
                            <label class="control-label" for="name_en">{{ __('strings.English_name') }}</label>
                            <input type="text" class="form-control" name="name_en" value="{{old('name_en')}}" required>
                            @if ($errors->has('name_en'))
                                <span class="help-block">
                                    <strong class="text-danger">{{ $errors->first('name_en') }}</strong>
                                </span>
                            @endif
                        </div>

                        <div class="col-md-6 form-group{{$errors->has('email') ? ' has-error' : ''}}"> <strong class="text-danger">*</strong>
                            <label class="control-label" for="email">{{ __('strings.Email') }}</label>
                            <input type="text" class="form-control" name="email" value="{{old('email')}}" required>
                            @if ($errors->has('email'))
                                <span class="help-block">
                                    <strong class="text-danger">{{ $errors->first('email') }}</strong>
                                </span>
                            @endif
                        </div>

                        <div class="col-md-6 form-group{{$errors->has('gender') ? ' has-error' : ''}}"> <strong class="text-danger">*</strong>
                            <label class="control-label" for="gender">{{ __('strings.Gender') }}</label>
                            <select class="form-control" name="gender" required>
                                <option value="1">{{ __('strings.Male') }}</option>
                                <option value="0">{{ __('strings.Female') }}</option>
                            </select>
                            @if ($errors->has('gender'))
                                <span class="help-block">
                                    <strong class="text-danger">{{ $errors->first('gender') }}</strong>
                                </span>
                            @endif
                        </div>

                        <div class="col-md-6 form-group{{$errors->has('address') ? ' has-error' : ''}}"> <strong class="text-danger">*</strong>
                            <label class="control-label" for="address">{{ __('strings.Address') }}</label>
                            <input type="text" class="form-control" name="address" value="{{old('address')}}" required>
                            @if ($errors->has('address'))
                                <span class="help-block">
                                    <strong class="text-danger">{{ $errors->first('address') }}</strong>
                                </span>
                            @endif
                        </div>

                        <div class="col-md-12 form-group{{$errors->has('phone_number') ? ' has-error' : ''}}"> <strong class="text-danger">*</strong>
                            <label class="control-label" for="phone_number">{{ __('strings.Phone') }}</label>
                            <input type="tel" class="form-control" name="phone_number" id="phone" value="{{old('phone_number')}}" required>
                            <span id="valid-msg" class="hide">✓ صالح</span>
                            <span id="error-msg" class="hide"></span>

                            @if ($errors->has('phone_number'))
                                <span class="help-block">
                                    <strong class="text-danger">{{ $errors->first('phone_number') }}</strong>
                                </span>
                            @endif
                        </div>
                        <div class="col-md-6 form-group{{$errors->has('from_date') ? ' has-error' : ''}}">
                            <label class="control-label" for="from_date"> {{ __('strings.From_date') }}</label>
                            <input type="date" class="form-control" name="from_date" value="{{old('from_date', date('Y-m-d'))}}" >
                            @if ($errors->has('from_date'))
                                <span class="help-block">
                                    <strong class="text-danger">{{ $errors->first('from_date') }}</strong>
                                </span>
                            @endif
                        </div>

                        <div class="col-md-6 form-group{{$errors->has('to_date') ? ' has-error' : ''}}">
                            <label class="control-label" for="to_date">{{ __('strings.To_date') }} </label>
                            <input type="date" class="form-control" name="to_date" value="{{old('to_date', date('Y-m-d'))}}">
                            @if ($errors->has('to_date'))
                                <span class="help-block">
                                    <strong class="text-danger">{{ $errors->first('to_date') }}</strong>
                                </span>
                            @endif
                        </div>
                        <div class="col-md-12 form-group text-right">
                            <button type="submit" class="btn btn-primary btn-lg" id="add_customer_submit">{{ __('strings.Save') }}</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade newModel" id="open-modal" role="dialog">
        <div class="modal-dialog modal-lg">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-body" style="overflow: hidden">

                </div>
            </div>

        </div>
    </div>

    <div id="main-wrapper">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-white">
                    <div class="panel-body">
                        <form method="post" action="{{route('transactions.store')}}" enctype="multipart/form-data" id="submit-form">
                            {{csrf_field()}}
                            <div class="row">
                                <div class="col-md-4">
                                    <table class="table table-bordered table-hover" id="tab_logic_total">
                                        <tbody>
                                        <tr>
                                            <th class="text-center">@lang('strings.Client_name')</th>
                                            <td>
                                                <select class="js-select New_select" name="customer_id" id="customers" required="required">
                                                    @foreach($customers as $customer)
                                                        @if(Request::is('admin/transactions/*/edit')) <option {{ $request->cust_id ==  $customer->id ? 'selected' : ''}} value="{{ $customer->id }}">{{ app()->getLocale() == 'ar' ? $customer->name : $customer->name_en }}</option> @else <option value="{{ $customer->id }}">{{ app()->getLocale() == 'ar' ? $customer->name : $customer->name_en }}</option> @endif
                                                    @endforeach
                                                </select>
                                                <button type="button" class="btn btn-info btn-lg NewBtn btnclient" data-toggle="modal" data-target="#addclient"><i class="fas fa-plus"></i></button>
                                                @if ($errors->has('customer_id'))
                                                    <span class="help-block">
                                                    <strong class="text-danger">{{ $errors->first('customer_id') }}</strong>
                                                </span>
                                                @endif
                                            </td>
                                        </tr>
                                        <tr>
                                            <th class="text-center">@lang('strings.transactions_date')</th>
                                            <td class="text-center">
                                                <input type="date" name="date" class="form-control"
                                                   @if(Request::is('admin/transactions/*/edit') && $request->date !== '') value="{{ date('Y-m-d', strtotime($request->date))  }}" @else   value="{{old('date', date('Y-m-d'))}}" @endif>
                                                        @if ($errors->has('date'))
                                                            <span class="help-block">
                                                            <strong class="text-danger">{{ $errors->first('date') }}</strong>
                                                        </span>
                                                   @endif
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="col-md-8">
                                    <table class="table table-bordered table-hover" id="tab_logic_total">
                                        <tbody>
                                            <tr>
                                                <th class="text-center" width="150"> @lang('strings.inv_numer') </th>
                                                <th class="text-center"> @lang('strings.inv_date')  </th>
                                                <th class="text-center"> @lang('strings.inv_esd')  </th>
                                                <th class="text-center" width="150"> @lang('strings.inv_role')  </th>
                                            </tr>
                                            <tr>
                                                <td class="text-center">
                                                    <div class="input-group" style="direction: ltr">
                                                        <span class="input-group-addon" id="basic-addon1">@if(Invoice_setup('3') != '') {{  Invoice_setup('3') }} @endif </span>
                                                        @if(Request::is('admin/transactions/*/edit') && $request !== '')
                                                            <input class="form-control" type="text" name="invoice_no" aria-describedby="basic-addon1" value="{{ $request->invoice_no }}">
                                                            @else
                                                            <input class="form-control" type="text" name="invoice_no" aria-describedby="basic-addon1" value="{{ $invoice_no }}">
                                                        @endif
                                                    </div>
                                                </td>
                                                @if(Request::is('admin/transactions/*/edit') && $request !== '')
                                                <td class="text-center"> <input class="form-control" type="text" readonly name="invoice_date" value="{{ $request->invoice_date }}"> </td>
                                                <td class="text-center"> <input class="form-control" type="text" name="release_date" disabled value="{{ $request->created_at }}"> </td>
                                                   <td class="text-center"> <input class="form-control" type="text" name="due_date" value="{{  $request->due_date }}"> {{ __('strings.days') }} </td>
                                                @else
                                                    <td class="text-center"> <input class="form-control" type="readonly" readonly name="invoice_date" value="{{ date('Y-m-d h:i:s') }}"> </td>
                                                    <td class="text-center"> <input class="form-control" type="text" name="release_date" disabled value="{{ date('Y-m-d') }}"> </td>
                                                    <td class="text-center"> <input class="form-control" type="text" name="due_date" value="{{ \App\InvoiceSetup::where(['org_id' => Auth::user()->org_id, 'type' => 5])->value('value') == ''  ? 0 : \App\InvoiceSetup::where(['org_id' => Auth::user()->org_id, 'type' => 5])->value('value')}}"> {{ __('strings.days') }} </td>
                                                @endif
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            @if(Request::is('admin/transactions/*/edit') && $request !== '')
                                <input id="head_id" type="hidden" name="head_id" value="{{ $request->id }}">
                                <div>
                                    <h3>@lang('strings.transaction_list')</h3>
                                    <table class="table table-bordered table-hover" data-toggle="tooltip" data-placement="top" title="تصريح المسؤول" >
                                        <thead>
                                            <tr>
                                                <th class="text-center"> @lang('strings.transactions_type')</th>
                                                <th class="text-center"> @lang('strings.Categories')</th>
                                                <th class="text-center"> @lang('strings.Quantity')</th>
                                                <th class="text-center"> @lang('strings.Unit_price')</th>
                                                <th class="text-center"> @lang('strings.Tax')</th>
                                                <th class="text-center"> @lang('strings.Total')</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        @foreach($request->transactions as $v)
                                            <tr>
                                                <td><select class="form-control" style="width: 100px" disabled>
                                                        <option {{ $v->req_flag == -1 ? 'selected' : '' }} value="-1">@lang('strings.Cashing')</option>
                                                        <option {{ $v->req_flag == 1 ? 'selected' : '' }} value="1"> @lang('strings.Reflux')</option>
                                                    </select></td>
                                                <td>
                                                    <input type="text" class="form-control" value="{{ app()->getLocale() == 'ar' ? App\Category::findOrFail($v->cat_id)->name : App\Category::findOrFail($v->cat_id)->name_en }}" disabled/>
                                                    <input type="hidden" name="old_products[]" class="form-control" value="{{ $v->id }}" />
                                                </td>
                                                <td>
                                                    <input type="text" placeholder='@lang('strings.Quantity')'
                                                           class="form-control" step="0.00" min="0" style="width: 100px" value="{{ $v->quantity }}" disabled/>
                                                </td>
                                                <td>
                                                    <input type="text" placeholder='0.00'
                                                           class="form-control" step="0.00" min="0" readonly
                                                           style="width: 150px" value="{{ Decimalplace($v->price) }}"/>
                                                </td>
                                                <td>
                                                    <input type="text" placeholder='0.00'
                                                           class="form-control" readonly style="width: 100px" value="{{ Decimalplace($v->tax_val) }}"/>
                                                </td>
                                                <td>
                                                    <input type="text" placeholder='0.00'
                                                           class="form-control" readonly style="width: 130px" value="{{ Decimalplace($v->price *  $v->quantity) }}"/>
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>

                                </div>
                            @endif

                            @if(($return == 1 && Request::is('admin/transactions/*/edit')) || session('isadmin') == 1 || Request::is('admin/transactions/create') || ($return == 1 && isset($request) && $request->invoice_no == null))

                                <div>
                                    <table class="table table-bordered table-hover" id="tab_logic">
                                        <thead>
                                            <tr>
                                                <th class="text-center"></th>
                                                <th class="text-center"> @lang('strings.transactions_type')</th>
                                                <th class="text-center"> @lang('strings.Categories')</th>
                                                <th class="text-center"> @lang('strings.Quantity')</th>
                                                <th class="text-center"> @lang('strings.Unit_price')</th>
                                                <th class="text-center"> @lang('strings.Tax')</th>
                                                <th class="text-center"> @lang('strings.Total')</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <tr id='row-1'>
                                            <td><a href="#"
                                                   class="delete_row pull-right delete-ico btn btn-xs btn-danger"><i
                                                            class="fa fa fa-remove"></i></a></td>
                                            <td><select class="form-control type" name="transaction_type[]">
                                                    <option value="-1" selected>@lang('strings.Cashing')</option>
                                                    <option value="1">@lang('strings.Reflux')</option>
                                                </select></td>
                                            <td>
                                                    <select class="form-control New_select products" id="products-1" onchange="invoices(1);" name="products[]" required>
                                                        <option value="0">@lang('strings.select')</option>
                                                        @foreach(App\Category::where(['active' => 1 ,'org_id' => Auth::user()->org_id])->get() as $value)
                                                            <option value="{{ $value->id }}"> {{ $value->name }} </option>
                                                        @endforeach
                                                    </select>

                                                    <div class="btn-group btns_sanef">
                                                        <button type="button" class="btn btn-info btn-lg NewBtn btnclient btnsanef" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                                                            <i class="fa fa-plus"></i>
                                                        </button>
                                                        <ul class="dropdown-menu pull-right">
                                                            @if(App\Settings::where(['key' => 'sold_item_type', 'org_id' => Auth::user()->org_id])->value('value') == 1)
                                                            <li>
                                                                <button type="button" class="btn btn-info btn-lg NewBtn btnclient btnsanef open-modal"><i class="fas fa-plus"></i> {{ __('strings.Categories_add') }} </button>
                                                            </li>
                                                            @endif
                                                            @if(App\Settings::where(['key' => 'sold_item_type', 'org_id' => Auth::user()->org_id])->value('value') == 2)
                                                            <li>
                                                                <button type="button" class="btn btn-info btn-lg NewBtn btnclient btnsanef open-modal-2"><i class="fas fa-plus"></i> {{ __('strings.Categories_add_service') }} </button>
                                                            </li>
                                                            @endif

                                                            @if(App\Settings::where(['key' => 'sold_item_type', 'org_id' => Auth::user()->org_id])->value('value') == 0)
                                                            <li>
                                                                <button type="button" class="btn btn-info btn-lg NewBtn btnclient btnsanef open-modal"><i class="fas fa-plus"></i> {{ __('strings.Categories_add') }} </button>
                                                            </li>
                                                            <li>
                                                                <button type="button" class="btn btn-info btn-lg NewBtn btnclient btnsanef open-modal-2"><i class="fas fa-plus"></i> {{ __('strings.Categories_add_service') }} </button>
                                                            </li>
                                                            @endif
                                                            <li>
                                                                <button type="button" class="btn btn-info btn-lg NewBtn btnclient btnsanef open-modal-3"><i class="fas fa-plus"></i> {{ __('strings.Categories_add_price') }} </button>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    {{--<input type="hidden" class="autocomplete_hidden_value" name="products[]" id="SchoolHiddenId"/>--}}

                                                    {{--@if ($errors->has('products'))
                                                        <span class="help-block">
                                                            <strong class="text-danger">{{ $errors->first('products') }}</strong>
                                                        </span>
                                                    @endif
                                                    @if ($errors->has('price.*'))
                                                        <span class="help-block">
                                                            <strong class="text-danger">{{ $errors->first('price.*') }}</strong>
                                                        </span>
                                                    @endif--}}
                                            </td>
                                            <td>
                                                <input type="number" name='qty[]' class="form-control qty" required min="1" step="any" style="width: 100px" value="1" id="qty-1"/>
                                            </td>
                                            <td>
                                                <input type="number" name='price[]' placeholder='0.00' required
                                                       class="form-control price price_item-1" step="0.00" min="0" readonly
                                                       style="width: 150px"/>
                                            </td>
                                            <td><input type="number" name='tax[]' placeholder='0.00'
                                                       class="form-control total_tax_1" readonly style="width: 100px"/>
                                                <input type="number" name='tax_id[]' class="form-control tax_id_1" style="display: none"/></td>

                                            <td><input type="number" name='total[]' placeholder='0.00'
                                                       class="form-control total" readonly style="width: 130px"/></td>
                                        </tr>
                                        </tbody>
                                    </table>
                                    <div class="row clearfix">
                                        <div class="col-md-4">
                                            <a id="add_rowaa" onclick="addbtn(this)" class="btn btn-primary btn-lg btn_row pull-right"> <i class="fas fa-plus"></i>  @lang('strings.Add_item')</a>
                                        </div>
                                        <div class="col-md-4">
                                            <table class="table table-bordered table-hover" id="tab_logic_total">
                                                <tbody>
                                                @if(isset($request))
                                                    <input type="hidden" class="form-control total-invoice" value="{{ $request->transactions->sum('total') }}" readonly >
                                                    <tr>
                                                        <th class="text-center no_padd">@lang('strings.Total_amount')</th>
                                                        <td class="text-center no_padd"><input type="text" name='total_amount'
                                                                                       id="total_amount" value='{{ Decimalplace($request->transactions->sum('total')) }}'
                                                                                       class="form-control" readonly/></td>
                                                    </tr>
                                                @else
                                                    <tr>
                                                        <th class="text-center no_padd">@lang('strings.Total_amount')</th>
                                                        <td class="text-center no_padd"><input type="number" name='total_amount'
                                                                                       id="total_amount" placeholder='0.00'
                                                                                       class="form-control" readonly/></td>
                                                    </tr>
                                                @endif
                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="col-md-4">
                                            @if(($return  == 0 && Request::is('admin/transactions/*/edit')) || (session('isadmin') == 0 && $isadmin = 0))
                                                <div class="more-options-box">
                                                    <button class="btn btn-default btn-lg m-b-md btn_open_row" data-toggle="collapse" href="#extra-settings" aria-expanded="true" aria-controls="extra-settings">
                                                        <i class="fa fa-bars"></i>
                                                        @lang('strings.Other_options')
                                                    </button>
                                                    <div class="clear"></div>
                                                    <div class="m-b-md collapse" id="extra-settings" aria-expanded="true" style="">
                                                        <ul class="nav nav-tabs responsive" id="myTab">
                                                            <li class="tab-1 active main-tabs"><a href="#tab-1" aria-controls="tab-1" role="tab" data-toggle="tab" tabindex="-1"><span>@lang('strings.Admin_login')</span></a></li>
                                                        </ul>

                                                        <div class="tab-content responsive">
                                                            <div class="tab-pane active" id="tab-1">
                                                                <div class="row">
                                                                    <table class="table table-bordered table-hover">
                                                                        <tbody>
                                                                        <tr>
                                                                            <th class="text-center">@lang('strings.Email')</th>
                                                                            <th>
                                                                                <input type="email" name="email" class="form-control">
                                                                                @if ($errors->has('email'))
                                                                                    <span class="help-block">
                                                                        <strong class="text-danger">{{ $errors->first('email') }}</strong>
                                                                    </span>
                                                                                @endif
                                                                            </th>
                                                                        </tr>
                                                                        <tr>
                                                                            <th class="text-center">@lang('strings.Password')</th>
                                                                            <th>
                                                                                <input type="password" name="password" class="form-control">
                                                                                @if ($errors->has('password'))
                                                                                    <span class="help-block">
                                                                        <strong class="text-danger">{{ $errors->first('password') }}</strong>
                                                                    </span>
                                                                                @endif
                                                                            </th>
                                                                        </tr>
                                                                        <tr>
                                                                            <th class="text-center"></th>
                                                                            <th class="text-center">
                                                                                <button name="save" type="submit" class="btn btn-primary btn-lg" value="3"> @lang('strings.Login')</button>
                                                                            </th>
                                                                        </tr>
                                                                        </tbody>
                                                                    </table>

                                                                </div>

                                                            </div>

                                                        </div>
                                                    </div>
                                                </div>
                                            @endif
                                        </div>
                                    </div>
                                    <div class="row clearfix" style="margin-top:20px">
                                        <div class="col-md-12">
                                            <div class="col-md-12 form-group{{$errors->has('description') ? ' has-error' : ''}}">
                                                <label class="control-label" for="description">@lang('strings.Description')</label>
                                                <textarea type="text" class="textall"
                                                          name="description">{{old('description')}}</textarea>
                                                @if ($errors->has('description'))
                                                    <span class="help-block">
                                                <strong class="text-danger">{{ $errors->first('description') }}</strong>
                                            </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-12 form-group text-right">
                                    @if(Request::is('admin/transactions/*/edit') && $request !== '' && $request->invoice_no == '')
                                        <button name="save" type="submit" class="btn btn-primary btn-lg" value="4"><i class="fas fa-save"></i> @lang('strings.Create_invoice')</button>
                                    @endif
                                    @if(Request::is('admin/transactions/*/edit') && $request !== '')
                                        <a href="{{ url('admin/transactions/'.$request->id.'/print') }}" class="btn btn-primary btn-lg" value="0"><i class="fas fa-print"></i> @lang('strings.Print')  </a>
                                    @endif
                                    @if(Request::is('admin/transactions/*/edit') && $request !== '')
                                        <a href="{{ url('admin/transactions/paid/'.$request->id) }}" class="btn btn-primary btn-lg" value="0">  @lang('strings.Pay')</a>
                                    @endif
                                    <button name="save" type="submit" class="btn btn-primary btn-lg" value="0"><i class="fas fa-save"></i> @lang('strings.Save') </button>
                                    @if(Request::is('admin/transactions/create'))
                                        <button name="save" type="submit" class="btn btn-primary btn-lg" value="1"><i class="fas fa-print"></i> @lang('strings.Save_print_create_invoice')</button>
                                    @endif
                                </div>
                            @endif
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('scripts')
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.0/js/select2.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/16.0.0/js/intlTelInput.js"></script>

    <script>
        $('.js-select').select2({  width: 300, required: true });
        $('.products').select2({  width: 300, required: true });

        function addbtn(){
            $('.products').select2("destroy");

            var row = $("#tab_logic tr").last().clone().find('input').val('').end();
            var oldId = Number(row.attr('id').slice(-1));
            var id = 1 + oldId;
            row.attr('id', 'row-' + id );
            row.find('#products-' + oldId).attr('id', 'products-' + id).attr('onchange', 'invoices(' + id + ');');
            row.find('.price_item-' + oldId).attr('class', 'form-control price price_item-' + id);
            row.find('.total_tax_' + oldId).attr('class', 'form-control total_tax_' + id);
            row.find('.tax_id_' + oldId).attr('class', 'form-control tax_id_' + id);
            row.find('#qty-' + oldId).attr('id', 'qty-' + id).val('1');

            $('.products').select2({  width: 300 , required: true});
            $('#tab_logic').append(row);
            //$("#addr0").clone().appendTo("#tab_logic");
        }

        function invoices(id) {
            console.log(id)
            //$("#products-"+ id).change(function () {
            if($('#products-'+ id + ' :selected').val() != 0) {
                if ($('.type').val() == 1) {
                    var dataString = 'product_id=' + $('#products-' + id + ' :selected').val() + '&transaction_id=' + $('#head_id').val();

                    $.ajax({
                        type: "POST",
                        url: '{{ url('admin/transactions/transactions-item-price') }}',
                        data: dataString,
                        cache: false,
                        success: function (data) {
                            if (data.price == null) {
                                alert("@lang('strings.transactions_item_not')");
                            }
                            $('.price_item-' + id).val(data.price);
                            $('.total_tax_' + id).val(data.tax_value);
                            $('.tax_id_' + id).val(data.tax_id);
                            calculation();
                        }
                    });

                } else {
                    var dataString = 'product_id=' + $('#products-' + id + ' :selected').val();

                    $.ajax({
                        type: "POST",
                        url: '{{ url('admin/transactions/item-details') }}',
                        data: dataString,
                        cache: false,
                        success: function (data) {
                            if (data.length == 0) {
                                alert("@lang('strings.transactions_item_price')");
                            } else if (data[0].price == null) {
                                alert("@lang('strings.transactions_item_price')");
                            } else {
                                $('.price_item-' + id).val(data[0].price);
                                $('.total_tax_' + id).val(data[0].tax_value);
                                $('.tax_id_' + id).val(data[0].tax_id);
                                calculation();
                            }
                        }
                    });
                }


            }
            //});
        }
        function calculation() {
            $('#tab_logic tbody tr').each(function (i, element) {
                var qty = $(this).find('.qty').val();
                var price = $(this).find('.price').val();
                $(this).find('.total').val((qty * price * $(this).find('.type').val()).toFixed(2));
                calculation_total();
            });
        }
        function calculation_total() {
            total = 0;
            residual = 0;
            $('.total').each(function () {
                total += parseFloat($(this).val());
            });
            total = total;
            /*$('.residual').each(function () {
                residual += parseFloat($(this).val());
            });*/

            //$('#sub_total').val(Math.abs(total));
            @if(Request::is('admin/transactions/*/edit'))
            $('#total_amount').val(Math.abs(total + parseFloat($('.total-invoice').val())).toFixed(2));
            @else
            $('#total_amount').val(Math.abs(total).toFixed(2));
            @endif
            //$('#total_amount').val(Math.abs(total.toFixed(2)));
        }
        $(document).on('click', '.delete_row', function () {
            if($('#tab_logic tbody tr').length != 1 && $(this).closest('tr').attr('id') != 'row-1') {
                $(this).closest('tr').remove();
                return false;
            }
        });

        $(document).on('click', '.open-modal', function () {
            // LOADING THE AJAX MODAL
            jQuery('#open-modal').modal('show', {backdrop: 'true'});
            // SHOW AJAX RESPONSE ON REQUEST SUCCESS
            $.ajax({
                url: '{{ url('admin/ajax/categories_modal') }}/1',
                success: function (response) {
                    jQuery('#open-modal .modal-body').html(response);
                }
            });
            return false;
        });


        $(document).on('click', '.open-modal-2', function () {
            // LOADING THE AJAX MODAL
            jQuery('#open-modal').modal('show', {backdrop: 'true'});
            // SHOW AJAX RESPONSE ON REQUEST SUCCESS
            $.ajax({
                url: '{{ url('admin/ajax/categories_modal') }}/2',
                success: function (response) {
                    jQuery('#open-modal .modal-body').html(response);
                }
            });
            return false;
        });

        $(document).on('click', '.open-modal-3', function () {
            // LOADING THE AJAX MODAL
            jQuery('#open-modal').modal('show', {backdrop: 'true'});
            // SHOW AJAX RESPONSE ON REQUEST SUCCESS
            $.ajax({
                url: '{{ url('admin/ajax/price_modal') }}',
                success: function (response) {
                    jQuery('#open-modal .modal-body').html(response);
                }
            });
            return false;
        });

        $(document).on('change', '#tab_logic tbody tr input', function () {
            var id = this.id.split('-')[1];
            if($('#products-' + id + ' :selected').val() != 0) {
                $.get("{{ url('admin/transactions/store-quantity') }}/" + $('#products-' + id + ' :selected').val() + '/' + parseFloat($('#qty-' + id).val()), function (data) {
                    if (data != 'false') {
                        //if (data < parseFloat($('#qty-' + id).val())) {
                            alert("@lang('strings.store_quantity_message')");
                        //}
                    }
                });
            }
        });

        $(document).ready(function () {
            $('#tab_logic tbody').on('keyup change', function () {
                calc();
                calc_total();

            });

            function calc() {
                $('#tab_logic tbody tr').each(function (i, element) {
                    var qty = $(this).find('.qty').val();
                    var price = $(this).find('.price').val();
                    $(this).find('.total').val((qty * price * $(this).find('.type').val()).toFixed(2));
                    //$(this).find('.residual').val(qty * price);
                    calc_total();
                });
            }

            function calc_total() {
                total = 0;
                residual = 0;
                $('.total').each(function () {
                    total += parseFloat($(this).val());
                });
                total = total;
                /*$('.residual').each(function () {
                    residual += parseFloat($(this).val());
                });*/

                //$('#sub_total').val(Math.abs(total));
                @if(Request::is('admin/transactions/*/edit'))
                $('#total_amount').val(Math.abs(total + parseFloat($('.total-invoice').val())));
                @else
                $('#total_amount').val(Math.abs(total));
                @endif
                //$('#total_amount').val(Math.abs(total.toFixed(2)));
            }

            $('#pay_method').change(function () {
                if(this.value == 1){
                    $('#treasure').show();
                    $('#banks').hide();
                }else if(this.value == 2){
                    $('#treasure').hide();
                    $('#banks').show();
                }else{
                    $('#banks').hide();
                    $('#treasure').hide();
                }
            });

            var input = document.querySelector("#phone"),
                errorMsg = document.querySelector("#error-msg"),
                validMsg = document.querySelector("#valid-msg");

            // here, the index maps to the error code returned from getValidationError - see readme
            var errorMap = ["☓ رقم غير صالح", "☓ رمز البلد غير صالح", "☓ قصير جدا", "☓ طويل جدا", "☓ رقم غير صالح"];

            // initialise plugin
            var iti = window.intlTelInput(input, {
                initialCountry: "auto",
                geoIpLookup: function(callback) {
                    $.get('https://ipinfo.io', function() {}, "jsonp").always(function(resp) {
                        var countryCode = (resp && resp.country) ? resp.country : "";
                        callback(countryCode);
                    });
                },
                utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/16.0.0/js/utils.js"
            });

            var reset = function() {
                input.classList.remove("error");
                errorMsg.innerHTML = "";
                errorMsg.classList.add("hide");
                validMsg.classList.add("hide");
            };

            // on blur: validate
            input.addEventListener('blur', function() {
                reset();
                if (input.value.trim()) {
                    if (iti.isValidNumber()) {
                        validMsg.classList.remove("hide");
                    } else {
                        input.classList.add("error");
                        var errorCode = iti.getValidationError();
                        errorMsg.innerHTML = errorMap[errorCode];
                        errorMsg.classList.remove("hide");
                    }
                }
            });

            // on keyup / change flag: reset
            input.addEventListener('change', reset);
            input.addEventListener('keyup', reset);

            $('#add_customer_submit').click(function() {
                $("#add_customer_store").ajaxForm({
                    url: '{{ url('admin/ajax/add_customer') }}', type: 'post',
                    beforeSubmit: function (response) {
                        if(iti.isValidNumber() == false) {
                            alert("Please check your phone again");
                            return false;
                        }
                    },
                    success: function (response) {
                        $('#addclient').modal('toggle');

                        $("#customers").append("<option selected value='" + response.data.id + "'>" + @if(app()->getLocale() == 'ar') response.data.name
                        @else response.data.name_en @endif + "</option>"
                    );
                    },
                    error: function (response) {
                        alert("Please check your entry date again");
                    }
                })
            });
        });

    </script>
@endsection
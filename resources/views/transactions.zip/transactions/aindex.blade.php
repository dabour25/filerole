@extends('layouts.admin', ['title' => __('strings.transactions_list') ])

@section('content')
    <style>
        .dataTables_scrollBody {
            overflow: visible !important;
        }
        .dataTables_scrollBody .dropdown-content {
            left: 0;
            right: auto;
        }
        .dataTables_scrollBody .dropdown-content span {
            font-size: 18px;
        }
        @media (max-width:767px) {
            .dataTables_scrollBody {
                overflow: auto !important;
            }
            .tab-content {
                padding: 0;
                background: #fff;
            }
        }

        /* Dropdown Button */
        .dropbtn {
            background-color: #4CAF50;
            color: white;
            padding: 16px;
            font-size: 16px;
            border: none;
        }

        /* The container <div> - needed to position the dropdown content */
        .dropdown {
            position: relative;
            display: inline-block;
        }

        /* Dropdown Content (Hidden by Default) */
        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f1f1f1;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
        }

        /* Links inside the dropdown */
        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }

        /* Change color of dropdown links on hover */
        .dropdown-content a:hover {background-color: #ddd;}

        /* Show the dropdown menu on hover */
        .dropdown:hover .dropdown-content {display: block;}

        /* Change the background color of the dropdown button when the dropdown content is shown */
        .dropdown:hover .dropbtn {background-color: #3e8e41;}
        .add-service {
            float: right !important;
            background-color: #00e3f2;
        }

    </style>
    <!--<div class="page-title">-->
    <!--    <h3>@lang('strings.transactions_list')</h3>-->
    <!--    <div class="page-breadcrumb">-->
    <!--        <ol class="breadcrumb">-->
    <!--            <li><a href="{{ route('home') }}">@lang('strings.Home')</a></li>-->
    <!--            <li class="active">@lang('strings.transactions_list')</li>-->
    <!--        </ol>-->
    <!--    </div>-->
    <!--</div>-->

    <div id="main-wrapper">
        <div class="row">
            <div class="col-md-12">
                @include('alerts.index')
                <a class="btn btn-primary btn-lg btn-add" href="{{ route('transactions.create') }}" ><i class="fa fa-plus"></i>&nbsp;&nbsp;@lang('strings.transactions_add')</a>
                <a class="btn btn-primary btn-lg btn-add" href="{{ url('admin/search') }}"><i class="fa fa-search"></i>&nbsp;&nbsp;@lang('strings.Search')</a>

                <div role="tabpanel">
                    <div class="panel panel-white">
                        <div class="panel-heading clearfix">
                            <h4 class="panel-title">@lang('strings.transactions_list')</h4>
                        </div>
                        <div class="panel-body">

                            <table id="xtreme-table" class="display table" style="width: 100%; cellspacing: 0;">
                                <thead>
                                <tr>
                                    <th>@lang('strings.transactions_id')</th>
                                    <th>@lang('strings.invoice_id')</th>
                                    <th>@lang('strings.Client_name')</th>
                                    <th>@lang('strings.transactions_date')</th>
                                    <th>@lang('strings.Total')</th>
                                    <th>@lang('strings.Paid')</th>
                                    <th>@lang('strings.Refund')</th>
                                    <th>@lang('strings.Remaining')</th>
                                    <th>@lang('strings.Settings')</th>
                                </tr>
                                </thead>
                                <tbody>
                                @foreach($list as $value)
                                    <tr>
                                        <td>{{ $value->id }}</td>
                                        <td>{{ $value->invoice_no }}</td>
                                        <td>{{ app()->getLocale() == 'ar' ? $value->customer->name : $value->customer->name_en }}</td>
                                        <td>{{ $value->date }}</td>

                                        <td>{{ round(abs($value->transactions->sum('price')), 2) }}</td>
                                        <td>{{ round(App\PermissionReceivingPayments::where(['customer_req_id' =>  $value->id,'customer_id' => $value->cust_id, 'pay_flag' => 1])->sum('pay_amount'), 2) }}</td>
                                        <td>{{ round(App\PermissionReceivingPayments::where(['customer_req_id' =>  $value->id,'customer_id' => $value->cust_id, 'pay_flag' => -1])->sum('pay_amount'), 2) }}</td>
                                        <td>{{ round(($value->transactions->where('status', 1)->where('req_flag', -1)->sum('price') - $value->transactions->sum('price')) - (App\PermissionReceivingPayments::where(['customer_req_id' =>  $value->id,'customer_id' => $value->cust_id, 'pay_flag' => 1])->sum('pay_amount') - App\PermissionReceivingPayments::where(['customer_req_id' =>  $value->id,'customer_id' => $value->cust_id, 'pay_flag' => -1])->sum('pay_amount')), 2) }}</td>

                                        {{--<td>{{ abs($value->transactions->where('status', 1)->where('req_flag', -1)->sum('price')) }}</td>--}}
                                        {{--<td>{{ $value->transactions->where('status', 1)->where('req_flag', -1)->sum('price') - $value->transactions->sum('price') }}</td>--}}

                                        <td>
                                            <a href="{{ route('transactions.edit', $value->id) }}" class="btn btn-primary btn-xs" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="عرض الطلب"><i class="fa fa-search"></i></a>
                                            <a href="{{ url('admin/transactions/'.$value->id.'/print') }}" class="btn btn-primary btn-xs" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="الفاتورة"><i class="fa fa-print"></i></a>
                                            <a href="{{ url('admin/transactions/paid', $value->id) }}" class="btn btn-primary btn-xs" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="دفع"><i class="fa fa-money"></i></a>
                                            <button class="btn btn-primary btn-xs dropdown">
                                                <i class="fa fa-globe"></i>
                                                <div class="dropdown-content">
                                                    <a href="https://www.facebook.com/sharer/sharer.php?u={{ url('invoice/'.$value->id) }}&amp;title=share code is {{ $value->share_code }}" target="_blank" class="social-button " id=""><span class="fa fa-facebook-official"></span></a>
                                                    <a href="https://twitter.com/intent/tweet?text=share code is {{ $value->share_code }}&amp;url={{ url('invoice/'.$value->id) }}"  target="_blank" class="social-button " id=""><span class="fa fa-twitter"></span></a>
                                                    <a href="https://plus.google.com/share?url={{ url('invoice/'.$value->id) }}" class="social-button " target="_blank" id=""><span class="fa fa-google-plus"></span></a>
                                                    <a href="http://www.linkedin.com/shareArticle?mini=true&amp;url={{ url('invoice/'.$value->id) }}&amp;title=share code is {{ $value->share_code }}" target="_blank" class="social-button " id=""><span class="fa fa-linkedin"></span></a>
                                                    <a href="https://wa.me/?text={{ url('invoice/'.$value->id) }}  share code is {{ $value->share_code }}" class="social-button" target="_blank" id=""><span class="fa fa-whatsapp"></span></a>
                                                </div>
                                            </button>
                                        </td>
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                            {{ $list->links() }}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


@endsection
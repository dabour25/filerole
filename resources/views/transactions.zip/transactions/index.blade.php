@extends('layouts.admin', ['title' => __('strings.transactions_list') ])

@section('content')
    <style>
        .dataTables_scrollBody {
            overflow: visible !important;
        }

        .dataTables_scrollBody .dropdown-content {
            left: 0;
            right: auto;
        }

        .dataTables_scrollBody .dropdown-content span {
            font-size: 18px;
        }

        @media (max-width: 767px) {
            .dataTables_scrollBody {
                overflow: auto !important;
            }

            .tab-content {
                padding: 0;
                background: #fff;
            }
        }

        /* Dropdown Button */
        .dropbtn {
            background-color: #4CAF50;
            color: white;
            padding: 16px;
            font-size: 16px;
            border: none;
        }

        /* The container <div> - needed to position the dropdown content */
        .dropdown {
            position: relative;
            display: inline-block;
        }

        /* Dropdown Content (Hidden by Default) */
        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f1f1f1;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
            z-index: 1;
        }

        /* Links inside the dropdown */
        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }

        /* Change color of dropdown links on hover */
        .dropdown-content a:hover {
            background-color: #ddd;
        }

        /* Show the dropdown menu on hover */
        .dropdown:hover .dropdown-content {
            display: block;
        }

        /* Change the background color of the dropdown button when the dropdown content is shown */
        .dropdown:hover .dropbtn {
            background-color: #3e8e41;
        }

        .add-service {
            float: right !important;
            background-color: #00e3f2;
        }
    </style>
    <div id="main-wrapper">
        <div class="row">
            <div class="col-md-12">
                @include('alerts.index')

                @if (permissions('transactions_add') == 1)
                    <a class="btn btn-primary btn-lg btn-add" href="{{ route('transactions.create') }}"><i
                                class="fa fa-plus"></i>&nbsp;&nbsp;@lang('strings.transactions_add')</a>
                @endif

                @if (permissions('transactions_search') == 1)
                    <a class="btn btn-primary btn-lg btn-add" href="{{ url('admin/search') }}"><i
                                class="fa fa-search"></i>&nbsp;&nbsp;@lang('strings.Search')</a>
                @endif
                <div role="tabpanel">

                    <!-- Tab panes -->
                    <div class="tab-content">
                        <!-- Nav tabs -->
                        <ul class="nav nav-pills" role="tablist">
                            <li role="presentation" class="active"><a href="#status-1" role="tab" data-toggle="tab"><i
                                            class="icon-basket"></i>&nbsp;&nbsp;@lang('strings.transactions_status_1')
                                </a></li>
                            <li role="presentation"><a href="#status-2" role="tab" data-toggle="tab"><i
                                            class="icon-basket"></i>&nbsp;&nbsp;@lang('strings.transactions_status_2')
                                </a></li>
                            <li role="presentation"><a href="#status-3" role="tab" data-toggle="tab"><i
                                            class="icon-basket"></i>&nbsp;&nbsp;@lang('strings.transactions_status_3')
                                </a></li>
                            <li role="presentation"><a href="#status-4" role="tab" data-toggle="tab"><i
                                            class="icon-basket"></i>&nbsp;&nbsp;@lang('strings.transactions_status_4')
                                </a></li>
                            <li role="presentation"><a href="#status-5" role="tab" data-toggle="tab"><i
                                            class="icon-basket"></i>&nbsp;&nbsp;@lang('strings.transactions_status_5')
                                </a></li>
                        </ul>
                        <div role="tabpanel" class="tab-pane active fade in" id="status-1">
                            <div class="panel panel-white">
                                <div class="panel-heading clearfix">
                                    <h4 class="panel-title">{{ __('strings.transactions_list') }}</h4>
                                </div>
                                <div class="panel-body">
                                    <table id="" class="display table">
                                        <thead>
                                        <tr>
                                            <th>@lang('strings.transactions_id')</th>
                                            <th>@lang('strings.invoice_id')</th>
                                            <th>@lang('strings.Client_name')</th>
                                            <th>@lang('strings.transactions_date')</th>
                                            <th>@lang('strings.Total')</th>
                                            <th>@lang('strings.Paid')</th>
                                            <th>@lang('strings.Refund')</th>
                                            <th>@lang('strings.Remaining')</th>
                                            @if (permissions('transactions_edit') == 1 || permissions('transactions_paid') == 1 || permissions('transactions_share') == 1)
                                                <th>@lang('strings.Settings')</th>
                                            @endif
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach($list->where('invoice_status', 1) as $value)
                                            <tr>
                                                <td>{{ $value->id }}</td>
                                                <td>{{ $value->invoice_code.' '.$value->invoice_no }}</td>
                                                <td>{{ app()->getLocale() == 'ar' ? $value->customer->name : $value->customer->name_en }}</td>
                                                <td>{{ Dateformat($value->date) }}</td>
                                                @php
                                                    $x1 = abs($value->transactions->sum('price'));
                                                    $x2 = App\PermissionReceivingPayments::where(['customer_req_id' =>  $value->id,'customer_id' => $value->cust_id, 'pay_flag' => 1])->sum('pay_amount');
                                                    $x3 = App\PermissionReceivingPayments::where(['customer_req_id' =>  $value->id,'customer_id' => $value->cust_id, 'pay_flag' => -1])->sum('pay_amount');
                                                @endphp
                                                <td>{{ Decimalplace($x1) }}</td>
                                                <td>{{ Decimalplace($x2) }}</td>
                                                <td>{{ Decimalplace($x3) }}</td>
                                                <td>{{ Decimalplace(($x1 - $x2) + $x3) }}</td>

                                                {{--<td>{{ abs($value->transactions->where('status', 1)->where('req_flag', -1)->sum('price')) }}</td>--}}
                                                {{--<td>{{ $value->transactions->where('status', 1)->where('req_flag', -1)->sum('price') - $value->transactions->sum('price') }}</td>--}}
                                                @if (permissions('transactions_edit') == 1 || permissions('transactions_paid') == 1 || permissions('transactions_share') == 1)
                                                    <td>
                                                        @if(permissions('transactions_edit') == 1)
                                                            <a href="{{ route('transactions.edit', $value->id) }}"
                                                               class="btn btn-primary btn-xs" data-toggle="tooltip"
                                                               data-placement="bottom" title=""
                                                               data-original-title="{{ __('strings.show_reg') }} "><i
                                                                        class="fa fa-search"></i></a>
                                                            <a href="{{ url('admin/transactions/'.$value->id.'/print') }}"
                                                               class="btn btn-primary btn-xs" data-toggle="tooltip"
                                                               data-placement="bottom" title=""
                                                               data-original-title="{{ __('strings.invoice') }}"><i
                                                                        class="fa fa-print"></i></a>
                                                        @endif
                                                        @if(permissions('transactions_paid') == 1)
                                                            <a href="{{ url('admin/transactions/paid', $value->id) }}"
                                                               class="btn btn-primary btn-xs" data-toggle="tooltip"
                                                               data-placement="bottom" title=""
                                                               data-original-title="{{ __('strings.Pay') }}"><i class="fa fa-money"></i></a>
                                                        @endif
                                                        @if(permissions('transactions_share') == 1)
                                                            <button class="btn btn-primary btn-xs dropdown">
                                                                <i class="fa fa-globe"></i>
                                                                <div class="dropdown-content">
                                                                    <a href="https://www.facebook.com/sharer/sharer.php?u={{ url('invoice/'.$value->id) }}&amp;title=share code is {{ $value->share_code }}"
                                                                       target="_blank" class="social-button "
                                                                       id=""><span
                                                                                class="fa fa-facebook-official"></span></a>
                                                                    <a href="https://twitter.com/intent/tweet?text=share code is {{ $value->share_code }}&amp;url={{ url('invoice/'.$value->id) }}"
                                                                       target="_blank" class="social-button "
                                                                       id=""><span class="fa fa-twitter"></span></a>
                                                                    <a href="https://plus.google.com/share?url={{ url('invoice/'.$value->id) }}"
                                                                       class="social-button " target="_blank"
                                                                       id=""><span class="fa fa-google-plus"></span></a>
                                                                    <a href="http://www.linkedin.com/shareArticle?mini=true&amp;url={{ url('invoice/'.$value->id) }}&amp;title=share code is {{ $value->share_code }}"
                                                                       target="_blank" class="social-button "
                                                                       id=""><span class="fa fa-linkedin"></span></a>
                                                                    <a href="https://web.whatsapp.com/send?phone={{ $value->customer->phone_number }}&text={{ url('invoice/'.$value->id) }}  share code is {{ $value->share_code }}"
                                                                       class="social-button" target="_blank" id=""><span
                                                                                class="fa fa-whatsapp"></span></a>
                                                                </div>
                                                            </button>
                                                        @endif
                                                    </td>
                                                @endif
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                    {{ $list->links() }}
                                </div>
                            </div>
                        </div>
                        <div role="tabpanel" class="tab-pane fade in" id="status-2">
                            <div class="panel panel-white">
                                <div class="panel-heading clearfix">
                                    <h4 class="panel-title">{{ __('strings.transactions_list') }}</h4>
                                </div>
                                <div class="panel-body">
                                    <table id="" class="display table">
                                        <thead>
                                            <tr>
                                                <th>@lang('strings.transactions_id')</th>
                                                <th>@lang('strings.invoice_id')</th>
                                                <th>@lang('strings.Client_name')</th>
                                                <th>@lang('strings.transactions_date')</th>
                                                <th>@lang('strings.Total')</th>
                                                <th>@lang('strings.Paid')</th>
                                                <th>@lang('strings.Refund')</th>
                                                <th>@lang('strings.Remaining')</th>
                                                @if (permissions('transactions_edit') == 1 || permissions('transactions_paid') == 1 || permissions('transactions_share') == 1)
                                                    <th>@lang('strings.Settings')</th>
                                                @endif
                                            </tr>
                                        </thead>
                                        <tbody>
                                        @foreach($list->where('invoice_status', 3) as $value)
                                            <tr>
                                                <td>{{ $value->id }}</td>
                                                <td>{{ $value->invoice_code.' '.$value->invoice_no }}</td>
                                                <td>{{ app()->getLocale() == 'ar' ? $value->customer->name : $value->customer->name_en }}</td>
                                                <td>{{ Dateformat($value->date) }}</td>
                                                @php
                                                    $x1 = abs($value->transactions->sum('price'));
                                                    $x2 = App\PermissionReceivingPayments::where(['customer_req_id' =>  $value->id,'customer_id' => $value->cust_id, 'pay_flag' => 1])->sum('pay_amount');
                                                    $x3 = App\PermissionReceivingPayments::where(['customer_req_id' =>  $value->id,'customer_id' => $value->cust_id, 'pay_flag' => -1])->sum('pay_amount');
                                                @endphp
                                                <td>{{ Decimalplace($x1) }}</td>
                                                <td>{{ Decimalplace($x2) }}</td>
                                                <td>{{ Decimalplace($x3) }}</td>
                                                <td>{{ Decimalplace(($x1 - $x2) + $x3) }}</td>

                                                {{--<td>{{ abs($value->transactions->where('status', 1)->where('req_flag', -1)->sum('price')) }}</td>--}}
                                                {{--<td>{{ $value->transactions->where('status', 1)->where('req_flag', -1)->sum('price') - $value->transactions->sum('price') }}</td>--}}

                                                @if (permissions('transactions_edit') == 1 || permissions('transactions_paid') == 1 || permissions('transactions_share') == 1)
                                                    <td>
                                                        @if(permissions('transactions_edit') == 1)
                                                            <a href="{{ route('transactions.edit', $value->id) }}"
                                                               class="btn btn-primary btn-xs" data-toggle="tooltip"
                                                               data-placement="bottom" title=""
                                                               data-original-title="{{ __('strings.show_reg') }} "><i
                                                                        class="fa fa-search"></i></a>
                                                            <a href="{{ url('admin/transactions/'.$value->id.'/print') }}"
                                                               class="btn btn-primary btn-xs" data-toggle="tooltip"
                                                               data-placement="bottom" title=""
                                                               data-original-title="{{ __('strings.invoice') }}"><i
                                                                        class="fa fa-print"></i></a>
                                                        @endif
                                                        @if(permissions('transactions_paid') == 1)
                                                            <a href="{{ url('admin/transactions/paid', $value->id) }}"
                                                               class="btn btn-primary btn-xs" data-toggle="tooltip"
                                                               data-placement="bottom" title=""
                                                               data-original-title="{{ __('strings.Pay') }}"><i class="fa fa-money"></i></a>
                                                        @endif
                                                        @if(permissions('transactions_share') == 1)
                                                            <button class="btn btn-primary btn-xs dropdown">
                                                                <i class="fa fa-globe"></i>
                                                                <div class="dropdown-content">
                                                                    <a href="https://www.facebook.com/sharer/sharer.php?u={{ url('invoice/'.$value->id) }}&amp;title=share code is {{ $value->share_code }}"
                                                                       target="_blank" class="social-button "
                                                                       id=""><span
                                                                                class="fa fa-facebook-official"></span></a>
                                                                    <a href="https://twitter.com/intent/tweet?text=share code is {{ $value->share_code }}&amp;url={{ url('invoice/'.$value->id) }}"
                                                                       target="_blank" class="social-button "
                                                                       id=""><span class="fa fa-twitter"></span></a>
                                                                    <a href="https://plus.google.com/share?url={{ url('invoice/'.$value->id) }}"
                                                                       class="social-button " target="_blank"
                                                                       id=""><span class="fa fa-google-plus"></span></a>
                                                                    <a href="http://www.linkedin.com/shareArticle?mini=true&amp;url={{ url('invoice/'.$value->id) }}&amp;title=share code is {{ $value->share_code }}"
                                                                       target="_blank" class="social-button "
                                                                       id=""><span class="fa fa-linkedin"></span></a>
                                                                    <a href="https://web.whatsapp.com/send?phone={{ $value->customer->phone_number }}&text={{ url('invoice/'.$value->id) }}  share code is {{ $value->share_code }}"
                                                                       class="social-button" target="_blank" id=""><span
                                                                                class="fa fa-whatsapp"></span></a>
                                                                </div>
                                                            </button>
                                                        @endif
                                                    </td>
                                                @endif
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                    {{ $list->links() }}
                                </div>
                            </div>
                        </div>
                        <div role="tabpanel" class="tab-pane fade in" id="status-3">
                            <div class="panel panel-white">
                                <div class="panel-heading clearfix">
                                    <h4 class="panel-title">{{ __('strings.transactions_list') }}</h4>
                                </div>
                                <div class="panel-body">
                                    <table id="" class="display table">
                                        <thead>
                                        <tr>
                                            <th>@lang('strings.transactions_id')</th>
                                            <th>@lang('strings.invoice_id')</th>
                                            <th>@lang('strings.Client_name')</th>
                                            <th>@lang('strings.transactions_date')</th>
                                            <th>@lang('strings.Total')</th>
                                            <th>@lang('strings.Paid')</th>
                                            <th>@lang('strings.Refund')</th>
                                            <th>@lang('strings.Remaining')</th>
                                            @if (permissions('transactions_edit') == 1 || permissions('transactions_paid') == 1 || permissions('transactions_share') == 1)
                                                <th>@lang('strings.Settings')</th>
                                            @endif
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach($list->where('invoice_status', 0)  as $value)
                                            <tr>
                                                <td>{{ $value->id }}</td>
                                                <td>{{ $value->invoice_code.' '.$value->invoice_no }}</td>
                                                <td>{{ app()->getLocale() == 'ar' ? $value->customer->name : $value->customer->name_en }}</td>
                                                <td>{{ Dateformat($value->date) }}</td>
                                                @php
                                                    $x1 = abs($value->transactions->sum('price'));
                                                    $x2 = App\PermissionReceivingPayments::where(['customer_req_id' =>  $value->id,'customer_id' => $value->cust_id, 'pay_flag' => 1])->sum('pay_amount');
                                                    $x3 = App\PermissionReceivingPayments::where(['customer_req_id' =>  $value->id,'customer_id' => $value->cust_id, 'pay_flag' => -1])->sum('pay_amount');
                                                @endphp
                                                <td>{{ Decimalplace($x1) }}</td>
                                                <td>{{ Decimalplace($x2) }}</td>
                                                <td>{{ Decimalplace($x3) }}</td>
                                                <td>{{ Decimalplace(($x1 - $x2) + $x3) }}</td>

                                                {{--<td>{{ abs($value->transactions->where('status', 1)->where('req_flag', -1)->sum('price')) }}</td>--}}
                                                {{--<td>{{ $value->transactions->where('status', 1)->where('req_flag', -1)->sum('price') - $value->transactions->sum('price') }}</td>--}}

                                                @if (permissions('transactions_edit') == 1 || permissions('transactions_paid') == 1 || permissions('transactions_share') == 1)
                                                    <td>
                                                        @if(permissions('transactions_edit') == 1)
                                                            <a href="{{ route('transactions.edit', $value->id) }}"
                                                               class="btn btn-primary btn-xs" data-toggle="tooltip"
                                                               data-placement="bottom" title=""
                                                               data-original-title="{{ __('strings.show_reg') }}"><i
                                                                        class="fa fa-search"></i></a>
                                                            <a href="{{ url('admin/transactions/'.$value->id.'/print') }}"
                                                               class="btn btn-primary btn-xs" data-toggle="tooltip"
                                                               data-placement="bottom" title=""
                                                               data-original-title="{{ __('strings.invoice') }}"><i
                                                                        class="fa fa-print"></i></a>
                                                        @endif
                                                        @if(permissions('transactions_paid') == 1)
                                                            <a href="{{ url('admin/transactions/paid', $value->id) }}"
                                                               class="btn btn-primary btn-xs" data-toggle="tooltip"
                                                               data-placement="bottom" title=""
                                                               data-original-title="{{ __('strings.Pay') }}"><i class="fa fa-money"></i></a>
                                                        @endif
                                                        @if(permissions('transactions_share') == 1)
                                                            <button class="btn btn-primary btn-xs dropdown">
                                                                <i class="fa fa-globe"></i>
                                                                <div class="dropdown-content">
                                                                    <a href="https://www.facebook.com/sharer/sharer.php?u={{ url('invoice/'.$value->id) }}&amp;title=share code is {{ $value->share_code }}"
                                                                       target="_blank" class="social-button "
                                                                       id=""><span
                                                                                class="fa fa-facebook-official"></span></a>
                                                                    <a href="https://twitter.com/intent/tweet?text=share code is {{ $value->share_code }}&amp;url={{ url('invoice/'.$value->id) }}"
                                                                       target="_blank" class="social-button "
                                                                       id=""><span class="fa fa-twitter"></span></a>
                                                                    <a href="https://plus.google.com/share?url={{ url('invoice/'.$value->id) }}"
                                                                       class="social-button " target="_blank"
                                                                       id=""><span class="fa fa-google-plus"></span></a>
                                                                    <a href="http://www.linkedin.com/shareArticle?mini=true&amp;url={{ url('invoice/'.$value->id) }}&amp;title=share code is {{ $value->share_code }}"
                                                                       target="_blank" class="social-button "
                                                                       id=""><span class="fa fa-linkedin"></span></a>
                                                                    <a href="https://web.whatsapp.com/send?phone={{ $value->customer->phone_number }}&text={{ url('invoice/'.$value->id) }}  share code is {{ $value->share_code }}"
                                                                       class="social-button" target="_blank" id=""><span
                                                                                class="fa fa-whatsapp"></span></a>
                                                                </div>
                                                            </button>
                                                        @endif
                                                    </td>
                                                @endif
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                    {{ $list->links() }}
                                </div>
                            </div>
                        </div>
                        <div role="tabpanel" class="tab-pane fade in" id="status-4">
                            <div class="panel panel-white">
                                <div class="panel-heading clearfix">
                                    <h4 class="panel-title">{{ __('strings.transactions_list') }}</h4>
                                </div>
                                <div class="panel-body">
                                    <table id="" class="display table">
                                        <thead>
                                        <tr>
                                            <th>@lang('strings.transactions_id')</th>
                                            <th>@lang('strings.invoice_id')</th>
                                            <th>@lang('strings.Client_name')</th>
                                            <th>@lang('strings.transactions_date')</th>
                                            <th>@lang('strings.Total')</th>
                                            <th>@lang('strings.Paid')</th>
                                            <th>@lang('strings.Refund')</th>
                                            <th>@lang('strings.Remaining')</th>
                                            @if (permissions('transactions_edit') == 1 || permissions('transactions_paid') == 1 || permissions('transactions_share') == 1)
                                                <th>@lang('strings.Settings')</th>
                                            @endif
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach($list->where('invoice_status', 2) as $value)
                                            <tr>
                                                <td>{{ $value->id }}</td>
                                                <td>{{ $value->invoice_code.' '.$value->invoice_no }}</td>
                                                <td>{{ app()->getLocale() == 'ar' ? $value->customer->name : $value->customer->name_en }}</td>
                                                <td>{{ Dateformat($value->date) }}</td>
                                                @php
                                                    $x1 = abs($value->transactions->sum('price'));
                                                    $x2 = App\PermissionReceivingPayments::where(['customer_req_id' =>  $value->id,'customer_id' => $value->cust_id, 'pay_flag' => 1])->sum('pay_amount');
                                                    $x3 = App\PermissionReceivingPayments::where(['customer_req_id' =>  $value->id,'customer_id' => $value->cust_id, 'pay_flag' => -1])->sum('pay_amount');
                                                @endphp
                                                <td>{{ Decimalplace($x1) }}</td>
                                                <td>{{ Decimalplace($x2) }}</td>
                                                <td>{{ Decimalplace($x3) }}</td>
                                                <td>{{ Decimalplace(($x1 - $x2) + $x3) }}</td>

                                                {{--<td>{{ abs($value->transactions->where('status', 1)->where('req_flag', -1)->sum('price')) }}</td>--}}
                                                {{--<td>{{ $value->transactions->where('status', 1)->where('req_flag', -1)->sum('price') - $value->transactions->sum('price') }}</td>--}}

                                                @if (permissions('transactions_edit') == 1 || permissions('transactions_paid') == 1 || permissions('transactions_share') == 1)
                                                    <td>
                                                        @if(permissions('transactions_edit') == 1)
                                                            <a href="{{ route('transactions.edit', $value->id) }}"
                                                               class="btn btn-primary btn-xs" data-toggle="tooltip"
                                                               data-placement="bottom" title=""
                                                               data-original-title="{{ __('strings.show_reg') }}"><i
                                                                        class="fa fa-search"></i></a>
                                                            <a href="{{ url('admin/transactions/'.$value->id.'/print') }}"
                                                               class="btn btn-primary btn-xs" data-toggle="tooltip"
                                                               data-placement="bottom" title=""
                                                               data-original-title="{{ __('strings.invoice') }}"><i
                                                                        class="fa fa-print"></i></a>
                                                        @endif
                                                        @if(permissions('transactions_paid') == 1)
                                                            <a href="{{ url('admin/transactions/paid', $value->id) }}"
                                                               class="btn btn-primary btn-xs" data-toggle="tooltip"
                                                               data-placement="bottom" title=""
                                                               data-original-title="{{ __('strings.Pay') }}"><i class="fa fa-money"></i></a>
                                                        @endif
                                                        @if(permissions('transactions_share') == 1)
                                                            <button class="btn btn-primary btn-xs dropdown">
                                                                <i class="fa fa-globe"></i>
                                                                <div class="dropdown-content">
                                                                    <a href="https://www.facebook.com/sharer/sharer.php?u={{ url('invoice/'.$value->id) }}&amp;title=share code is {{ $value->share_code }}"
                                                                       target="_blank" class="social-button "
                                                                       id=""><span
                                                                                class="fa fa-facebook-official"></span></a>
                                                                    <a href="https://twitter.com/intent/tweet?text=share code is {{ $value->share_code }}&amp;url={{ url('invoice/'.$value->id) }}"
                                                                       target="_blank" class="social-button "
                                                                       id=""><span class="fa fa-twitter"></span></a>
                                                                    <a href="https://plus.google.com/share?url={{ url('invoice/'.$value->id) }}"
                                                                       class="social-button " target="_blank"
                                                                       id=""><span class="fa fa-google-plus"></span></a>
                                                                    <a href="http://www.linkedin.com/shareArticle?mini=true&amp;url={{ url('invoice/'.$value->id) }}&amp;title=share code is {{ $value->share_code }}"
                                                                       target="_blank" class="social-button "
                                                                       id=""><span class="fa fa-linkedin"></span></a>
                                                                    <a href="https://web.whatsapp.com/send?phone={{ $value->customer->phone_number }}&text={{ url('invoice/'.$value->id) }}  share code is {{ $value->share_code }}"
                                                                       class="social-button" target="_blank" id=""><span
                                                                                class="fa fa-whatsapp"></span></a>
                                                                </div>
                                                            </button>
                                                        @endif
                                                    </td>
                                                @endif
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                    {{ $list->links() }}
                                </div>
                            </div>
                        </div>
                        <div role="tabpanel" class="tab-pane fade in" id="status-5">
                            <div class="panel panel-white">
                                <div class="panel-heading clearfix">
                                    <h4 class="panel-title">{{ __('strings.transactions_list') }}</h4>
                                </div>
                                <div class="panel-body">
                                    <table id="" class="display table">
                                        <thead>
                                        <tr>
                                            <th>@lang('strings.transactions_id')</th>
                                            <th>@lang('strings.invoice_id')</th>
                                            <th>@lang('strings.Client_name')</th>
                                            <th>@lang('strings.transactions_date')</th>
                                            <th>@lang('strings.Total')</th>
                                            <th>@lang('strings.Paid')</th>
                                            <th>@lang('strings.Refund')</th>
                                            <th>@lang('strings.Remaining')</th>
                                            @if (permissions('transactions_edit') == 1 || permissions('transactions_paid') == 1 || permissions('transactions_share') == 1)
                                                <th>@lang('strings.Settings')</th>
                                            @endif
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach($list->where('invoice_status', 4) as $value)
                                            <tr>
                                                <td>{{ $value->id }}</td>
                                                <td>{{ $value->invoice_code.' '.$value->invoice_no }}</td>
                                                <td>{{ app()->getLocale() == 'ar' ? $value->customer->name : $value->customer->name_en }}</td>
                                                <td>{{ Dateformat($value->date) }}</td>
                                                @php
                                                    $x1 = abs($value->transactions->sum('price'));
                                                    $x2 = App\PermissionReceivingPayments::where(['customer_req_id' =>  $value->id,'customer_id' => $value->cust_id, 'pay_flag' => 1])->sum('pay_amount');
                                                    $x3 = App\PermissionReceivingPayments::where(['customer_req_id' =>  $value->id,'customer_id' => $value->cust_id, 'pay_flag' => -1])->sum('pay_amount');
                                                @endphp
                                                <td>{{ Decimalplace($x1) }}</td>
                                                <td>{{ Decimalplace($x2) }}</td>
                                                <td>{{ Decimalplace($x3) }}</td>
                                                <td>{{ Decimalplace(($x1 - $x2) + $x3) }}</td>

                                                {{--<td>{{ abs($value->transactions->where('status', 1)->where('req_flag', -1)->sum('price')) }}</td>--}}
                                                {{--<td>{{ $value->transactions->where('status', 1)->where('req_flag', -1)->sum('price') - $value->transactions->sum('price') }}</td>--}}

                                                @if (permissions('transactions_edit') == 1 || permissions('transactions_paid') == 1 || permissions('transactions_share') == 1)
                                                    <td>
                                                        @if(permissions('transactions_edit') == 1)
                                                            <a href="{{ route('transactions.edit', $value->id) }}"
                                                               class="btn btn-primary btn-xs" data-toggle="tooltip"
                                                               data-placement="bottom" title=""
                                                               data-original-title="{{ __('strings.show_reg') }}"><i
                                                                        class="fa fa-search"></i></a>
                                                            <a href="{{ url('admin/transactions/'.$value->id.'/print') }}"
                                                               class="btn btn-primary btn-xs" data-toggle="tooltip"
                                                               data-placement="bottom" title=""
                                                               data-original-title="{{ __('strings.invoice') }}"><i
                                                                        class="fa fa-print"></i></a>
                                                        @endif
                                                        @if(permissions('transactions_paid') == 1)
                                                            <a href="{{ url('admin/transactions/paid', $value->id) }}"
                                                               class="btn btn-primary btn-xs" data-toggle="tooltip"
                                                               data-placement="bottom" title=""
                                                               data-original-title="{{ __('strings.Pay') }}"><i class="fa fa-money"></i></a>
                                                        @endif
                                                        @if(permissions('transactions_share') == 1)
                                                            <button class="btn btn-primary btn-xs dropdown">
                                                                <i class="fa fa-globe"></i>
                                                                <div class="dropdown-content">
                                                                    <a href="https://www.facebook.com/sharer/sharer.php?u={{ url('invoice/'.$value->id) }}&amp;title=share code is {{ $value->share_code }}"
                                                                       target="_blank" class="social-button "
                                                                       id=""><span
                                                                                class="fa fa-facebook-official"></span></a>
                                                                    <a href="https://twitter.com/intent/tweet?text=share code is {{ $value->share_code }}&amp;url={{ url('invoice/'.$value->id) }}"
                                                                       target="_blank" class="social-button "
                                                                       id=""><span class="fa fa-twitter"></span></a>
                                                                    <a href="https://plus.google.com/share?url={{ url('invoice/'.$value->id) }}"
                                                                       class="social-button " target="_blank"
                                                                       id=""><span class="fa fa-google-plus"></span></a>
                                                                    <a href="http://www.linkedin.com/shareArticle?mini=true&amp;url={{ url('invoice/'.$value->id) }}&amp;title=share code is {{ $value->share_code }}"
                                                                       target="_blank" class="social-button "
                                                                       id=""><span class="fa fa-linkedin"></span></a>
                                                                    <a href="https://web.whatsapp.com/send?phone={{ $value->customer->phone_number }}&text={{ url('invoice/'.$value->id) }}  share code is {{ $value->share_code }}"
                                                                       class="social-button" target="_blank" id=""><span
                                                                                class="fa fa-whatsapp"></span></a>
                                                                </div>
                                                            </button>
                                                        @endif
                                                    </td>
                                                @endif
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                    {{ $list->links() }}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


@endsection
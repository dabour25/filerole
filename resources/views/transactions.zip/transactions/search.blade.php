@extends('layouts.admin', ['title' => __('strings.Search')])

@section('content')

    <!--<div class="page-title">-->
    <!--    <h3> @lang('strings.Search')</h3>-->
    <!--    <div class="page-breadcrumb">-->
    <!--        <ol class="breadcrumb">-->
    <!--            <li><a href="{{ route('home') }}">@lang('strings.Home')</a></li>-->
    <!--            <li><a href="{{ route('transactions.index') }}">@lang('strings.transactions_list')</a></li>-->
    <!--            <li class="active">@lang('strings.Search')</li>-->
    <!--        </ol>-->
    <!--    </div>-->
    <!--</div>-->

    <div id="main-wrapper">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-white">
                    <div class="panel-body">

                        <form method="post" action="" enctype="multipart/form-data" id="add">
                            {{csrf_field()}}
                            <div class="row">

                                <div class="col-lg-3 col-md-4 col-sm-6 m-b-sm">
                                    <label>@lang('strings.Client_name')</label>
                                    <select class="form-control js-select" name="search_name">
                                        <option value="0">@lang('strings.Select_client')</option>
                                        @foreach(App\Customers::where(['active' => 1,'org_id' => Auth::user()->org_id])->get() as $role)
                                            <option {{ app('request')->input('search_name') == $role->id ? 'selected' : '' }} value="{{$role->id}}">{{ app()->getLocale() == 'ar' ? $role->name : $role->name_en }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="col-lg-3 col-md-4 col-sm-6 m-b-sm">
                                    <div class="input-group text">
                                        <label>@lang('strings.transactions_id')</label>
                                        <input name="search_request_id" type="number" style="" class="form-control" value="{{ app('request')->input('search_request_id') }}">
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-4 col-sm-6 m-b-sm">
                                    <div class="input-group text">
                                        <label>@lang('strings.invoice_id')</label>
                                        <input name="search_invoice_no" type="number" style="" class="form-control" value="{{ app('request')->input('search_invoice_no') }}">
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-4 col-sm-6 m-b-sm">
                                    <div class="input-group text">
                                        <label>@lang('strings.transactions_date')</label>
                                        <input name="search_date" type="date" style="" class="form-control" value="{{ app('request')->input('search_date') }}">
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-12 form-group text-right">
                                <button type="submit" class="btn btn-primary btn-lg">@lang('strings.Search')</button>
                            </div>


                        </form>
                    </div>
                </div>
            </div>
        </div>

        @if($list != null)
            <div class="row">
            <div class="col-md-12">
                <div class="panel panel-white">
                    <div class="panel-heading clearfix">
                        <h4 class="panel-title">@lang('strings.Customers')</h4>
                    </div>
                    <div class="panel-body">
                        <div class="table-responsive">
                            <table id="xtreme-table" class="display table" style="width: 100%; cellspacing: 0;">
                                <thead>
                                <tr>
                                    <th>@lang('strings.transactions_id')</th>
                                    <th>@lang('strings.invoice_id')</th>
                                    <th>@lang('strings.Client_name')</th>
                                    <th>@lang('strings.transactions_date')</th>
                                    <th>@lang('strings.Total')</th>
                                    <th>@lang('strings.Paid')</th>
                                    <th>@lang('strings.Refund')</th>
                                    <th>@lang('strings.Remaining')</th>
                                    <th>@lang('strings.Settings')</th>
                                </tr>
                                </thead>
                                <tbody>
                                @foreach($list as $value)
                                    <tr>
                                        <td>{{ $value->id }}</td>
                                        <td>{{ $value->invoice_no }}</td>
                                        <td>{{ app()->getLocale() == 'ar' ? $value->customer->name : $value->customer->name_en }}</td>
                                        <td>{{ Dateformat($value->date) }}</td>
                                        <td>{{ Decimalplace(abs($value->transactions->sum('price'))) }}</td>
                                        <td>{{ Decimalplace(App\PermissionReceivingPayments::where(['customer_req_id' =>  $value->id,'customer_id' => $value->cust_id, 'pay_flag' => 1])->sum('pay_amount')) }}</td>
                                        <td>{{ Decimalplace(App\PermissionReceivingPayments::where(['customer_req_id' =>  $value->id,'customer_id' => $value->cust_id, 'pay_flag' => -1])->sum('pay_amount')) }}</td>
                                        <td>{{ Decimalplace(($value->transactions->where('status', 1)->where('req_flag', -1)->sum('price') - $value->transactions->sum('price')) - (App\PermissionReceivingPayments::where(['customer_req_id' =>  $value->id,'customer_id' => $value->cust_id, 'pay_flag' => 1])->sum('pay_amount') - App\PermissionReceivingPayments::where(['customer_req_id' =>  $value->id,'customer_id' => $value->cust_id, 'pay_flag' => -1])->sum('pay_amount'))) }}</td>

                                        <td>
                                            <a href="{{ route('transactions.edit', $value->id) }}" class="btn btn-primary btn-xs"><i class="fa fa-search"></i></a>
                                        </td>
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                            {{ $list->links() }}
                        </div>
                    </div>
                </div>
            </div>
        </div>
        @endif
    </div>
    <!--begin::Modal-->
    <div class="modal fade" id="modal_view_password" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">
                        @lang('strings.Change_password')
                    </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">
                                &times;
                            </span>
                    </button>
                </div>
                <div class="modal-body">

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">
                        @lang('strings.Cancel')
                    </button>
                    <button type="button" class="btn btn-primary" onclick="document.forms['password'].submit(); return false;">
                        @lang('strings.Save')
                    </button>
                </div>
            </div>
        </div>
    </div>
    <!--end::Modal-->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
    <script>
        $('.js-select').select2({
            minimumInputLength: 2,
        });

        $( ".search-type" ).change(function() {
            if(this.value == 1) {
                $("#search-name").show();
                $( "#search-phone" ).hide();
                $( "#search-email" ).hide();
                $( "#search-code" ).hide();
            }else if(this.value == 2){
                $("#search-phone").show();
                $( "#search-name" ).hide();
                $( "#search-email" ).hide();
                $( "#search-code" ).hide();
            }else if(this.value == 3){
                $("#search-email").show();
                $( "#search-name" ).hide();
                $( "#search-phone" ).hide();
                $( "#search-code" ).hide();
            }else if(this.value == 4){
                $("#search-code").show();
                $( "#search-name" ).hide();
                $( "#search-phone" ).hide();
                $( "#search-email" ).hide();
            }else{
                $( "#search-name" ).hide();
                $( "#search-phone" ).hide();
                $( "#search-email" ).hide();
                $( "#search-code" ).hide();
            }
        });

        function _open(id, that) {
            $td_edit = $(that);
            jQuery('#modal_view_password .modal-body').html('<div style="text-align:center;margin-top:200px;"><img src="{{ asset('/lg.azure-round-loader.gif') }}" /></div>');
            // LOADING THE AJAX MODAL
            jQuery('#modal_view_password').modal('show', {backdrop: 'true'});
            // SHOW AJAX RESPONSE ON REQUEST SUCCESS
            $.ajax({
                url: "{{ url('admin/customers/') }}/" + id + '/change-password',
                success: function (response) {
                    jQuery('#modal_view_password .modal-body').html(response);
                }
            });
        }

        function _print(id, that) {
            window.open("{{ url('admin/customers/') }}/" + id + "/print", '_blank');
        }
    </script>
@endsection
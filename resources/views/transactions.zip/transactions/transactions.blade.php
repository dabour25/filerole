<div class="row clearfix" style="margin-top:20px">
    <div class="pull-left col-md-6">
        <table class="table table-bordered table-hover" id="tab_logic_total">
            <tbody>
            <tr>
                <th class="text-center">@lang('strings.Customer')</th>
                <td>
                    <input type="text" name="invoice_no" class="form-control"
                           value="{{ app()->getLocale() == 'ar' ? $list->customer->name : $list->customer->name_en }}" disabled>
                </td>
            </tr>
            <tr>
                <th class="text-center">@lang('strings.Invoice_date')</th>
                <td class="text-center">
                    <input type="date" name="date" class="form-control"
                           value="{{ $list->date }}" disabled>
                </td>
            </tr>

            <tr>
                <th class="text-center">@lang('strings.Invoice_id')</th>
                <td class="text-center">
                    <input type="text" name="invoice_no" class="form-control"
                           value="{{ $list->invoice_no }}" disabled>
                </td>
            </tr>
            </tbody>
        </table>
    </div>
</div>
<table id="xtreme-table" class="display table" style="width: 100%; cellspacing: 0;">
    <thead>
    <tr>
        <th>@lang('strings.Item_name')</th>
        <th>@lang('strings.Quantity')</th>
        <th>@lang('strings.Price')</th>
        <th>@lang('strings.Tax')</th>
        <th>@lang('strings.Payment_status')</th>
    </tr>
    </thead>
    <tbody>
        @foreach($list->transactions as $value)
        <tr>
            <td> {{ app()->getLocale() == 'ar' ? App\Category::findOrFail($value->cat_id)->name : App\Category::findOrFail($value->cat_id)->name_en }}</td>
            <td> {{ $value->quantity }}</td>
            <td> {{ $value->price }}</td>
            <td> {{ $value->tax_val }} {{ $value->tax_val <= 100 ? '%' : '' }}</td>
            <td> <input type="checkbox" name="paid" {{ $value->status == 1 ? 'checked disabled' : ''}}></td>
        </tr>
        @endforeach
    </tbody>
</table>
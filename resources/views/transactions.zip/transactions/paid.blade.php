@extends('layouts.admin', ['title' => __('strings.pay_bill')])

@section('content')

    <!--<div class="page-title">-->
    <!--    <h3>@lang('strings.pay_bill')</h3>-->
    <!--    <div class="page-breadcrumb">-->
    <!--        <ol class="breadcrumb">-->
    <!--            <li><a href="{{ route('home') }}">@lang('strings.Home')</a></li>-->
    <!--            <li><a href="{{ route('transactions.index') }}">@lang('strings.transactions_list')</a></li>-->
    <!--            <li class="active">@lang('strings.pay_bill')</li>-->
    <!--        </ol>-->
    <!--    </div>-->
    <!--</div>-->
    <div id="main-wrapper">
        <div class="row">
            <form method="post" action="{{ url('admin/transactions/invoice/create-paid')}}" enctype="multipart/form-data" role="form" id="add-role">
                {{csrf_field()}}

                <input name="customer_req_id" type="hidden" value="{{ $id }}">
                <input name="cust_id" type="hidden" value="{{ $receiving->cust_id }}">
                <div class="col-md-4 form-group">
                    <label class="control-label" for="invoice_no">@lang('strings.Client_name')</label>
                    <input type="text" class="form-control" name="" value="{{ app()->getLocale() == 'ar' ? App\Customers::findOrFail($receiving->cust_id)->name : App\Customers::findOrFail($receiving->cust_id)->name_en }}" readonly>
                </div>

                <div class="col-md-4 form-group{{$errors->has('invoice_no') ? ' has-error' : ''}}">
                    <label class="control-label" for="invoice_no">@lang('strings.invoice_id')</label>
                    <input type="text" class="form-control" name="invoice_no" value="{{ $receiving->invoice_no }}" readonly>
                </div>

                <div class="col-md-4 form-group{{$errors->has('pay_date') ? ' has-error' : ''}}">
                    <label class="control-label" for="pay_date">@lang('strings.Pay_date')</label>
                    <input type="date" class="form-control" name="pay_date" value="{{ date('Y-m-d') }}">
                </div>

                <div class="col-md-4 form-group{{$errors->has('total_invoice') ? ' has-error' : ''}}">
                    <label class="control-label" for="total_invoice">@lang('strings.Total_invoice')</label>
                    <input type="text" class="form-control" name="total_invoice" value="{{ number_format(abs($receiving->transactions->sum('total')), 2) }}" readonly>
                </div>

                <div class="col-md-4 form-group{{$errors->has('pay_flag') ? ' has-error' : ''}}">
                    <label class="control-label" for="pay_flag">@lang('strings.Payment_type')</label>
                    <select class="form-control" name="pay_flag" id="pay_flag">
                        <option value="1">@lang('strings.Payment_type_1')</option>
                        <option value="-1">@lang('strings.Payment_type_2')</option>
                    </select>
                </div>

                <div class="col-md-4 form-group{{$errors->has('paid') ? ' has-error' : ''}}">
                    <label class="control-label" for="paid">@lang('strings.Amount')</label>
                    <input type="text" class="form-control" name="paid">
                </div>

                <div class="col-md-12 form-group{{$errors->has('description') ? ' has-error' : ''}}">
                    <label class="control-label" for="description">@lang('strings.Notes')</label>
                    <textarea type="text" class="textall" name="description">{{old('description')}}</textarea>
                    @if ($errors->has('description'))
                        <span class="help-block">
                            <strong class="text-danger">{{ $errors->first('description') }}</strong>
                        </span>
                    @endif
                </div>
                <div class="">
                    <div class="pull-right col-md-6">
                        <table class="table table-bordered table-hover" id="tab_logic_total">
                            <tbody>
                            <tr>
                                <th class="text-center">@lang('strings.Payments_type')</th>
                                <td class="text-center">
                                    <select class="form-control" name="pay_method" id="pay_method">
                                        <option value="0">@lang('strings.Select')</option>
                                        <option value="1">@lang('strings.Cash')</option>
                                        <option value="2">@lang('strings.Bank_account')</option>
                                        <option value="3">@lang('strings.Credit_card')</option>
                                    </select>
                                </td>
                            </tr>

                            <tr style="display: none" id="treasure">
                                <th class="text-center">@lang('strings.treasure')</th>
                                <td class="text-center">
                                    <select class="form-control" name="treasure_method">
                                        <option>@lang('strings.Select')</option>
                                        @foreach($banks->where('type', 1) as $v)
                                            <option value="{{ $v->id }}">{{ app()->getLocale() == 'ar' ? $v->name : $v->name_en }}</option>
                                        @endforeach
                                    </select>
                                </td>
                            </tr>

                            <tr style="display: none" id="banks">
                                <th class="text-center">@lang('strings.Banks')</th>
                                <td class="text-center">
                                    <select class="form-control" name="bank_method">
                                        <option>@lang('strings.Select')</option>
                                        @foreach($banks->where('type', 2) as $v)
                                            <option value="{{ $v->id }}">{{ app()->getLocale() == 'ar' ? $v->name : $v->name_en }}</option>
                                        @endforeach
                                    </select>
                                </td>
                            </tr>

                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="col-md-12 form-group text-right">
                    <button type="submit" class="btn btn-primary btn-lg">@lang('strings.Save')</button>
                </div>

            </form>
            <div class="col-md-12">
                @include('alerts.index')

                <div class="panel panel-white">
                    <div class="panel-heading clearfix">
                    </div>
                    <div class="panel-body">
                        <div class="table-responsive">
                            <table id="xtreme-table" class="display table" style="width: 100%; cellspacing: 0;">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>@lang('strings.Client_name')</th>
                                    <th>@lang('strings.invoice_id')</th>
                                    <th>@lang('strings.Payment_type')</th>
                                    <th>@lang('strings.Amount') </th>
                                    <th>@lang('strings.Notes')</th>
                                </tr>
                                </thead>
                                <tbody>
                                    @foreach($invoice as $value)
                                        <tr>
                                            <td>{{ $value->id }}</td>
                                            <td>{{ app()->getLocale() == 'ar' ? App\Customers::findOrFail($value->customer_id)->name : App\Customers::findOrFail($value->customer_id)->name_en }}</td>
                                            <td>{{ $value->customer_invoice_no }}</td>
                                            <td>{!! $value->description !!}</td>
                                            <td>{{ $value->pay_amount }}</td>
                                            <td>{!! $value->remarks !!}</td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>

                        {{ $invoice->links() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('scripts')
<script>
    $('#pay_method').change(function () {
        if(this.value == 1){
            $('#treasure').show();
            $('#banks').hide();
        }else if(this.value == 2){
            $('#treasure').hide();
            $('#banks').show();
        }else{
            $('#banks').hide();
            $('#treasure').hide();
        }
    });
</script>
@endsection
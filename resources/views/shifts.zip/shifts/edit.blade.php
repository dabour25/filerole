@extends('layouts.admin', ['title' => __('strings.shift_add') ])

@section('content')
  <style>
  .clearButton {
    color: #fff;
    background: #bbb;
    font-size: 0.7em;
    padding: 0 4px;
    border-radius: 10px;
    position: relative;
    z-index: 20;
    left: -20px;
    cursor: default;
}
  </style>
    <!--<div class="page-title">-->
    <!--    <h3> {{ __('strings.Role_add') }} </h3>-->
    <!--    <div class="page-breadcrumb">-->
    <!--        <ol class="breadcrumb">-->
    <!--            <li><a href="{{ route('home') }}">{{ __('strings.Home') }}</a></li>-->
    <!--            <li><a href="{{ route('roles.index') }}">{{ __('strings.Roles') }}</a></li>-->
    <!--            <li class="active">{{ __('strings.Role_add') }}</li>-->
    <!--        </ol>-->
    <!--    </div>-->
    <!--</div>-->
    <div id="main-wrapper">
        <div class="row">
          <div class="col-md-12">
    			<div class="input-fields inside-form-box">
    				<h3 class="rounded-item  head-bar theme-color-a"><span class="contact-info"></span></h3>
    								<form  action="{{route('shift.update',$shift->id)}}" method="post">
                      {{ csrf_field() }}
                      {{ method_field('PATCH') }}

                      <input type="hidden" name="data[Shift][id]" value="" id="ShiftId">
                      <div class="form-group text required"><label for="ShiftName">{{ __('strings.Arabic_name') }}</label>
                        <input name="name" type="text" class="form-control required" value="{{$shift->name}}" maxlength="255" id="ShiftName" required>
                        @if ($errors->has('name'))
                                          <span class="help-block">
                                              <strong class="text-danger">{{ $errors->first('name') }}</strong>
                                          </span>
                                      @endif
                      </div>
                        <div class="form-group  text required"><label for="ShiftName">{{ __('strings.English_name') }}</label>
                          <input name="name_en" type="text" class="form-control required" value="{{$shift->name_en}}" maxlength="255" id="ShiftName" required>
                          @if ($errors->has('name'))
                                            <span class="help-block">
                                                <strong class="text-danger">{{ $errors->first('name') }}</strong>
                                            </span>
                                        @endif
                        </div>

                        <div class="row shift-row">

    									<input type="hidden" name="data[ShiftDay][1][id]" value="" id="ShiftDay1Id"><div class="clip-check check-info  from-group col-md-2">
                        <input type="hidden" name="data[ShiftDay][1][weekday]" id="ShiftDay1Weekday_" value="0">
                        <input type="checkbox" name="data[ShiftDay][1][weekday]" value="2" class="shift-day form-control INPUT required" id="ShiftDay1Weekday" {{$shiftDays[0]->shift_day==2?'checked':''}}>
                        <label for="ShiftDay1Weekday">{{__('strings.sunday')}}</label>
                      </div>
                      <div class="from-group col-md-2">
                        <label for="ShiftDay1FromTime"></label>
                        <input name="data[ShiftDay][1][from_time]" type="time" autocomplete="off" placeholder="00:00" class="timepicker INPUT required hasDatepicker" value="{{time_from_id($shiftDays[0]->time_from)}}"  disabled="disabled" step="1800">
                        <i class="fa fa-long-arrow-left"></i> </div>
    										<div class="from-group col-md-2">
                          <label for="ShiftDay1ToTime"></label>
                          <input name="data[ShiftDay][1][to_time]" type="time" autocomplete="off" placeholder="00:00" class="timepicker INPUT required hasDatepicker" value="{{time_from_id($shiftDays[0]->time_to)}}" id="ShiftDay1ToTime" disabled="disabled" step="1800">
                          @if(Session::has('shiftday2'))
                                           <span class="help-block">
                                               <strong class="text-danger">{{session('shiftday2')}}</strong>
                                           </span>
                                       @endif
                        </div>
                      </div>
    															<div class="row shift-row">

    									<input type="hidden" name="data[ShiftDay][2][id]" value="" id="ShiftDay2Id">
                      <div class="clip-check check-info  from-group col-md-2">
                        <input type="hidden" name="data[ShiftDay][2][weekday]" id="ShiftDay2Weekday_" value="0">
                        <input type="checkbox" name="data[ShiftDay][2][weekday]" value="3" class="shift-day form-control INPUT required" id="ShiftDay2Weekday" {{$shiftDays[1]->shift_day==3?'checked':''}}>
                        <label for="ShiftDay2Weekday">{{__('strings.monday')}}</label>
                      </div>
                      <div class="from-group col-md-2">
                        <label for="ShiftDay2FromTime"></label>
                        <input name="data[ShiftDay][2][from_time]" type="time" autocomplete="off" placeholder="00:00" class="timepicker INPUT required hasDatepicker" value="{{time_from_id($shiftDays[1]->time_from)}}" id="ShiftDay2FromTime" disabled="disabled" step="1800">
                        <i class="fa fa-long-arrow-left"></i> </div>
    										<div class="from-group col-md-2">
                          <label for="ShiftDay2ToTime"></label>
                          <input name="data[ShiftDay][2][to_time]" type="time" autocomplete="off" placeholder="00:00" class="timepicker INPUT required hasDatepicker" value="{{time_from_id($shiftDays[1]->time_to)}}" id="ShiftDay2ToTime" disabled="disabled" step="1800">
                          @if(Session::has('shiftday3'))
                                           <span class="help-block">
                                               <strong class="text-danger">{{session('shiftday3')}}</strong>
                                           </span>
                                       @endif
                        </div>
                      </div>
    											<div class="row shift-row">

    									<input type="hidden" name="data[ShiftDay][3][id]" value="" id="ShiftDay3Id"><div class="clip-check check-info  from-group col-md-2">
                        <input type="hidden" name="data[ShiftDay][3][weekday]" id="ShiftDay3Weekday_" value="0">
                        <input type="checkbox" name="data[ShiftDay][3][weekday]" value="4" class="shift-day form-control INPUT required" id="ShiftDay3Weekday" {{$shiftDays[2]->shift_day==4?'checked':''}}>
                        <label for="ShiftDay3Weekday">{{__('strings.tuesday')}}</label>
                      </div>
                      <div class="from-group col-md-2">
                        <label for="ShiftDay3FromTime"></label>
                        <input name="data[ShiftDay][3][from_time]" type="time" autocomplete="off" placeholder="00:00" class="timepicker INPUT required hasDatepicker" value="{{time_from_id($shiftDays[2]->time_from)}}" id="ShiftDay3FromTime" disabled="disabled" step="1800">
                        <i class="fa fa-long-arrow-left"></i>
                      </div>
    										<div class="from-group col-md-2">
                          <label for="ShiftDay3ToTime"></label>
                          <input name="data[ShiftDay][3][to_time]" type="time" autocomplete="off" placeholder="00:00" class="timepicker INPUT required hasDatepicker" value="{{time_from_id($shiftDays[2]->time_to)}}" id="ShiftDay3ToTime" disabled="disabled" step="1800">
                          @if(Session::has('shiftday4'))
                                           <span class="help-block">
                                               <strong class="text-danger">{{session('shiftday4')}}</strong>
                                           </span>
                                       @endif
                        </div>
                      </div>
    															<div class="row shift-row">

    									<input type="hidden" name="data[ShiftDay][4][id]" value="" id="ShiftDay4Id">
                      <div class="clip-check check-info  from-group col-md-2">
                        <input type="hidden" name="data[ShiftDay][4][weekday]" id="ShiftDay4Weekday_" value="0">
                        <input type="checkbox" name="data[ShiftDay][4][weekday]" value="5" class="shift-day form-control INPUT required" id="ShiftDay4Weekday" {{$shiftDays[3]->shift_day==5?'checked':''}}>
                        <label for="ShiftDay4Weekday">{{__('strings.wednesday')}}</label>
                      </div><div class="from-group col-md-2">
                        <label for="ShiftDay4FromTime"></label>
                        <input name="data[ShiftDay][4][from_time]" type="time" autocomplete="off" placeholder="00:00" class="timepicker INPUT required hasDatepicker" value="{{time_from_id($shiftDays[3]->time_from)}}" id="ShiftDay4FromTime" disabled="disabled" step="1800">
                        <i class="fa fa-long-arrow-left"></i> </div>
    										<div class="from-group col-md-2">
                          <label for="ShiftDay4ToTime"></label>
                          <input name="data[ShiftDay][4][to_time]" type="time" autocomplete="off" placeholder="00:00" class="timepicker INPUT required hasDatepicker" value="{{time_from_id($shiftDays[3]->time_to)}}" id="ShiftDay4ToTime" disabled="disabled" step="1800">
                          @if(Session::has('shiftday5'))
                                           <span class="help-block">
                                               <strong class="text-danger">{{session('shiftday5')}}</strong>
                                           </span>
                                       @endif
                        </div>
                      </div>
    															<div class="row shift-row">

    									<input type="hidden" name="data[ShiftDay][5][id]" value="" id="ShiftDay5Id">
                      <div class="clip-check check-info  from-group col-md-2">
                        <input type="hidden" name="data[ShiftDay][5][weekday]" id="ShiftDay5Weekday_" value="0">
                        <input type="checkbox" name="data[ShiftDay][5][weekday]" value="6" class="shift-day form-control INPUT required" id="ShiftDay5Weekday" {{$shiftDays[4]->shift_day==6?'checked':''}}>
                        <label for="ShiftDay5Weekday">{{__('strings.thursday')}}</label>
                      </div>
                      <div class="from-group col-md-2">
                        <label for="ShiftDay5FromTime"></label>
                        <input name="data[ShiftDay][5][from_time]" type="time" autocomplete="off" placeholder="00:00" class="timepicker INPUT required hasDatepicker" value="{{time_from_id($shiftDays[4]->time_from)}}" id="ShiftDay5FromTime" disabled="disabled" step="1800">
                        <i class="fa fa-long-arrow-left"></i> </div>
    										<div class="from-group col-md-2">
                          <label for="ShiftDay5ToTime"></label>
                          <input name="data[ShiftDay][5][to_time]" type="time" autocomplete="off" placeholder="00:00" class="timepicker INPUT required hasDatepicker" value="{{time_from_id($shiftDays[4]->time_to)}}" id="ShiftDay5ToTime" disabled="disabled" step="1800">
                          @if(Session::has('shiftday6'))
                                           <span class="help-block">
                                               <strong class="text-danger">{{session('shiftday6')}}</strong>
                                           </span>
                                       @endif
                        </div>
                      </div>
    															<div class="row shift-row">

    									<input type="hidden" name="data[ShiftDay][6][id]" value="" id="ShiftDay6Id">
                      <div class="clip-check check-info  from-group col-md-2">
                        <input type="hidden" name="data[ShiftDay][6][weekday]" id="ShiftDay6Weekday_" value="0">
                        <input type="checkbox" name="data[ShiftDay][6][weekday]" value="7" class="shift-day form-control INPUT required" id="ShiftDay6Weekday" {{$shiftDays[5]->shift_day==7?'checked':''}}>
                        <label for="ShiftDay6Weekday">{{__('strings.friday')}}</label>
                      </div>
                      <div class="from-group col-md-2">
                        <label for="ShiftDay6FromTime"></label>
                        <input name="data[ShiftDay][6][from_time]" type="time" autocomplete="off" placeholder="00:00" class="timepicker INPUT required hasDatepicker" value="{{time_from_id($shiftDays[5]->time_from)}}" id="ShiftDay6FromTime" disabled="disabled" step="1800">
                        <i class="fa fa-long-arrow-left"></i></div>
    										<div class="from-group col-md-2">
                          <label for="ShiftDay6ToTime"></label>
                          <input name="data[ShiftDay][6][to_time]" type="time" autocomplete="off" placeholder="00:00" class="timepicker INPUT required hasDatepicker" value="{{time_from_id($shiftDays[5]->time_to)}}" id="ShiftDay6ToTime" disabled="disabled" step="1800">
                          @if(Session::has('shiftday7'))
                                           <span class="help-block">
                                               <strong class="text-danger">{{session('shiftday7')}}</strong>
                                           </span>
                                       @endif
                        </div>
                      </div>
    															<div class="row shift-row">

    									<input type="hidden" name="data[ShiftDay][7][id]" value="" id="ShiftDay7Id">
                      <div class="clip-check check-info  from-group col-md-2">
                        <input type="hidden" name="data[ShiftDay][7][weekday]" id="ShiftDay7Weekday_" value="0">
                        <input type="checkbox" name="data[ShiftDay][7][weekday]" value="1" class="shift-day form-control INPUT required" id="ShiftDay7Weekday">
                        <label for="ShiftDay7Weekday">{{__('strings.saturday')}}</label>
                      </div>
                      <div class="from-group col-md-2">
                        <label for="ShiftDay7FromTime"></label>
                        <input name="data[ShiftDay][7][from_time]" type="time" autocomplete="off" placeholder="00:00" class="timepicker INPUT required hasDatepicker" value="{{time_from_id($shiftDays[6]->time_from)}}" id="ShiftDay7FromTime" disabled="disabled" step="1800">
                        <i class="fa fa-long-arrow-left"></i> </div>
    										<div class="from-group col-md-2">
                          <label for="ShiftDay7ToTime"></label>
                          <input name="data[ShiftDay][7][to_time]" type="time" autocomplete="off" placeholder="00:00" class="timepicker INPUT required hasDatepicker" value="{{time_from_id($shiftDays[6]->time_to)}}" id="ShiftDay7ToTime" disabled="disabled" step="1800">
                          @if(Session::has('shiftday1'))
                                           <span class="help-block">
                                               <strong class="text-danger">{{session('shiftday1')}}</strong>
                                           </span>
                                       @endif
                        </div>
                      </div>
                          <div class="col-md-6 form-group"><label class="control-label" for="active">{{__('strings.status')}}</label><select class="form-control" name="active"><option value="1" {{$shift->active==1?'selected':''}}>{{__('strings.active')}}</option><option value="0" {{$shift->active==0?'selected':''}}>{{__('strings.inactive')}}</option></select></div>
                          <div class="col-sm-12">
                    <button type="submit" class="btn btn-success btn-addon btn-lg pull-right "><i class="fa fa-angle-right"></i><span class="submit-blue">
      {{__('strings.save')}}        </span></button>
     </div>
    			</form>
        </div>
    		</div>
        <script>

        </script>

        @endsection

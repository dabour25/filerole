@extends('front.index_layout')

@section('content')
    <style>
        .form-wrapper {
            display: none;
        }

        .form-group select, .form-group input {
            display: block;
            width: 100%;
            height: 34px;
            padding: 6px 12px;
            font-size: 14px;
            line-height: 1.42857143;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        /* The Modal (background) */
        .modal_2 {
            display: none; /* Hidden by default */
            position: fixed; /* Stay in place */
            z-index: 1; /* Sit on top */
            left: 0;
            top: 0;
            width: 100%; /* Full width */
            height: 100%; /* Full height */
            overflow: auto; /* Enable scroll if needed */
            background-color: rgb(0, 0, 0); /* Fallback color */
            background-color: rgba(0, 0, 0, 0.4); /* Black w/ opacity */
        }

        /* Modal Content/Box */
        .modal-content {
            background-color: #fefefe;
            margin: 15% auto; /* 15% from the top and centered */
            padding: 20px;
            border: 1px solid #888;
            width: 80%; /* Could be more or less, depending on screen size */
        }

        /* The Close Button */
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        .radios {
            margin: 20px;
        }

        .radio-inline {
            padding-left: 56px;
        }

        input#confirm {
            height: auto;
        }

        #captains img {
            width: 40px !important;
            height: 40px !important;
        }

        #captains td {
            vertical-align: middle;
        }

        .green {
            background-color: #4CAF50 !important;
        }

        .service-wrapper {
            text-align: center;
        }

        .service {
            display: flex;
            align-items: center;
            flex-direction: column;
            height: 380px;
            border: 2px solid #efefef;
            border-radius: 10%;
            overflow: hidden;
            margin-bottom: 20px;
            background: #f7f7f7;
        }

        .service img {
            width: 100%;
            max-width: 100%;
            height: 70% !important;
        }

        .service button {
            width: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 15px 0 0 0;
        }

        .service h1 {
            font-size: 20px;
            font-weight: bold;
            margin: 15px 0 0 0;
        }

        span.label.captain_not_found {
            display: none;
            font-size: 16px;
        }

        .panel .panel-white {
            display: none;
        }

        span.help-block.date-error {
            display: none;
        }

        span.date-captain-error {
            display: none;
        }

        .paginate-links {
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .col-md-4 {
            float: right !important;
        }

        #category_types {
            width: 28% !important;
        }

        .reservation_header {
            display: flex;
            align-items: center;
        }

        .av_price {
            color: #353F49;
            font-size: 1.5em;
            font-weight: 500;
        }

        .del_price {
            color: #999;
            font-size: 1.5em;
            font-weight: 500;
        }

        @media only screen and (min-width: 350px) {
            #reservation > div > div.panel-body > div.container > div.reservation_header {
                flex-direction: column !important;;
            }

            .reservation_header h2 {
                width: 100%;
            }

            .header_left {
                justify-content: center !important;
                width: 100%;
            }

            #reservation > div > div.panel-body > div.container > div.reservation_header > div > a {
                margin-left: 0.7em;
            }
        }

        @media only screen and (min-width: 786px) {
            #reservation > div > div.panel-body > div.container > div.reservation_header {
                flex-direction: row !important;
            }

            #reservation > div > div.panel-body > div.container > div.reservation_header > div > a {
                float: left;
            }

            .reservation_header h2 {
                width: 50%;
            }

            .header_left {
                width: 50%;
            }
        }

        @media only screen and (min-width: 980px) {
            .reservation_header h2 {
                width: 70%;
            }

            .header_left {
                width: 30%;
            }
        }

        #reservation {
            width: 100%;
            overflow: hidden;
            padding: 0 40px;
        }

        .btn-primary {
            font-size: 14px;
            color: #adadad;
            background: none;
            border: 1px solid #adadad;
        }

        .col-md-4 {
            width: 100%;
            max-width: 100%;
        }

        .main-wrapper {
            overflow: hidden;
        }
        .staff-time {
    width: calc(20% - 6px);
    padding: 7px 10px;
    border: 1px solid #ddd;
    display: inline-block;
    margin: 3px;
    text-align: center;
    cursor: pointer;
  }
        .times {
          list-style: none;
          text-align: right;
        }
        .start-time  {
          padding: 15px;
          border: 1px solid #ccc;
          border-radius: 3px;
          margin-bottom: 10px;
          width: 100%;
          box-sizing: border-box;
          color: #2C3E50;
          font-size: 13px;
        }
        span.help-block.date-error2 {
    display: none;
  }
    </style>
    <div id="page_header" class="page-subheader page-subheader-bg">

        <!-- Sub-Header content wrapper -->
        <div class="ph-content-wrap d-flex">
            <div class="container align-self-center">
                <div class="row">

                    <div class="col-sm-12 col-md-6 col-lg-6">
                        <div class="subheader-titles">
                            <h2 class="subheader-maintitle">
                                الحجوزات والفواتير
                            </h2>

                        </div>
                    </div>

                    <div class="col-sm-12 col-md-6 col-lg-6">
                        <ul class="breadcrumbs fixclear">
                            <li><a href="/">@lang('strings.Home')</a></li>
                            <li> الحجوزات والفواتير</li>
                        </ul>

                    </div>
                </div>
            </div>
        </div>

        <!-- Sub-Header bottom mask style 6 -->
        <div class="kl-bottommask kl-bottommask--mask6">
            <svg width="2700px" height="57px" class="svgmask" viewBox="0 0 2700 57" version="1.1"
                 xmlns="https://www.w3.org/2000/svg" xmlns:xlink="https://www.w3.org/1999/xlink">
                <defs>
                    <filter x="-50%" y="-50%" width="200%" height="200%" filterUnits="objectBoundingBox"
                            id="filter-mask6">
                        <feOffset dx="0" dy="-2" in="SourceAlpha" result="shadowOffsetOuter1"></feOffset>
                        <feGaussianBlur stdDeviation="2" in="shadowOffsetOuter1"
                                        result="shadowBlurOuter1"></feGaussianBlur>
                        <feColorMatrix values="0 0 0 0 0   0 0 0 0 0   0 0 0 0 0  0 0 0 0.5 0" in="shadowBlurOuter1"
                                       type="matrix" result="shadowMatrixOuter1"></feColorMatrix>
                        <feMerge>
                            <feMergeNode in="shadowMatrixOuter1"></feMergeNode>
                            <feMergeNode in="SourceGraphic"></feMergeNode>
                        </feMerge>
                    </filter>
                </defs>
                <g transform="translate(-1.000000, 10.000000)">
                    <path d="M0.455078125,18.5 L1,47 L392,47 L1577,35 L392,17 L0.455078125,18.5 Z"
                          fill="#000000"></path>
                    <path d="M2701,0.313493752 L2701,47.2349598 L2312,47 L391,47 L2312,0 L2701,0.313493752 Z"
                          fill="#fbfbfb" class="bmask-bgfill" filter="url(#filter-mask6)"></path>
                    <path d="M2702,3 L2702,19 L2312,19 L1127,33 L2312,3 L2702,3 Z" fill="#cd2122"
                          class="bmask-customfill"></path>
                </g>
            </svg>
        </div>
    </div>

    <div id="main-wrapper">
        <div class="row">
            <div role="tabpanel" class="tab-pane" id="reservation">
                <div class="panel panel-white">

                    <div class="panel-body">
                        <div class="container">
                            <div class="reservation_header">

                                <div class="header_left">
                                    <a href="{{ url('customerdashboard') }}"
                                       class="btn btn-primary">@lang('strings.return_home')</a>
                                    <a href="{{ url('/reservation') }}"
                                       class="btn btn-primary">@lang('strings.all_services')</a>
                                </div>
                            </div>
                            @if(!$category_types->isEmpty())
                                <div class="form-group">
                                    <label for="category"
                                           style="display: block">@lang('strings.choose_cat_type')</label>
                                    <select class="custom-select" name="category_types" id="category_types">
                                        <option value="" selected disabled>@lang('strings.all')...</option>
                                        @foreach($category_types as $i => $category_type)
                                            <option value="{{ $category_type->id }}">{{ app()->getLocale() == 'ar' ? $category_type->name  : $category_type->name_en  }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            @else
                                <span class="help-block">
                                                <strong class="text-danger">@lang('strings.no_services_avaliable')</strong>
                                            </span>
                            @endif
                            <div class="service-wrapper serv_wrap_new">
                                @include('reservation.categories')
                            </div>


                        </div>
                        <div class="form-wrapper form_wrapper_new">
                            <div id="main-wrapper" style="display: flex;justify-content: center;align-content: center">
                                <div class="row">

                                        {{-- <div class="form-group">

                                            <label for="category"
                                                   style="display: block">@lang('strings.choose_cat_type')</label>
                                            <select class="custom-select" name="category" id="categories">

                                            </select>
                                        </div> --}}
                                        <div class="form-group">
                                          <label for="captain" style="display: block">@lang('strings.choose_catpatin')</label>
                                          <select class="form-control js-select" name="captain" id="captain">
                                            @foreach($captins as $captin)
                                              <option value="{{ $captin->id }}">{{ app()->getLocale() == 'ar' ? $captin->name  : $captin->name_en  }}</option>
                                            @endforeach
                                          </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="date"
                                                   style="display: block">@lang('strings.choose_date')</label>
                                            <input type="date" name="date" id="date" class="form-control" value="{{date('Y-m-d')}}">
                                            <span class="help-block date-error">
                                                <strong class="text-danger"> @lang('strings.Message_date')</strong>
                                            </span>
                                            <span class="help-block date-error2">
                                                <strong class="text-danger2"> @lang('strings.no_times_available')</strong>
                                            </span>
                                        </div>
                                        <div class="col-md-4 col-xs-12">
                                           <div class="form-group" id="time_form">
                                               <label class="control-label" for="time">@lang('strings.Time')</label>
                                               <p id="date-text"></p>
                                               <div class="timeline_new">
                                                 <ul id="times" class="times"></ul>
                                               </div>

                                               @if (session('time_error'))
                                                   <span class="help-block">
                                                       <strong class="text-danger">{{ session('time_error') }}</strong>
                                                   </span>
                                               @endif
                                           </div>
                                       </div>

                                       <div class="form-group">
                                           <label for="comment">@lang('strings.add_comment')</label>
                                           <textarea class="form-control" rows="5" name="comment"
                                                     id="comment"></textarea>
                                       </div>

                                        <div class="form-group">
                                            <button id="add_comment_button" type="submit" onclick="validateform(event)" class="btn btn-primary">@lang('strings.save')</button>
                                        </div>

                                        <div id="myModal2" class="modal_2 modalmy">
                                            <!-- Modal content -->
                                            <div class="modal-content">
                                                <button type="button" class="close" data-dismiss="modal"
                                                        onclick="close_me(event)">&times;
                                                </button>
                                                <span>@lang('strings.confirm_reservation')</span>
                                                <input type="hidden" name="time2">
                                                <button type="submit" class="btn btn-primary" data-dismiss="modal" style="display:inline;">@lang('strings.Confirm')</button>
                                                <button  class="btn btn-primary" data-dismiss="modal" onclick="close_me(event)">@lang('strings.Cancel')</button>
                                            </div>
                                        </div>


                                    </form>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>



@endsection

@section('scripts')

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <script>
    function getTimeString(time)
    {
        timeParts = time.split(':');
        hours = parseInt(timeParts[0]);
        if(hours >= 12)
        {
            timeSuffix = 'PM';
            if(hours > 12)
            {
                hours = hours - 12;
            }
        }else if(hours < 12)
        {
            timeSuffix = 'AM';
            if(hours == 0)
            {
                hours = 12;
            }
        }

        if(hours < 10){
            hours = '0'+hours.toString();
        }

        timeParts[0] = hours;
        timeParts[1]+= ' ' + timeSuffix;
        time = timeParts.join(':');
        return time;
    }
    function add_selected(){
      $(".form-wrapper").fadeOut(400);

    }
  var duration=0;
    function choose_services(event){
      event.preventDefault();
           duration=0;
            $.each($('input[name="cat_id[]"]:checked'), function(){
            duration+=$(this).data('duration');
            });
            console.log(duration);
            if(duration==0){
              alert('please choose service');
            }
            else{
              $(".form-wrapper").fadeIn(400);
              $('html,body').animate({scrollTop: $("#add_comment_button").offset().top}, 'slow');

              var captainElement = document.getElementById('captain');
              var captainID = captainElement.options[captainElement.selectedIndex].value;
              $.get("{{ url('/reservations/customer_captains') }}/" + captainID + "/" +$('#date').val()+"/" +duration, function (data) {
                  $("#times").empty();


                   timeSlotsHtml = '';
                  console.log(data);
                  if(!Object.keys(data).length >=1){
                    $('#times').empty();
                    if ($('span.help-block.date-error2').css('display') == 'none') {
                        $('span.help-block.date-error2').css({"display": "block"});
                        $('.panel .panel-white').css({"display": "none"});
                    }
                    return;

                  }
                  else{
                    $('span.help-block.date-error2').css({"display": "none"});
                    $('span.date-captain-error2').css({"display": "none"});
                    var j=0;
                    $.each(data, function (key, value) {
                                         if(j==0){
                                           timeSlotsHtml += `<li class="staff-time">
                                                 <input class="start-time" type="radio" name="time" value="${key}" checked> <span>${getTimeString(value)}</span>
                                           </li>`;
                                         }
                                         else{
                                           timeSlotsHtml += `<li class="staff-time">
                                                 <input class="start-time" type="radio" name="time" value="${key}" > <span>${getTimeString(value)}</span>
                                           </li>`;
                                         }

                      $('#times').html(timeSlotsHtml);
                      j++;
                    });
                  }

              });
            }



    }
        function fillCategories(typeValue) {

        };


        function validateDate() {
            var del_date = document.getElementById('date').value;
            var yesterday = (function () {
                this.setDate(this.getDate() - 1);
                return this;
            }).call(new Date);
            if (Date.parse(del_date) < yesterday) {
                return false;
            } else {
                return true;
            }
        };

        var initialCategoryType = $("#category_types").val();
        fillCategories(initialCategoryType);



        $("#categories").empty();
        $("#category_types").change(function () {
            $('.paginate-links').empty();
            $(".form-wrapper").fadeOut(400);
            var category_type_id = this.value;
            fillCategories(category_type_id);
            $.get("{{ url('reservation/service') }}/" + category_type_id + "/categories", function (data) {
                $(".service-wrapper").html(data);
            });
        });

        $("#date").change(function () {
            $check = validateDate();
            if ($check === false) {
            $('#times').empty();

                if ($('span.help-block.date-error').css('display') == 'none') {
                    $('span.help-block.date-error').css({"display": "block"});
                    $('span.help-block.date-error2').css({"display": "none"});
                    $('.panel .panel-white').css({"display": "none"});
                }
                return;
            } else {

                $('span.help-block.date-error').css({"display": "none"});
                $('span.date-captain-error').css({"display": "none"});
                var captainElement = document.getElementById('captain');
                var captainID = captainElement.options[captainElement.selectedIndex].value;

                var dateElement = document.getElementById('date').value;
              $.get("{{ url('/reservations/customer_captains') }}/" + captainID + "/" +$('#date').val()+"/" +duration, function (data) {
                    $("#time").empty();


                     timeSlotsHtml = '';
                    console.log(data);
                    if(!Object.keys(data).length >=1){
                      $('#times').empty();
                      if ($('span.help-block.date-error2').css('display') == 'none') {
                          $('span.help-block.date-error2').css({"display": "block"});
                          $('.panel .panel-white').css({"display": "none"});
                      }
                      return;

                    }
                    else{
                      $('span.help-block.date-error2').css({"display": "none"});
                      $('span.date-captain-error2').css({"display": "none"});
                      var j=0;
                      $.each(data, function (key, value) {
                                           if(j==0){
                                             timeSlotsHtml += `<li class="staff-time">
                                                   <input class="start-time" type="radio" name="time" value="${key}" checked> <span>${getTimeString(value)}</span>
                                             </li>`;
                                           }
                                           else{
                                             timeSlotsHtml += `<li class="staff-time">
                                                   <input class="start-time" type="radio" name="time" value="${key}"><span>${getTimeString(value)}</span>
                                             </li>`;
                                           }

                        $('#times').html(timeSlotsHtml);
                        j++;
                      });
                    }

                });
            }

        });


        $(document).on('click', '.pagination a', function (e) {
            var category_type_id = $("#category_types").val();
            if (category_type_id == null) {
                return;
            }
            e.preventDefault();
            var page = $(this).attr('href').split('s=')[1];
            $.get("{{ url('reservation/service') }}/" + category_type_id + "/categories?s=" + page, function (data) {
                $('.service-wrapper').html(data);
            });
        });


        function validateform(e){

var modal2 = document.getElementById('myModal2');
$('input[name="time2"]').val($('input[name="time"]').val());



              e.preventDefault();
            modal2.style.display = "block";
          }

       function close_me(event) {
                   document.getElementById("myModal2").style.display = "none";
                  event.preventDefault();
               };

    </script>
@endsection

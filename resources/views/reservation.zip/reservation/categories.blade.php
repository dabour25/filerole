
<div class="row">
    <div class="services">
      
      <form method="post" action="{{ url('/reservation') }}" id="reservation_form">
          @csrf
        @foreach($categories as $i => $category)
            <div class="col-md-4 col-sm-6 col-xs-12">
                <div class="service" id="service-{{ $category['category']->id }}">
                    <img src="{{asset($category['photo'] ? $category['photo'] : '/images/profile-placeholder.png')}}" alt="{{ $category['category']->name }}" style="width:100%;height: 170px">
                    <h2 id="service-name-{{ $category['category']->id }}">{{app()->getLocale() == 'ar' ? $category['category']->name : $category['category']->name_en }}</h2>
                    <div class="prices">
                        @if(!empty($category['offer_price']))
                            <span class="av_price"> {{ $category['offer_price'] }} </span>
                            <del class="del_price"> {{ $category['final_price'] }} </del>
                        @else
                            @if(!empty($category['final_price']))
                                <span class="av_price"> {{ $category['final_price'] }} </span>
                            @endif
                        @endif
                    </div>
                    <label for="cat_id">{{__('strings.choose_service')}}</label>
                    <input type="checkbox" name="cat_id[]"  data-duration="{{$category['duration']}}" value="{{ $category['category']->id }}" onchange="add_selected(this)">

                </div>
            </div>
        @endforeach
    </div>
    <button onclick="choose_services(event)">{{__('strings.continue')}}</button>
</div>
<?php
$link_limit = 7;
$paginator = $categories;
?>

<div class="paginate-links">
@if ($paginator->lastPage() > 1)
    <ul class="pagination">
        <li class="{{ ($paginator->currentPage() == 1) ? ' disabled' : '' }}">
            <a href="{{ $paginator->url(1) }}">First</a>
        </li>
        @for ($i = 1; $i <= $paginator->lastPage(); $i++)
            <?php
            $half_total_links = floor($link_limit / 2);
            $from = $paginator->currentPage() - $half_total_links;
            $to = $paginator->currentPage() + $half_total_links;
            if ($paginator->currentPage() < $half_total_links) {
                $to += $half_total_links - $paginator->currentPage();
            }
            if ($paginator->lastPage() - $paginator->currentPage() < $half_total_links) {
                $from -= $half_total_links - ($paginator->lastPage() - $paginator->currentPage()) - 1;
            }
            ?>
            @if ($from < $i && $i < $to)
                <li class="{{ ($paginator->currentPage() == $i) ? ' active' : '' }}">
                    <a href="{{ $paginator->url($i) }}">{{ $i }}</a>
                </li>
            @endif
        @endfor
        <li class="{{ ($paginator->currentPage() == $paginator->lastPage()) ? ' disabled' : '' }}">
            <a href="{{ $paginator->url($paginator->lastPage()) }}">Last</a>
        </li>
    </ul>
@endif
</div>

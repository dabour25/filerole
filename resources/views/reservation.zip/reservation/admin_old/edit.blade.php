@extends('layouts.admin', ['title' =>__('strings.dashboard')])

@section('content')
    <style>
        .form-group select,.form-group input{
            display: block;
            width: 100%;
            height: 34px;
            padding: 6px 12px;
            font-size: 14px;
            line-height: 1.42857143;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        /* The Modal (background) */
        .modal {
            display: none; /* Hidden by default */
            position: fixed; /* Stay in place */
            z-index: 1; /* Sit on top */
            left: 0;
            top: 0;
            width: 100%; /* Full width */
            height: 100%; /* Full height */
            overflow: auto; /* Enable scroll if needed */
            background-color: rgb(0,0,0); /* Fallback color */
            background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
        }

        /* Modal Content/Box */
        .modal-content {
            background-color: #fefefe;
            margin: 15% auto; /* 15% from the top and centered */
            padding: 20px;
            border: 1px solid #888;
            width: 80%; /* Could be more or less, depending on screen size */
        }

        /* The Close Button */
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }
        .radios{
            margin: 20px;
        }
        .radio-inline{
            padding-left: 56px;
        }
        input#confirm{
            height: auto;
        }
    </style>

    <div class="page-title">
        <h3>@lang('strings.edit_reservation') </h3>
    </div>
    <div id="main-wrapper" style="display: flex;justify-content: center;align-content: center">
        <div class="row">
            <form method="post" action="{{ url('/admin/reservations') }}/{{ $reservation->id }}" id="reservation_form">
                @csrf
                @method('PUT')
                <div class="form-group">
                    <label style="display: block">@lang('strings.Client_name')</label>
                    <select class="form-control js-select" name="customer" required>
                        <option value="">@lang('strings.Select_client')</option>
                        @foreach($customers as $customer)
                            @if($reservation->cust_id == $customer->id)
                                <option value="{{$customer->id}}" selected>{{ app()->getLocale() == 'ar' ? $customer->name  : $customer->name_en  }}</option>
                            @else
                                <option value="{{$customer->id}}">{{ app()->getLocale() == 'ar' ? $customer->name  : $customer->name_en  }}</option>
                            @endif
                        @endforeach
                    </select>
                </div>
                <div class="form-group">
                    <label for="category" style="display: block">@lang('strings.choose_cat_type')</label>
                    <select class="custom-select" name="category_types" id="category_types">
                        <option selected disabled>@lang('strings.Select') ...</option>
                        @foreach($services as $service)
                            @if($reservation->category_type_id == $service->id)
                                <option value="{{ $service->id }}" selected>{{ app()->getLocale() == 'ar' ? $service->name  : $service->name_en  }}</option>
                            @else
                                <option value="{{ $service->id }}">{{ app()->getLocale() == 'ar' ? $service->name  : $service->name_en  }}</option>
                            @endif
                        @endforeach
                    </select>
                </div>
                <div class="form-group">
                    <label style="display: block">@lang('strings.choose_cat')</label>
                    <select class="form-control js-select" name="category" id="categories">
                        <option value="">@lang('strings.Select') ...</option>
                        @foreach($categories as $category)
                            @if($reservation->cat_id == $category->id)
                                <option value="{{ $category->id }}" selected>{{ app()->getLocale() == 'ar' ? $category->name  : $category->name_en  }}</option>
                            @else
							 
                                <option value="{{ $category->id }}">{{ app()->getLocale() == 'ar' ? $category->name  : $category->name_en  }}</option>
                            @endif
                        @endforeach
                    </select>
                </div>
                <div class="form-group">
                    <label for="date" style="display: block">@lang('strings.choose_date')</label>
                    <input type="date" name="date" id="date" class="form-control" value="{{ $reservation->reservation_date }}">
                </div>
                <div class="form-group">
                    <label for="captain" style="display: block">@lang('strings.choose_catpatin')</label>
                    <select class="custom-select" name="captain" id="captain">
					 <option value="{{ $reservation->captain_id }}" selected>{{ $reservation->captain_name }}</option>
					@foreach($captainsAvailable as $value)
					@if($reservation->captain_id == $value->id)
					{{'&nbsp;'}}
				   @else
					<option value="{{ $value->id }}">{{ app()->getLocale() == 'ar' ? $value->name  : $value->name_en  }}</option>
				@endif
					@endforeach	
                    </select>
                </div>
                <div class="form-group" id="time_form">
                    <label class="control-label" for="time">@lang('strings.Time')</label>
					
					
                    <select class="custom-select" name="time" id="time">
                    <option value="{{ $reservation->av_time }}">{!! availableTimes($reservation->av_time,false) !!}</option>
					@foreach($times as $time)
					@if($reservation->av_time == $time)
					{{'&nbsp;'}}
				   @else
                     <option value="{{ $reservation->av_time }}">{!! availableTimes($time,false) !!}</option>
				 @endif
                   @endforeach
                    </select>
                    @if (session('time_error'))
                        <span class="help-block">
                        <strong class="text-danger">{{ session('time_error') }}</strong>
                    </span>
                    @endif
                </div>
                <div class="form-group">
                    <button id="add_comment_button" type="button" class="btn btn-primary">@lang('strings.add_comment')</button>
                </div>
                <div id="myModal" class="modal">
                    <!-- Modal content -->
                    <div class="modal-content">
                        <span class="close">&times;</span>
                        <div class="form-group">
                            <label for="comment">@lang('strings.add_comment') </label>
                            <textarea class="form-control" rows="5" name="comment" id="comment"></textarea>
                        </div>
                        <button id="add_check_button" type="button" class="btn btn-primary">@lang('strings.Save')</button>
                    </div>
                </div>
                <div id="myModal2" class="modal">
                    <!-- Modal content -->
                    <div class="modal-content">
                        <span class="close2">&times;</span>
                        <div class="form-group">
                            <label id="confirmation" for="radios" style="margin-bottom: 10px"></label>
                            <div class="custom-radio" id="radios">
                                <label class="radio-inline"><input type="radio" name="confirm" id="confirm" value="y" checked>@lang('strings.Yes')</label>
                                <label class="radio-inline"><input type="radio" name="confirm" id="confirm" value="n">@lang('strings.No')</label>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">@lang('strings.Confirm')</button>
                    </div>
                </div>

            </form>
        </div>
    </div>

@endsection

@section('scripts')
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
    <script>
        $('.js-select').select2({
            minimumInputLength: 2,
        });
        $("#category_types").change(function () {
            $.get( "{{ url('/admin/reservations/getCategories') }}/" + this.value, function( data ) {
                $("#categories").empty();
                $.each(data, function(key, value) {
					
				if({{app()->getLocale() == 'ar'?0:1}}==0)
                   $("#categories").append("<option value='" + value.id + "'>" + value.name + "</option>");
				else
				  $("#categories").append("<option value='" + value.id + "'>" + value.name_en + "</option>");
	
                });
            });
        });

        $("#date").change(function () {
            $("#time").empty();
            $.get( "{{ url('/admin/reservations/captains') }}/" + this.value, function( data ) {

                $("#captain").empty();
                $("#captain").append("<option selected disabled>" + "@lang('strings.Select') ... " + "</option>");
                $.each(data, function(key, value) {
					if({{app()->getLocale() == 'ar'?0:1}}==0)	
                    $("#captain").append("<option value='" + value.id + "'>" + value.name + "</option>");
				else
                   $("#captain").append("<option value='" + value.id + "'>" + value.name_en + "</option>");

                });
            });
        });

        $("#captain").change(function () {
            var captainElement = document.getElementById('captain');
            var captainID = captainElement.options[captainElement.selectedIndex].value;
            var dateElement = document.getElementById('date').value;
            console.log(captainID);
            console.log(dateElement);
            $.get( "{{ url('/admin/reservations/captains') }}/" + captainID + "/" + dateElement, function( data ) {
                $("#time").empty();
                $.each(data, function(key,value) {
                    var id = key + 1;
                    $("#time").append("<option value='" + key + "'>" + value + "</option>");
                });
            });

        });

        // Get the modal
        var modal = document.getElementById('myModal');

        // Get the button that opens the modal
        var btn = document.getElementById("add_comment_button");

        // Get the <span> element that closes the modal
        var span = document.getElementsByClassName("close")[0];

        // When the user clicks on the button, open the modal
        btn.onclick = function() {
            modal.style.display = "block";
        };

        // When the user clicks on <span> (x), close the modal
        span.onclick = function() {
            modal.style.display = "none";
        };

        // When the user clicks anywhere outside of the modal, close it
        window.onclick = function(event) {
            if (event.target === modal) {
                modal.style.display = "none";
            }
        };

        var modal2 = document.getElementById('myModal2');

        // Get the button that opens the modal
        var btn2 = document.getElementById("add_check_button");

        // Get the <span> element that closes the modal
        var span2 = document.getElementsByClassName("close2")[0];

        // When the user clicks on the button, open the modal
        btn2.onclick = function() {
            modal.style.display = "none";
            modal2.style.display = "block";
            var label2 = document.getElementById('confirmation');
            var serviceElement = document.getElementById('categories');
            var captainElement = document.getElementById('captain');
            var dateElement = document.getElementById('date').value;
            var timeElement = document.getElementById('time');
            var service = serviceElement.options[serviceElement.selectedIndex].text;
            var captain = captainElement.options[captainElement.selectedIndex].text;
            var time = timeElement.options[timeElement.selectedIndex].text;
            var confimation_text = 'رجاء تأكيد تعديل الحجز لخدمة ' + service + ' مع كابتن ' + captain + ' يوم ' + dateElement + ' الساعة ' + time;
            label2.innerHTML= confimation_text;
        };

        // label2.innerText = 'رجاء تأكيد الحجز لخدمة ';


        // When the user clicks on <span> (x), close the modal
        span2.onclick = function() {
            modal2.style.display = "none";
        };

        // When the user clicks anywhere outside of the modal, close it
        window.onclick = function(event) {
            if (event.target === modal2) {
                modal2.style.display = "none";
            }
        }


    </script>
@endsection
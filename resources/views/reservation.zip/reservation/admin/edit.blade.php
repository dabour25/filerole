@extends('layouts.admin', ['title' => __('strings.add_reservation')])
@section('styles')

  <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.10/css/select2.min.css" rel="stylesheet" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/16.0.0/css/intlTelInput.css" rel="stylesheet" />
  <style>
    .modal {
            display: none; /* Hidden by default */

        }



  .staff-time {
width: calc(20% - 6px);
padding: 7px 10px;
border: 1px solid #ddd;
display: inline-block;
margin: 3px;
text-align: center;
cursor: pointer;
}
  .datepicker-inline {
       width: 100% !important;
  }

  @primary-color:#63a2cb;
  @secondary-color: #67d5bf;
  /*basic reset*/
  * {margin: 0; padding: 0;}

  /*form styles*/
  #msform {
  	width: 100%;
  	margin: 50px auto;
  	text-align: center;
  	position: relative;
  }
  #msform fieldset {
  	background: white;
  	border: 1px solid #cecdcd;
      border-top: 0px;
      padding: 15px 13px;
      width:100%;
  	box-sizing: border-box;
      left:0px;

  }
  .selected-staff-item .summary-icon
  {
      padding: 0px 5px;
      color: #0393d6;
      font-size: 16px;
  }
  @media only screen and (max-width:767px)
  {
      #msform fieldset
      {
          width:100%;
      }
      .book_records
      {
          display:none;
      }
  }
  /*Hide all except first fieldset*/
  #msform fieldset:not(:first-of-type) {
  	display: none;
  }
  /*inputs*/
  #msform input, #msform textarea {
  	padding: 15px;
  	border: 1px solid #ccc;
  	border-radius: 3px;
  	margin-bottom: 10px;
  	width: 100%;
  	box-sizing: border-box;
  	color: #2C3E50;
  	font-size: 13px;
  }
  /*buttons*/
  #msform .action-button {
  	width: 160px;
  	background: #04a564;
  	font-weight: bold;
  	color: white;
  	border: 0 none;
  	border-radius: 1px;
  	cursor: pointer;
  	padding: 10px 5px;
  	margin: 10px 5px;
  }
  #msform .action-button:hover, #msform .action-button:focus {
  	box-shadow: 0 0 0 2px white, 0 0 0 3px @secondary-color;
  }
  /*headings*/
  .fs-title {
  	font-size: 16px;
  	text-transform: uppercase;
  	color: @primary-color;
  	margin-bottom: 10px;
  }
  .fs-subtitle {
  	font-weight: normal;
  	font-size: 14px;
  	color: #666;
  	margin-bottom: 20px;
  }
  /*progressbar*/
  #progressbar {
  	margin-bottom: 30px;
  	overflow: hidden;
  	/*CSS counters to number the steps*/
  	counter-reset: step;
  }
  #progressbar li {
  	list-style-type: none;
  	color: white;
  	text-transform: uppercase;
  	font-size: 9px;
  	width: 10%;
  	float: left;
  	position: relative;
  }
  #progressbar li:before {
  	content: counter(step);
  	counter-increment: step;
  	width: 20px;
  	line-height: 20px;
  	display: block;
  	font-size: 10px;
  	color: #333;
  	background: white;
  	border-radius: 3px;
  	margin: 0 auto 5px auto;
  }
  /*progressbar connectors*/
  #progressbar li:after {
  	content: '';
  	width: 100%;
  	height: 2px;
  	background: white;
  	position: absolute;
  	left: -50%;
  	top: 9px;
  	z-index: -1; /*put it behind the numbers*/
  }
  #progressbar li:first-child:after {
  	/*connector not needed before the first step*/
  	content: none;
  }
  /*marking active/completed steps green*/
  /*The number of the step and the connector before it = green*/
  #progressbar li.active:before,  #progressbar li.active:after{
  	background: @secondary-color;
  	color: white;
  }

  .help-block {
    font-size: .8em;
    color: #7c7c7c;
    text-align: left;
    margin-bottom: .5em;
  }
  hr
  {
      border:0 #d8d8d8 solid;
          border-top-width:1px;
          margin-top:10px;
          display: none;
  }
  .appoint-bg-panel .panel-heading
  {
      background:none;
      color:none;
  }
  .btn-appoint
  {
    font-size: 18px;
      color: #717171;
      border: 1px solid #ddd;
      padding: 10px;
      width: 100%;
      display: block;
      margin-bottom: 10px;
      background: #f3f3f3;
  }
  .multi-collapse
  {
      border: 1px solid #ddd;
      background: #f3f3f34d;
  }
  /* .position-abs
  {
      position:absolute;
  } */
  .clip-check
  {
      margin-bottom: 10px;
      margin-top: 10px;
      padding: 10px;

  }

  .clip-check {
      border-bottom: 1px solid #ddd;
  }

  .clip-check:last-child {
      border-bottom: 0px !important;
  }

  .sum-head
  {
      margin:0px;
      color: #fff;
      font-size: 15px;
      font-weight:bold;
      padding:18px;
  }
  .active-services
  {
      display:block;
      margin-bottom:10px;
  }
  .service-items span
  {

      cursor: pointer;
      /* padding: 7px; */
      border: 1px solid #bbb;
      font-size: 12px;
      display:block;
      line-height: 1;
      margin: 0 .14285714em;
      /* background-color: #f7f2cc; */
      background-image: none;
      /* padding: .5833em .833em; */
      color: #717171;
      text-transform: none;
      font-weight: 700;
      border: 0 solid transparent;
      border-radius: .28571429rem;
      -webkit-transition: background .1s ease;
      transition: background .1s ease;
      /* border: 1px solid #f5eca8; */
  }
  .service-items span:hover
  {
     color:#333333;
  }
  .service-items span i
  {
    color: rgba(0,0,0,0.4);
  }
  .appoint-bg-panel .panel-heading
  {
          font-size: 18px;
      padding: 20px;
  }
  .next
  {
      float:right;
  }
  .previous
  {
     float:left;
  }
  .staff-ul
  {
      list-style:none;
  }
  .staff-ul li input
  {
      display:none;

  }
  .staff-ul .active
  {
      font-weight: bold;
      color: white;
      background: #1193d6;
  }
  .staff-ul li label
  {
          padding: 10px;
      border: 1px solid #ddd;
      cursor:pointer;
  }
  .staff-time
  {
      width: calc(20% - 6px);
      padding: 7px 10px;
      border: 1px solid #ddd;
      display: inline-block;
      margin: 3px;
      text-align:center;
      cursor: pointer;

  }
  .staff-time:hover
  {
      background:#ddd;
  }

  .data-item tr td i {
      display:none;
  }

  .times
  {
      list-style:none;
      text-align: right;
  }
  .times input
  {
      display:none;
  }
  #InvoiceQuery
  {
      margin-bottom:0px !important;
  }
  .app-info
  {
      background:#f5f5f5;
      padding: 10px 20px;
          border-top: 3px solid #b5b5b5;
  }
  .app-info span:first-child
  {
      margin-right:40px;
  }
  .app-info div
  {
      margin-bottom:5px;
  }
  .inline
  {
      display:inline-block !important;
      width:auto !important;
  }
  .Book-appointment
  {
      width:150px !important;
      background: #04a564;
      font-weight: bold;
      color: white;
      border: 0 none;
      border-radius: 1px;
      cursor: pointer;
      padding: 10px !important;
      margin: 10px 5px;
  }
  .add_client
  {
      margin-top: 10px;
      border: 1px solid #cacaca;
      margin-bottom: 10px;
      background:#e6e6e6;
  }
  .add_client i
  {
      margin-right:10px;
  }
  .btn-disabled
  {
          background: #ddd !important;
      color: #6b6b6b !important;
  }
  .alert-warning
  {
      width:100%;
      text-align:center;
  }
  .time-disabled
  {
      background:#ddd;
      font-weight:600;
      cursor: no-drop;
  }
  .book_records
  {
      width: 100%;
      float: right;
      color: #ffffff;
      background-color:#fff;
      border-bottom: 1px solid #d4d4d4;
      border-radius: 0px;
  }

  .sum-body
  {
      padding:10px 10px;
  }
  .sum-body h4
  {
      margin: 0px;
      padding-bottom:0px;
      font-size: 15px;
      font-weight: bold;
      text-align: left;
      color: #616161;

  }
  .service-title
  {
      width:60%;
  }
  .service-items
  {
      background: #f3f3f3;
      width:100%;
      color: #454f5a;
      margin-top:5px;
  }

  .service-items td {
      padding: 10px;
      border-bottom: 1px solid #fff;
  }

  .service-items td i {
      color:#454f5a;
      transition: 0.1s ease-in-out;
  }

  .service-items td i:hover {
      color: rgb(236, 48, 48);
  }

  .staff-item span
  {
      cursor: pointer;
      /* padding: 7px; */
      border: 1px solid #bbb;
      font-size: 12px;
      display: block;
      line-height: 1;
      vertical-align: baseline;
      margin: 0 .14285714em;
      /* background-color: #f7f2cc; */
      background-image: none;
      /* padding: .5833em .833em; */
      color: #717171;
      text-transform: none;
      font-weight: 700;
      border: 0 solid transparent;
      border-radius: .28571429rem;
      -webkit-transition: background .1s ease;
      transition: background .1s ease;
      /* border: 1px solid #f5eca8; */
      margin: 3px;
      margin-left: 5px;
      margin-bottom: 10px;
  }
  .staff-items
  {
      width:100%;
  }
  .staff-items tr td
  {
      padding:10px;
      font-size: 13px;
      color: #717171;
  }
  .booking-notes
  {
      padding:15px;
      background-color:gray;
  }
  .staff-items tr td i
  {
      color:#454f5a;
  }
  .td16
  {
      width:20%;
  }
  .sum-body table tr
  {
      cursor:pointer;
  }
  .staff-items
  {
      border-bottom: 1px solid #dadada;
      width: 100%;
      color: #454f5a;
      font-weight:bold;
      font-size:15px;
  }
  .data-item
  {
      width: 100%;
      color: #454f5a;
  }
  .data-item i
  {
      color:#454f5a;
  }

  .data-item i:hover, .staff-items tr td i:hover {
      color: rgb(248, 77, 77)
  }


  .data-item tr td
  {
      vertical-align:top;
  }
  .value-color
  {
          color: #0393d6;
      font-weight: bold;
  }
  .icon-sum
  {
      padding: 0px 5px;
      color: #0393d6 !important;
      font-size:16px;
  }
  .client-search .bootstrap-select:not([class*="col-"]):not([class*="form-control"]):not(.input-group-btn)
  {
      width:100% !important;
  }
  .time-disabled{
      background: #dadada;
  }
  .active-time{
      background: #0193d6;
      color: #fff;
      font-weight: bold;
  }

  .progress-par {
      margin: 30px 0;
      overflow: hidden;
      display: flex;
  }

  .progress-par .step {
      float: left;
      /* width: calc(50% - 28px); */
      flex: 1 0 0px;
  }

  .progress-par .step.last {
      width: 50px;
      flex:0;
  }
  .progress-par .step .circle {
      display: block;
      width: 50px;
      height: 50px;
      border-radius: 50%;
      border: 2px solid #12ade6;
      float: left;
      text-align: center;
      line-height: 50px;
  }

  .progress-par .step.active .circle {
      border: 2px solid #04a564;
  }

  .progress-par .step.active.done .circle {
      background: #04a564;
  }



  .progress-par .step .circle .fa {
      color: #12ade6;
      font-size: 16px;
  }

  .progress-par .step.active .circle .fa {
      color: #04a564;
  }

  .progress-par .step.active.done .circle .fa {
      color: #fff;
  }

  .progress-par .step .line {
      display: block;
      width: calc(100% - 50px);
      height: 2px;
      background: #12ade6;
      margin-top: 23px;
      float: left;
  }

  .progress-par .step.active .line {
      background: #04a564;
  }
  #selected-staff
  {
      margin-top:10px;
  }
  #selected-staff, #date {

      border-bottom: 0px;
      background: #f3f3f3;
      margin-top:10px;
  }

  #date td {
      padding: 10px;
  }

  h3 {
      margin-bottom: 30px;
  }

  .ui-datepicker {
      width: 100%;
      margin-bottom: 30px;
  }

  .ui-state-active, .ui-widget-content .ui-state-active, .ui-widget-header .ui-state-active {
      background: #12ade6 !important;
      color: #fff;
  }

  .ui-widget-header, .ui-state-default, .ui-widget-content .ui-state-default, .ui-widget-header .ui-state-default {
      background: none;
  }
  .btn-disabled:hover
  {
      cursor:not-allowed !important;
  }

  .alert-danger {
      font-weight: bold;
      padding: 10px;
  }
      /* The snackbar - position it at the bottom and in the middle of the screen */
      #snackbar {
          visibility: hidden; /* Hidden by default. Visible on click */
          min-width: 250px; /* Set a default minimum width */
          margin-left: -125px; /* Divide value of min-width by 2 */
          background-color: #333; /* Black background color */
          color: #fff; /* White text color */
          text-align: center; /* Centered text */
          border-radius: 2px; /* Rounded borders */
          padding: 16px; /* Padding */
          position: fixed; /* Sit on top of the screen */
          z-index: 1050; /* Add a z-index if needed */
          left: 50%; /* Center the snackbar */
          bottom: 30px; /* 30px from the bottom */
      }

      /* Show the snackbar when clicking on a button (class added with JavaScript) */
      #snackbar.show {
          visibility: visible; /* Show the snackbar */
          /* Add animation: Take 0.5 seconds to fade in and out the snackbar.
         However, delay the fade out process for 2.5 seconds */
          -webkit-animation: fadein 0.5s, fadeout 0.5s 2.5s;
          animation: fadein 0.5s, fadeout 0.5s 2.5s;
      }

      /* Animations to fade the snackbar in and out */
      @-webkit-keyframes fadein {
          from {bottom: 0; opacity: 0;}
          to {bottom: 30px; opacity: 1;}
      }

      @keyframes fadein {
          from {bottom: 0; opacity: 0;}
          to {bottom: 30px; opacity: 1;}
      }

      @-webkit-keyframes fadeout {
          from {bottom: 30px; opacity: 1;}
          to {bottom: 0; opacity: 0;}
      }

      @keyframes fadeout {
          from {bottom: 30px; opacity: 1;}
          to {bottom: 0; opacity: 0;}
      }

  </style>
@endsection
@section('content')


    <div class="modal newModel"  id="myModal3" role="dialog">
          <div class="modal-dialog">
              <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" onclick="close_modal()">&times;</button>
              </div>
              <!-- Modal content-->
              <div class="modal-content">
                  <div class="modal-body" style="overflow: hidden">
                      <form method="post" action="#" enctype="multipart/form-data" id="add_customer_store2">
                          {{csrf_field()}}
                          <input type="hidden" class="form-control" name="user_id" value="{{  Auth::user()->id }}">
                          <input type="hidden" class="form-control" name="active" value="1">

                          <div class="col-md-6 form-group{{$errors->has('name') ? ' has-error' : ''}}"> <strong class="text-danger">*</strong>
                              <label class="control-label" for="name">{{ __('strings.Arabic_name') }}</label>
                              <input type="text" class="form-control" name="name" value="{{old('name')}}" required>
                              @if ($errors->has('name'))
                                  <span class="help-block">
                                      <strong class="text-danger">{{ $errors->first('name') }}</strong>
                                  </span>
                              @endif
                          </div>

                          <div class="col-md-6 form-group{{$errors->has('name_en') ? ' has-error' : ''}}">
                              <label class="control-label" for="name_en">{{ __('strings.English_name') }}</label>
                              <input type="text" class="form-control" name="name_en" value="{{old('name_en')}}" required>
                              @if ($errors->has('name_en'))
                                  <span class="help-block">
                                      <strong class="text-danger">{{ $errors->first('name_en') }}</strong>
                                  </span>
                              @endif
                          </div>

                          <div class="col-md-6 form-group{{$errors->has('email') ? ' has-error' : ''}}"> <strong class="text-danger">*</strong>
                              <label class="control-label" for="email">{{ __('strings.Email') }}</label>
                              <input type="text" class="form-control" name="email" value="{{old('email')}}" required>
                              @if ($errors->has('email'))
                                  <span class="help-block">
                                      <strong class="text-danger">{{ $errors->first('email') }}</strong>
                                  </span>
                              @endif
                          </div>

                          <div class="col-md-6 form-group{{$errors->has('gender') ? ' has-error' : ''}}"> <strong class="text-danger">*</strong>
                              <label class="control-label" for="gender">{{ __('strings.Gender') }}</label>
                              <select class="form-control" name="gender" required>
                                  <option value="1">{{ __('strings.Male') }}</option>
                                  <option value="0">{{ __('strings.Female') }}</option>
                              </select>
                              @if ($errors->has('gender'))
                                  <span class="help-block">
                                      <strong class="text-danger">{{ $errors->first('gender') }}</strong>
                                  </span>
                              @endif
                          </div>

                          <div class="col-md-6 form-group{{$errors->has('address') ? ' has-error' : ''}}"> <strong class="text-danger">*</strong>
                              <label class="control-label" for="address">{{ __('strings.Address') }}</label>
                              <input type="text" class="form-control" name="address" value="{{old('address')}}" required>
                              @if ($errors->has('address'))
                                  <span class="help-block">
                                      <strong class="text-danger">{{ $errors->first('address') }}</strong>
                                  </span>
                              @endif
                          </div>

                          <div class="col-md-12 form-group{{$errors->has('phone_number') ? ' has-error' : ''}}"> <strong class="text-danger">*</strong>
                              <label class="control-label" for="phone_number">{{ __('strings.Phone') }}</label>
                              <input type="tel" class="form-control" name="phone_number" id="phone" value="{{old('phone_number')}}" required>
                              <span id="valid-msg" class="hide">✓ صالح</span>
                              <span id="error-msg" class="hide"></span>

                              @if ($errors->has('phone_number'))
                                  <span class="help-block">
                                      <strong class="text-danger">{{ $errors->first('phone_number') }}</strong>
                                  </span>
                              @endif
                          </div>
                          <div class="col-md-6 form-group{{$errors->has('signs') ? ' has-error' : ''}}">
                                  <label>{{__('strings.country')}}<strong class="text-danger">*</strong></label>
                                  <select required name="country_id" class="select-search">
                                      @foreach($countries as $country)
                                          @php
                                              $country_session = Session::has('country')  ? session('country') : 'EG';
                                          @endphp
                                          <option {{ $country_session == $country->code || old('country_id') == $country->id ? 'selected' : ''}} value="{{$country->id}}">{{ app()->getLocale() == 'ar' ? $country->name  : $country->name_en  }}</option>
                                          @endforeach
                                  </select>
                              </div>


                           <div class="col-md-6 form-group{{$errors->has('signs') ? ' has-error' : ''}}">
                                  <label>{{__('strings.city')}}<strong class="text-danger">*</strong></label>
                                  <input type="text" placeholder="" required name="city" value="{{ Session::has('city')  ? session('city') : 'EG' }}">
                              </div>
                          <div class="col-md-12 form-group text-right">
                              <button type="submit" class="btn btn-primary btn-lg" id="add_customer_submit2">{{ __('strings.Save') }}</button>
                          </div>
                      </form>
                  </div>
              </div>
          </div>
    </div>


    <!-- Progress par for booking steps -->

    <div class="container">

      <div class="col-md-8 progress-par">
      	<div class="step step-1 active done">
      		<span class="circle"><i class="fa fa-plus"></i></span>
      		<span class="line"></span>
      	</div>

      	<div class="step step-2">
      		<span class="circle"><i class="fa fa-user"></i></span>
      		<span class="line"></span>
      	</div>

      	<div class="step  step-3">
      		<span class="circle"><i class="fa fa-calendar"></i></span>
      				<span class="line"></span>
      			</div>
      		<div class="step last step-4">

      		<span class="circle"><i class="fa fa-check"></i></span>

      	</div>

      </div>
        <form id="msform" method="post" action="{{url('/admin/reservations/update')}}">
        {{csrf_field()}}
        <input type="hidden" name="reservation_id" value="{{$reservation->id}}">
            <div class="row">
                <div class="col-md-8">
                     <div class="panel-default appoint-bg-panel">
                               <div class="panel-heading text-left ">
                          موعد جديد			</div>
                    </div>
                          <div class="main-field">

                    <fieldset>
        			<h3 style="margin-bottom:30px;" class="text-left">إختر خدمة</h3>

        			            <div class="form-group">
        @foreach($services as $service)
                          <a class="btn-appoint text-left" data-toggle="collapse" href="#multiCollapse{{$service->id}}" role="button">
                            {{app()->getLocale()=='ar'?$service->name:$service->name_en}}
                          </a>


                         <div class="collapse multi-collapse" id="multiCollapse{{$service->id}}">
                               @foreach($service->categories  as $category)
                                <div class="card card-body">

        														<div class="clip-check check-info text-left">

                                      <input type="hidden" class="service-input" name="" id="SiteEnableInvoiceStatus1_">

                                         <input data-duration="{{$category->time}}" data-price="{{$category->price}}" value="{{$category->id}}" type="checkbox" name="cat_id[]" class="service-input INPUT service-input-{{$category->id}} form-control " onchange="add_selected(this)" id="SiteEnableInvoiceStatus1">

                                         <label for="SiteEnableInvoiceStatus1">{{app()->getLocale()=='ar'?$category->name:$category->name_en}}</label><span id="enable_invoice_link">

                                            </span>

                                     </div>

                                </div>
                                @endforeach
                              </div>

                                @endforeach

                    </div>


        			<input type="button" name="next" data-step="2" id="serviceNext" data-error="من فضلك إختر خدمة واحدة على الأقل" class="ignore-handler next-btn next btn-disabled action-button" value="التالي">

        	</fieldset>
        	<fieldset>
        				<h3 class="text-left">{{__('strings.choose_captin')}}</h3>
                    <hr>
                    <ul class="staff-ul text-left">
                                 @foreach($captins as $captin)
        				                <li class="staff-item staff-item-{{$captin->id}}">
                            <input class="staff_id" id="{{$captin->id}}" name="captin_id" value="{{$captin->id}}"  type="radio">
                             <label>{{app()->getLocale()=='ar'?$captin->name:$captin->name_en}}</label>
                        </li>
                      @endforeach
        				            </ul>
                   <input type="button" data-step="3" name="previous" class="previous action-button" value="السابق">
        		   <input type="button" data-step="3" name="next" id="staffNext" data-error="من فضلك قم بإختيار موظف" class="ignore-handler btn-disabled staff-next next next-btn next action-button" value="التالي">



        	</fieldset>
        	<fieldset>
            <h3 class="text-left">{{__('strings.choose_date')}}</h3>
                          <input type="hidden" name="date" id="AddAppointment" placeholder="Select Date For This Appointment">
                          <div id="dateDiv" class="hasDatepicker">
                          </div>
                            <div class="form-group">
                              <ul id="times" class="times">
                              </ul>
                            </div>
                            <input type="button" data-step="4" name="previous" class="previous action-button" value="السابق">
                            <input type="button" name="next" data-step="4" id="timeNext" data-error="من فضلك كم بإختيار يوم وساعة من أجل الحجز" class="ignore-handler next btn-next next btn-disabled  action-button" value="التالي">
                          </fieldset>

                          <fieldset>
                                   <h3 class="text-left">{{__('strings.choose_customer')}}</h3>
                           <div class="client-search">
                             <label for="client_selectpicker">{{__('strings.customer')}}</label>
                             <select name="customer" id="client_selectpicker" class="form-control" onchange="change_customer()" data-live-search="true" data-width="auto" title="{{__('strings.choose_customer')}}">
                               <option value="0">{{__('strings.choose_customer')}}</option>
                               @foreach($customers as $customer)
                                 <option value="{{$customer->id}}" {{$customer->id==$reservation->cust_id?'selected':''}}>{{app()->getLocale()=='ar'?$customer->name:$customer->name_en}}</option>
                               @endforeach
                             </select>
                           </div>
                           <div class="text-left">
                             <button type="button" class="btn btn-info btn-lg NewBtn btnclient" onclick="customer_modal()">{{__('strings.customer')}}<i class="fas fa-plus"></i></button>

                           </div>
                           <br>
                           <h3 class="text-left"> ملاحظات الحجز</h3>
                           <textarea name="description" style="height:100px"></textarea>
                           <input type="button" data-step="5" name="previous" class="previous action-button" value="السابق">
                           <input id="finish" type="submit" name="next" data-error= "من فضلك اختر العميل" class="ignore-handler  next action-button" value="انهي الحجز">
                </fieldset>
              </div>

                </div>
                <div class="col-md-4">

                <div class=" book_records">
                     <h4 class="sum-head appoint-bg-panel">تفاصيل الحجز</h4>
                              <div class="sum-body">
                                  <!--make this section display none and show it when selection is done !-->
                                    <section class="services-sec">
                                     <h4><i class="fa fa-list-ul icon-sum"></i><span style="display:inline-block">الخدمات المختارة</span></h4>
                                     <table class="service-items text-left">

                                     </table>
                                    </section>
                                    <!--make this section display none and show it when selection is done !-->
                                    <section class="staff-sec">
                                        <table class="staff-items text-left " id="selected-staff">
                                          <tr data-id="1">
                                                                      <td class="selected-staff-item" width="60%">
                                                                          <span><i class="fa fa-user summary-icon"></i>{{app()->getLocale()=='ar'?$reserved_captin->name:$reserved_captin->name_en}}</span>
                                                                      </td>

                                        </table>
                                    </section>
                                     <!--make this section display none and show it when selection is done !-->
                                     <section class="dtime-sec">

                                        <table id="date" class="data-item text-left">
                                          <tbody>
                                          <td class="staff-item" width="60%">
                        <i class="fa fa-calendar summary-icon icon-sum"></i>{{$reservation->reservation_date}}
                                          </td>
                                          <td class="td16 value-color">
                        {{time_from_id($start_id)}}
                                          </td>
                                          <td class="td16 value-color">
                      {{time_from_id($end_id)}}
                                          </td>
                                          <td>
                                              <i class="fa fa-times"></i>
                                          </td>
                                      </tr>
                                    </tbody>
                                        </table>
                                    </section>
                               </div>
                         </div>


                </div>
            </div>

        	<!-- progressbar -->
        </form>
    </div>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/16.0.0/js/intlTelInput.js"></script>
    <script>
           $(document).ready(function () {

  $("#client_selectpicker").select2({
  tags: true,

});

});
var lang = $('meta[name="lang"]').attr('content');
  var input = document.querySelector("#phone"),
                errorMsg = document.querySelector("#error-msg"),
                validMsg = document.querySelector("#valid-msg");

            var errorMap = ["☓ رقم غير صالح", "☓ رمز البلد غير صالح", "☓ قصير جدا", "☓ طويل جدا", "☓ رقم غير صالح"];

            var iti = window.intlTelInput(input, {
                initialCountry: "auto",
                geoIpLookup: function(callback) {
                    $.get('https://ipinfo.io', function() {}, "jsonp").always(function(resp) {
                        var countryCode = (resp && resp.country) ? resp.country : "";
                        callback(countryCode);
                    });
                },
                utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/16.0.0/js/utils.js"
            });

            var reset = function() {
                input.classList.remove("error");
                errorMsg.innerHTML = "";
                errorMsg.classList.add("hide");
                validMsg.classList.add("hide");
            };

            input.addEventListener('blur', function() {
                reset();
                if (input.value.trim()) {
                    if (iti.isValidNumber()) {
                        validMsg.classList.remove("hide");
                    } else {
                        input.classList.add("error");
                        var errorCode = iti.getValidationError();
                        errorMsg.innerHTML = errorMap[errorCode];
                        errorMsg.classList.remove("hide");
                    }
                }
            });

            input.addEventListener('change', reset);
            input.addEventListener('keyup', reset);

  $('#add_customer_submit2').click(function() {
                $("#add_customer_store2").ajaxForm({
                    url: '/admin/ajax/add_customer', type: 'post',
                    beforeSubmit: function (response) {
                        if(iti.isValidNumber() == false) {
                            alert("Please check your phone again");
                            return false;
                        }
                    },
                    success: function (response) {
                        var modal2 = document.getElementById('myModal3');
                        modal2.style.display = "none";
                        if(lang=='ar'){
                             $("#client_selectpicker").append('<option selected="selected" value='+ response.data.id + '>' +response.data.name + '</option>');
                        }
                        else{
                            $("#client_selectpicker").append('<option selected="selected" value='+ response.data.id + '>' +response.data.name_en + '</option>');
                        }
                        $('#client_selectpicker').val(response.data.id);
                        $('#client_selectpicker').trigger('change');

                    },
                    error: function (response) {
                        alert("Please check your entry date again");
                    }
                })
            });
    </script>


    <script src="{{ asset('js/jqueryui.js')}}"></script>
    <script src="{{ asset('js/app3.js')}}"></script>
    <script src="{{ asset('js/perfect-scrollbar.jquery.min.js')}}"></script>
    <script src="{{ asset('js/functions_v2.js')}}"></script>
    <script src="{{ asset('js/daterangepicker.js')}}"></script>
    <script src="{{ asset('js/app2.js')}}"></script>
    <script src="{{ asset('js/functions_ajax_v1.js')}}"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js" type="text/javascript"></script>
    <script src="{{ asset('js/booking-add-steps.js') }}"></script>
    <script src="{{ asset('js/booking-edit.js') }}"></script>
@endsection

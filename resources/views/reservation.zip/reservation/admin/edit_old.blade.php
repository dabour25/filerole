@extends('layouts.admin', ['title' =>__('strings.dashboard')])

@section('content')
    <style>
        .form-group select,.form-group input{
            display: block;
            width: 100%;
            height: 34px;
            padding: 6px 12px;
            font-size: 14px;
            line-height: 1.42857143;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        /* The Modal (background) */
        .modal {
            display: none; /* Hidden by default */
            position: fixed; /* Stay in place */
            z-index: 1; /* Sit on top */
            left: 0;
            top: 0;
            width: 100%; /* Full width */
            height: 100%; /* Full height */
            overflow: auto; /* Enable scroll if needed */
            background-color: rgb(0,0,0); /* Fallback color */
            background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
        }

        /* Modal Content/Box */
        .modal-content {
            background-color: #fefefe;
            margin: 15% auto; /* 15% from the top and centered */
            padding: 20px;
            border: 1px solid #888;
            width: 80%; /* Could be more or less, depending on screen size */
        }

        /* The Close Button */
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }
        .radios{
            margin: 20px;
        }
        .radio-inline{
            padding-left: 56px;
        }
        input#confirm{
            height: auto;
        }
        .staff-time {
    width: calc(20% - 6px);
    padding: 7px 10px;
    border: 1px solid #ddd;
    display: inline-block;
    margin: 3px;
    text-align: center;
    cursor: pointer;
  }
  .times {
    list-style: none;
    text-align: right;
  }
  .start-time  {
    padding: 15px;
    border: 1px solid #ccc;
    border-radius: 3px;
    margin-bottom: 10px;
    width: 100%;
    box-sizing: border-box;
    color: #2C3E50;
    font-size: 13px;
  }
  span.help-block.date-error {
      display: none;
  }
  .row {
      width: 100%;
  }
  span.help-block.date-error2 {
display: none;
}
    </style>

    <!--<div class="page-title">-->
    <!--    <h3>@lang('strings.edit_reservation') </h3>-->
    <!--</div>-->
    <div id="main-wrapper" style="display: flex;justify-content: center;align-content: center">
        <div class="row">
            <form method="post" action="{{ url('/admin/reservations') }}/{{ $reservation->id }}" id="reservation_form">
                @csrf
                @method('PUT')
                <div class="form-group">
                  <input type="hidden" name="reservation_id" value="{{$reservation->id}}">
                    <label style="display: block">@lang('strings.Client_name')</label>
                    <select class="form-control js-select" name="customer" required>
                        <option value="">@lang('strings.Select_client')</option>
                        @foreach($customers as $customer)
                            @if($reservation->cust_id == $customer->id)
                                <option value="{{$customer->id}}" selected>{{ app()->getLocale() == 'ar' ? $customer->name  : $customer->name_en  }}</option>
                            @else
                                <option value="{{$customer->id}}">{{ app()->getLocale() == 'ar' ? $customer->name  : $customer->name_en  }}</option>
                            @endif
                        @endforeach
                    </select>
                </div>
                <div class="form-group">
                    <label for="category" style="display: block">@lang('strings.choose_cat_type')</label>
                    <select class="custom-select js-select" name="category_types" id="category_types">
                        <option selected disabled>@lang('strings.Select') ...</option>
                        @foreach($services as $service)
                            @if($reservation->category_type_id == $service->id)
                                <option value="{{ $service->id }}" selected>{{ app()->getLocale() == 'ar' ? $service->name  : $service->name_en  }}</option>
                            @else
                                <option value="{{ $service->id }}">{{ app()->getLocale() == 'ar' ? $service->name  : $service->name_en  }}</option>
                            @endif
                        @endforeach
                    </select>
                </div>
                <div class="form-group">
                    <label style="display: block">@lang('strings.choose_cat')</label>
                    <select class="form-control js-select" name="category" id="categoriess">
                        <option value="">@lang('strings.Select') ...</option>
                        @foreach($categories as $category)
                            @if($reservation->cat_id == $category->id)
                                <option value="{{ $category->id }}" selected>{{ app()->getLocale() == 'ar' ? $category->name  : $category->name_en  }}</option>
                            @else

                                <option value="{{ $category->id }}">{{ app()->getLocale() == 'ar' ? $category->name  : $category->name_en  }}</option>
                            @endif
                        @endforeach
                    </select>
                </div>
                <div class="form-group">
                    <label for="captain" style="display: block">@lang('strings.choose_catpatin')</label>
                    <select class="custom-select js-select" name="captain" id="captain">
          @foreach($captainsAvailable as $value)
          <option {{ $reservation->captain_id == $value->id ? 'selected' : '' }}  value="{{ $value->id }}">{{ app()->getLocale() == 'ar' ? $value->name  : $value->name_en  }}</option>

          @endforeach
                    </select>
                </div>
                <div class="form-group">
                    <label for="date" style="display: block">@lang('strings.choose_date')</label>
                    <input type="date" name="date" id="date" class="form-control" value="{{ $reservation->reservation_date }}">
                    <span class="help-block date-error">
                        <strong class="text-danger"> @lang('strings.Message_date')</strong>
                    </span>
                    <span class="help-block date-error2">
                        <strong class="text-danger2"> @lang('strings.no_times_available')</strong>
                    </span>
                </div>

                <div class="form-group" id="time_form">
                    <label class="control-label" for="time">@lang('strings.Time')</label>
                    <p id="date-text"></p>
                    <div class="timeline_new">
                      <ul id="times2" class="times"></ul>
                </div>
                <div class="form-group">
                  <button type="submit" class="btn btn-primary">@lang('strings.Confirm')</button>
                </div>
                {{-- <div id="myModal" class="modal">
                    <!-- Modal content -->
                    <div class="modal-content">
                        <span class="close">&times;</span>
                        <div class="form-group">
                            <label for="comment">@lang('strings.add_comment') </label>
                            <textarea class="form-control" rows="5" name="comment" id="comment"></textarea>
                        </div>
                        <button id="add_check_button" type="button" class="btn btn-primary">@lang('strings.Save')</button>
                    </div>
                </div> --}}
                {{-- <div id="myModal2" class="modal">
                    <!-- Modal content -->
                    <div class="modal-content">
                        <span class="close2">&times;</span>
                        <div class="form-group">
                            <label id="confirmation" for="radios" style="margin-bottom: 10px"></label>
                            <div class="custom-radio" id="radios">
                                <label class="radio-inline"><input type="radio" name="confirm" id="confirm" value="y" checked>@lang('strings.Yes')</label>
                                <label class="radio-inline"><input type="radio" name="confirm" id="confirm" value="n">@lang('strings.No')</label>
                            </div>
                        </div>

                    </div>
                </div> --}}

            </form>
        </div>
    </div>

@endsection

@section('scripts')
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
    <script>
    function validateDate() {
        var del_date = document.getElementById('date').value;
        var yesterday = (function () {
            this.setDate(this.getDate() - 1);
            return this;
        }).call(new Date);

        if (Date.parse(del_date) < yesterday) {
            return false;
        } else {
            return true;
        }
    };


   
  




</script>

@endsection

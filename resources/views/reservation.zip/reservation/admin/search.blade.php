@extends('layouts.admin', ['title' => __('strings.dashboard')])
<!-- Last Modified  02/05/2019 15:14:52  -->
@section('content')
    <style>
    
  
        .panel-body form{
            padding: 20px;
        }
        .panel-body button,.panel-body a{
            margin-left: 20px;
            padding: 6px 20px;
            font-size: 15px;
        }
        #search_form > div.col-md-12.form-group.text-right > div{
            float: left;
            font-size: 1.2em;
            font-weight: 600;
            color: red;
            display: none;
        }
    </style>
    
   
     <div class="main_wrapper">  
     <div id="message"></div>
        <div class="panel panel-white">
            <div class="panel-body">
                <form method="post" action="" enctype="multipart/form-data" id="search_form">
                    {{csrf_field()}}
                    <div class="row">
                        <div class="col-lg-3 col-md-4 col-sm-6 m-b-sm">
                            <label>@lang('strings.customer_phone_no')</label>
							
                            <select class="form-control js-select " name="phone_number">
                                <option value="0">@lang('strings.All')</option>
                                @foreach($customers as $customer)
                       <option {{ app('request')->input('phone_number') == $customer->phone_number ? 'selected' : ''}} value="{{$customer->phone_number}}">{{$customer->phone_number}}</option>    
								
								
								@endforeach
                            </select>
                        </div>
                        <div class="col-lg-3 col-md-4 col-sm-6 m-b-sm">
                            <label>@lang('strings.choose_membership_no')</label>
                            <select class="form-control  js-select " name="cust_code">
                                <option value="0">@lang('strings.All')</option>
                                @foreach($customers as $customer)
                                 <option {{ app('request')->input('cust_code') == $customer->cust_code ? 'selected' : ''}}  value="{{$customer->cust_code}}">{{$customer->cust_code}}</option>   
	
                                @endforeach
                            </select>
                        </div>
                        <div class="col-lg-3 col-md-4 col-sm-6 m-b-sm">
                            <label>@lang('strings.Client_name')</label>
                            <select class="form-control js-select" name="customer">
                                <option value="0">@lang('strings.All')</option>
                                @foreach($customers as $customer)
                 <option {{ app('request')->input('customer') == $customer->id ? 'selected' : ''}} value="{{$customer->id}}">{{ app()->getLocale() == 'ar' ? $customer->name  : $customer->name_en  }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-lg-3 col-md-4 col-sm-6 m-b-sm">
                            <label>@lang('strings.reservation_captain')</label>
                            <select class="form-control js-select" name="captain">
                                <option value="0">@lang('strings.All')</option>
                                @foreach($captains as $captain)
                                    <option {{ app('request')->input('captain') == $captain->id ? 'selected' : ''}} value="{{$captain->id}}">{{ app()->getLocale() == 'ar' ? $captain->name  : $captain->name_en  }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-lg-3 col-md-4 col-sm-6 m-b-sm">
                            <div class="input-group text">
                                <label>@lang('strings.Date_too')</label>
                                <input name="date_to" id="date_to" type="date" value="{{ app('request')->input('date_to') }}" class="form-control">
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-4 col-sm-6 m-b-sm">
                            <div class="input-group text">
                                <label>@lang('strings.Date_fromm')</label>
                                <input name="date_from" id="date_from" type="date" value="{{ app('request')->input('date_from') }}" class="form-control">
                            </div>
                        </div>
                    </div>

                    <div class="col-md-12 form-group text-right">
                        <div class="date_error">
                            @lang('strings.Message_date')
                        </div>
                        <button id="search_button" type="submit" class="btn btn-primary"> <i class="fas fa-search"></i> @lang('strings.Search')</button>
                        <a href="{{ url('/admin/reservations/create') }}" type="button" class="btn btn-primary"> <i class="fa fa-plus"></i> @lang('strings.add_reservation')</a>
                    </div>


                </form>
            </div>

        </div>
        <div class="panel panel-white">
            <div class="panel-heading clearfix">
                <h4 class="panel-title">@lang('strings.reservation')</h4>
            </div>
            <div class="panel-body">
                <div class="table-responsive">
                    <table id="xtreme-table" class="display table"
                           style="width: 100%; cellspacing: 0;">
                        <thead>
                        <tr>
                         <th>@lang('strings.reservation_no')</th>
                        <!--<th>@lang('strings.reservation_category')</th>-->
                        <th>@lang('strings.Client_name')</th>
                         <th>@lang('strings.phone')</th>
                         <th>@lang('strings.Day')</th>
                        <th>@lang('Time')</th>
                        <th>@lang('strings.reservation_comment')</th>
                        <th>@lang('strings.reservation_captain')</th>
                        <th>@lang('strings.reservation_date')</th>
                        <th>@lang('strings.reservation_confirm')</th>
                        <th>@lang('strings.Settings')</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($reservations as $reservation)
                            <tr>
                                <td>{{ $reservation['id'] }}</td>
                                <!--<td>{{ $reservation['category'] }}</td>-->
                                 <!--   esraa   11-feb-2019-->
                               <td>{{ $reservation['customer'] }}</td>
                             <td>{{ $reservation['customer_phone'] }}</td>
                                <!--  End Esraa -->
                                <td>{{\Carbon\Carbon::parse($reservation['reservation_date'])->format('l')}}</td>
                                <td>{{ time_from_id(\App\ReserveDetails::where('reserve_id',$reservation['id'])->first()->av_time_from)==0?__('strings.with_precedenceof_attendance'):time_from_id(\App\ReserveDetails::where('reserve_id',$reservation['id'])->first()->av_time_from)}}</td>
                                <td>{{ $reservation['comment'] }}</td>
                                <td>{{ $reservation['captain'] }}</td>
                                <td>{{ $reservation['reservation_date'] }}</td>
                                <td>
                                    @if($reservation['confirm']=='y')
                                        <span class="label label-success" style="font-size:13px;">@lang('strings.confirmed2')</span>
                                    @elseif($reservation['confirm']=='c')
                                        <span class="label label-default" style="font-size:13px;background-color: #2a2a2a;border: none">@lang('strings.canceled')</span>
                                    @else
                                        <span class="label label-danger" style="font-size:13px;">@lang('strings.not_confirmed')</span>
                                    @endif
                                </td>
                                
                                <!--   esraa   11-feb-2019-->
                                <td>
                                    @if($reservation['confirm']=='y')
                                     <div class="dropdown">
                                        <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">@lang('strings.Settings')
                                            <span class="caret"></span></button>
                                        <ul class="dropdown-menu">
                                <li><a href="{{ url('/admin/reservations'). '/' . $reservation['id'] . '/show' }}">@lang('strings.show') <i class="fa fa-search" style="color: green"></i></a></li><li class="divider"></li>
                                   </ul>
                                    </div>
                                @elseif($reservation['confirm']=='n')
                                    <div class="dropdown">
                                        <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">الإعدادات
                                            <span class="caret"></span></button>
                                        <ul class="dropdown-menu">
                                            <li><a href="{{ url('/admin/reservations'). '/' . $reservation['id'] . '/show' }}">@lang('strings.show') <i class="fa fa-search" style="color: green"></i></a></li><li class="divider"></li>
                                            <!--<li><a href="{{ url('/admin/reservations'). '/' . $reservation['id'] . '/confirm' }}">@lang('strings.Confirm') <i class="fa fa-check" style="color: green"></i></a></li><li class="divider"></li>-->
                                             <li><button onclick="confirm_reservation({{$reservation['id']}})">@lang('strings.Confirm') <i class="fa fa-check" style="color: green"></i></button></li><li class="divider"></li>
                                            <li><a href="{{ url('/admin/reservations'). '/' . $reservation['id'] . '/edit' }}">@lang('strings.edit') <i class="fa fa-cog" style="color: blue"></i></a></li><li class="divider"></li>
                                            <li><a href="{{ url('/admin/reservations'). '/' . $reservation['id'] . '/cancel' }}">@lang('strings.Cancel') <i class="fa fa-times" style="color: red"></i></a></li>
                                        </ul>
                                    </div>
                                @endif
                            </td>
                                <!--  End Esraa -->
                                
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
				 {{ $reservations->appends(Illuminate\Support\Facades\Input::except('page'))->links() }}
                </div>
            </div>
        </div>
    </div>
@endsection

@section('scripts')
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
    <script>


        $('#search_button').click(function (e) {
            $check = validateDate();
            if($check !== true){
                $('#search_form > div.col-md-12.form-group.text-right > div').css({"display":"block"});
                e.preventDefault();
            }
        });

        function validateDate() {
            var date_from = document.getElementById('date_from').value;
            var date_to = document.getElementById('date_to').value;
            if(date_from === "" && date_to === ""){
                return true;
            }
            if (Date.parse(date_from) <= Date.parse(date_to)) {
                return true;
            }else{
                return false;
            }
        }
        $('.js-select').select2({
            minimumInputLength: 2,
        });

        
     
    </script>
    
@endsection

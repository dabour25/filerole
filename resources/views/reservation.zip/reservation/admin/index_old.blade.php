@extends('layouts.admin', ['title' =>__('strings.dashboard')])
<!-- Last Modified  02/05/2019 15:14:17  -->
@section('content')
    <style>
        .search_header{
            padding: 20px;
        }
        .search_header a{
            padding: 7px 23px;
            font-size: 16px;
        }
        #xtreme-table > tbody > tr > td:nth-child(9){
            padding: 7px!important;
        }
        .dropdown-menu .divider{
            margin: 4px 0;
        }
        /* <!-- Mostafa Change  02/06/2019 12:10:25  --> */
        #snackbar {
            visibility: hidden; /* Hidden by default. Visible on click */
            min-width: 250px; /* Set a default minimum width */
            margin-left: -125px; /* Divide value of min-width by 2 */
            background-color: #333; /* Black background color */
            color: #fff; /* White text color */
            text-align: center; /* Centered text */
            border-radius: 2px; /* Rounded borders */
            padding: 16px; /* Padding */
            position: fixed; /* Sit on top of the screen */
            z-index: 1; /* Add a z-index if needed */
            left: 50%; /* Center the snackbar */
            top: 18%; /* 30px from the bottom */
        }
        /* Show the snackbar when clicking on a button (class added with JavaScript) */
        #snackbar.show {
            visibility: visible; /* Show the snackbar */
            /* Add animation: Take 0.5 seconds to fade in and out the snackbar.
            However, delay the fade out process for 2.5 seconds */
            -webkit-animation: fadein 0.5s, fadeout 0.5s 2.5s;
            animation: fadein 0.5s, fadeout 0.5s 2.5s;
        }

        /* Animations to fade the snackbar in and out */
        @-webkit-keyframes fadein {
            from {top: 0; opacity: 0;}
            to {top: 18%; opacity: 1;}
        }

        @keyframes fadein {
            from {top: 0; opacity: 0;}
            to {top: 18%; opacity: 1;}
        }

        @-webkit-keyframes fadeout {
            from {top: 18%; opacity: 1;}
            to {top: 0; opacity: 0;}
        }

        @keyframes fadeout {
            from {top: 18%; opacity: 1;}
            to {top: 0; opacity: 0;}
        }
        /* End of Mostafa Change <!-- Last Modified  02/06/2019 12:10:25  --> */

    </style>
    <div class="panel panel-white">
        <div class="panel-heading clearfix">
            <h4 class="panel-title">@lang('strings.reservation')</h4>
        </div>
        <div class="panel-body">
            <div class="search_header">
                @if (session('confirm_status'))
                    <div class="" id="snackbar"><p>{{ session('confirm_status') }} <i class="fa fa-times" style="color: red"></i></p></div>
                @endif
                
                <a href="{{ url('/admin/reservations/search') }}" type="button" class="btn btn-primary">@lang('strings.reservation')</a>
                <a href="{{ url('/admin/reservations/create') }}" type="button" class="btn btn-primary" style="margin-right: 20px">@lang('strings.reservation_add')</a>
            </div>
            <div class="table-responsive">
                <table id="xtreme-table" class="display table"
                       style="width: 100%; cellspacing: 0;">
                    <thead>
                    <tr>
                        <th>@lang('strings.reservation_no')</th>
                        <th>@lang('strings.reservation_category')</th>
                        <th>@lang('strings.Client_name')</th>
                        <th>@lang('strings.phone')</th>
                        <th>@lang('strings.Day')</th>
                        <th>@lang('Time')</th>
                        <th>@lang('strings.reservation_comment')</th>
                        <th>@lang('strings.reservation_captain')</th>
                        <th>@lang('strings.reservation_date')</th>
                        <th>@lang('strings.reservation_confirm')</th>
                        <th>@lang('strings.Settings')</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($reservations as $reservation)
                        <tr>
                            <td>{{ $reservation['id'] }}</td>
                            <td>{{ $reservation['category'] }}</td>
                             <td>{{ $reservation['customer'] }}</td>
                             <td>{{ $reservation['customer_phone'] }}</td>
                            <td>{{ $reservation['day'] }}</td>
                            <td>{{ $reservation['time'] }}</td>
                            <td>{{ $reservation['comment'] }}</td>
                            <td>{{ $reservation['captain'] }}</td>
                            <td>{{ $reservation['reservation_date'] }}</td>
                            <td>
                                @if($reservation['confirm']=='y')
                                    <span class="label label-success" style="font-size:13px;">@lang('strings.confirmed2')</span>
                                @elseif($reservation['confirm']=='c')
                                    <span class="label label-default" style="font-size:13px;background-color: #2a2a2a;border: none">@lang('strings.canceled')</span>
                                @else
                                    <span class="label label-danger" style="font-size:13px;">@lang('strings.not_confirmed')</span>
                                @endif
                            </td>
                            <td>
                                @if($reservation['confirm']=='n')
                                    <div class="dropdown">
                                        <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">@lang('strings.Settings')
                                            <span class="caret"></span></button>
                                        <ul class="dropdown-menu">
                                            <li><a href="{{ url('/admin/reservations'). '/' . $reservation['id'] . '/confirm' }}">@lang('strings.Confirm') <i class="fa fa-check" style="color: green"></i></a></li><li class="divider"></li>
                                            <li><a href="{{ url('/admin/reservations'). '/' . $reservation['id'] . '/edit' }}">@lang('strings.edit') <i class="fa fa-cog" style="color: blue"></i></a></li><li class="divider"></li>
                                            <li><a href="{{ url('/admin/reservations'). '/' . $reservation['id'] . '/cancel' }}">@lang('strings.Cancel') <i class="fa fa-times" style="color: red"></i></a></li>
                                        </ul>
                                    </div>
                                @endif
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
				{{ $reservations->links() }}
            </div>
        </div>
    </div>

@endsection

@section('scripts')
    <script>
        $(window).load(function(){
            $("#snackbar").addClass("show");
            setTimeout(function() {
                $("#snackbar").removeClass("show");
            }, 2800);
        });
    </script>
@endsection
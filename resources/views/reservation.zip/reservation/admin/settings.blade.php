@extends('layouts.admin', ['title' => __('strings.reservation_settings')])

@section('content')
  <div id="main-wrapper">
      <div class="row">
          <div class="col-md-12">
              <div class="alert_new">
                          <span class="alertIcon">
                              <i class="fas fa-exclamation-circle"></i>
                           </span>
                          <p>
                              @if (app()->getLocale() == 'ar')
            {{ DB::table('function_new')->where('id',234)->value('description') }}
            @else
            {{ DB::table('function_new')->where('id',234)->value('description_en') }}
            @endif
                          </p>
                          <a href="#" onclick="close_alert()" class="close_alert"> <i class="fas fa-times-circle"></i>
                          </a>
                      </div>
              <div class="panel panel-white">
                  <div class="panel-heading clearfix">
                      <div class="col-md-12">
                          <h4 class="panel-title"> {{ __('strings.reservation_settings') }} </h4>
                      </div>
                  </div>
                  <div class="panel-body">
                    <form method="post" action="{{url('/admin/reservation/settings')}}">
                      {{csrf_field()}}
                      <select name="reservation_type"
                              data-placeholder="تحديد صيفة التاريخ"
                              required="required" class="js-select">
                          <option {{App\Settings::where(['key' => 'reservation_type', 'org_id' => Auth::user()->org_id])->value('value') == 0 ? 'selected' : ''}} value="0">
                              {{__('strings.reserve_with_specific_time')}}
                          </option>
                          <option {{App\Settings::where(['key' => 'reservation_type', 'org_id' => Auth::user()->org_id])->value('value') == 1 ? 'selected' : ''}} value="1">
                              {{__('strings.reserve_with_Precedence_of_attendance')}}
                          </option>

                      </select>
                  </div>
                  <button class="btn btn-primary btn-lg btn-save" type="submit"><i class="icon-check"></i>&nbsp;&nbsp; @lang('strings.update_settings')
                  </button>
                    </form>
                  </div>
                </div>
              </div>
            </div>
@endsection

@extends('layouts.admin', ['title' => __('strings.add_reservation')])

@section('content')
  @section('styles')
      <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.0/css/select2.min.css" rel="stylesheet" />
      <link href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/16.0.0/css/intlTelInput.css" rel="stylesheet" />
  @endsection
    <style>
        .form-group select, .form-group input {
            display: block;
            width: 100%;
            height: 34px;
            padding: 6px 12px;
            font-size: 14px;
            line-height: 1.42857143;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .staff-time {
    width: calc(20% - 6px);
    padding: 7px 10px;
    border: 1px solid #ddd;
    display: inline-block;
    margin: 3px;
    text-align: center;
    cursor: pointer;
  }
  .times {
    list-style: none;
    text-align: right;
  }
  .start-time  {
    padding: 15px;
    border: 1px solid #ccc;
    border-radius: 3px;
    margin-bottom: 10px;
    width: 100%;
    box-sizing: border-box;
    color: #2C3E50;
    font-size: 13px;
  }



        /* The Close Button */
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }
        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }
        .radios {
            margin: 20px;
        }
        .radio-inline {
            padding-left: 56px;
        }
        input#confirm {
            height: auto;
        }
        span.help-block.date-error {
            display: none;
        }
        .row {
            width: 100%;
        }
        span.help-block.date-error2 {
    display: none;
  }
    </style>

    <!--<div class="page-title">-->
    <!--    <h3>@lang('strings.add_reservation')</h3>-->
    <!--</div>-->
    
    <div class="alert_new">
        <span class="alertIcon">
            <i class="fas fa-exclamation-circle"></i>
         </span>
         <p>
             @if (app()->getLocale() == 'ar')
            {{ DB::table('function_new')->where('id',16)->value('description') }}
            @else
            {{ DB::table('function_new')->where('id',16)->value('description_en') }}
            @endif
         </p>
         <a href="#" onclick="close_alert()" class="close_alert">  <i class="fas fa-times-circle"></i> </a>
         
    </div>
    
    <div class="modal fade newModel" id="addclient" role="dialog">
        <div class="modal-dialog">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-body" style="overflow: hidden">
                    <form method="post" action="#" enctype="multipart/form-data" id="add_customer_store">
                        {{csrf_field()}}
                        <input type="hidden" class="form-control" name="user_id" value="{{  Auth::user()->id }}">
                        <input type="hidden" class="form-control" name="active" value="1">

                        <div class="col-md-6 form-group{{$errors->has('name') ? ' has-error' : ''}}"> <strong class="text-danger">*</strong>
                            <label class="control-label" for="name">{{ __('strings.Arabic_name') }}</label>
                            <input type="text" class="form-control" name="name" value="{{old('name')}}" required>
                            @if ($errors->has('name'))
                                <span class="help-block">
                                    <strong class="text-danger">{{ $errors->first('name') }}</strong>
                                </span>
                            @endif
                        </div>

                        <div class="col-md-6 form-group{{$errors->has('name_en') ? ' has-error' : ''}}">
                            <label class="control-label" for="name_en">{{ __('strings.English_name') }}</label>
                            <input type="text" class="form-control" name="name_en" value="{{old('name_en')}}" required>
                            @if ($errors->has('name_en'))
                                <span class="help-block">
                                    <strong class="text-danger">{{ $errors->first('name_en') }}</strong>
                                </span>
                            @endif
                        </div>

                        <div class="col-md-6 form-group{{$errors->has('email') ? ' has-error' : ''}}"> <strong class="text-danger">*</strong>
                            <label class="control-label" for="email">{{ __('strings.Email') }}</label>
                            <input type="text" class="form-control" name="email" value="{{old('email')}}" required>
                            @if ($errors->has('email'))
                                <span class="help-block">
                                    <strong class="text-danger">{{ $errors->first('email') }}</strong>
                                </span>
                            @endif
                        </div>

                        <div class="col-md-6 form-group{{$errors->has('gender') ? ' has-error' : ''}}"> <strong class="text-danger">*</strong>
                            <label class="control-label" for="gender">{{ __('strings.Gender') }}</label>
                            <select class="form-control" name="gender" required>
                                <option value="1">{{ __('strings.Male') }}</option>
                                <option value="0">{{ __('strings.Female') }}</option>
                            </select>
                            @if ($errors->has('gender'))
                                <span class="help-block">
                                    <strong class="text-danger">{{ $errors->first('gender') }}</strong>
                                </span>
                            @endif
                        </div>

                        <div class="col-md-6 form-group{{$errors->has('address') ? ' has-error' : ''}}"> <strong class="text-danger">*</strong>
                            <label class="control-label" for="address">{{ __('strings.Address') }}</label>
                            <input type="text" class="form-control" name="address" value="{{old('address')}}" required>
                            @if ($errors->has('address'))
                                <span class="help-block">
                                    <strong class="text-danger">{{ $errors->first('address') }}</strong>
                                </span>
                            @endif
                        </div>

                        <div class="col-md-12 form-group{{$errors->has('phone_number') ? ' has-error' : ''}}"> <strong class="text-danger">*</strong>
                            <label class="control-label" for="phone_number">{{ __('strings.Phone') }}</label>
                            <input type="tel" class="form-control" name="phone_number" id="phone" value="{{old('phone_number')}}" required>
                            <span id="valid-msg" class="hide">✓ صالح</span>
                            <span id="error-msg" class="hide"></span>

                            @if ($errors->has('phone_number'))
                                <span class="help-block">
                                    <strong class="text-danger">{{ $errors->first('phone_number') }}</strong>
                                </span>
                            @endif
                        </div>
                          <div class="col-md-6 form-group{{$errors->has('signs') ? ' has-error' : ''}}">
                                <label>{{__('strings.country')}}<strong class="text-danger">*</strong></label>
                                <select required name="country_id" class="select-search">
                                    @foreach($countries as $country)
                                        @php
                                            $country_session = Session::has('country')  ? session('country') : 'EG';
                                        @endphp
                                        <option {{ $country_session == $country->code || old('country_id') == $country->id ? 'selected' : ''}} value="{{$country->id}}">{{ app()->getLocale() == 'ar' ? $country->name  : $country->name_en  }}</option>
                                        @endforeach
                                </select>
                            </div>


                         <div class="col-md-6 form-group{{$errors->has('signs') ? ' has-error' : ''}}">
                                <label>{{__('strings.city')}}<strong class="text-danger">*</strong></label>
                                <input type="text" placeholder="" required name="city" value="{{ Session::has('city')  ? session('city') : 'EG' }}">
                            </div>
                        <div class="col-md-12 form-group text-right">
                            <button type="submit" class="btn btn-primary btn-lg" id="add_customer_submit">{{ __('strings.Save') }}</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div id="main-wrapper">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-white">
                    <div class="panel-heading clearfix">
                        <div class="col-md-12">
                            <h4 class="panel-title"></h4>
                        </div>
                    </div>
                    <div class="panel-body">
                        @if(Session::has('message'))
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="alert alert-danger">
                                        {{Session::get('message')}}
                                    </div>
                                </div>
                            </div>
                        @endif
                        <form method="post" action="{{ url('/admin/reservations') }}" id="reservation_form">
                            @csrf
                            <div class="row">
                                <div class="col-md-4 col-xs-12">
                                    <div class="form-group">
                                        <label style="display: block">@lang('strings.Client_name')</label>
                                        <select class="form-control js-select" name="customer" id="customers">
                                            {{-- <option value="0">@lang('strings.Select_client')</option> --}}
                                            @foreach($customers as $customer)
                                                <option value="{{$customer->id}}">{{ app()->getLocale() == 'ar' ? $customer->name  : $customer->name_en  }}</option>
                                            @endforeach
                                        </select>
                                        <button type="button" class="btn btn-info btn-lg NewBtn btnclient" data-toggle="modal" data-target="#addclient"><i class="fas fa-plus"></i></button>
                                    </div>

                                </div>
                                <div class="col-md-4 col-xs-12">
                                    <div class="form-group">
                                        <label for="category"
                                               style="display: block">@lang('strings.choose_cat_type')</label>
                                        <select class="form-control js-select" name="category_types" id="category_types">
                                            {{-- <option value="0" selected>@lang('strings.Select') ...</option> --}}
                                            @foreach($services as $service)
                                                <option value="{{ $service->id }}">{{ app()->getLocale() == 'ar' ? $service->name  : $service->name_en  }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4 col-xs-12">
                                    <div class="form-group">
                                        <label style="display: block">@lang('strings.choose_cat')</label>
                                        <select class="form-control js-select" name="category" id="categoriess">
                                            {{-- <option value="0">@lang('strings.Select') ...</option> --}}
                                            @foreach($categories as $category)
                                                <option value="{{ $category->id }}">{{ app()->getLocale() == 'ar' ? $category->name  : $category->name_en  }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4 col-xs-12">
                                    <div class="form-group">
                                        <label for="captain"
                                               style="display: block">@lang('strings.choose_catpatin')</label>
                                        <select class="form-control js-select" name="captain" id="captain">
                                          @foreach($captins as $captin)
                                            <option value="{{ $captin->id }}">{{ app()->getLocale() == 'ar' ? $captin->name  : $captin->name_en  }}</option>
                                          @endforeach
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4 col-xs-12">
                                    <div class="form-group">
                                        <label for="date" style="display: block">@lang('strings.choose_date')</label>
                                        <input type="date" name="date" id="date" class="form-control" value="{{date('Y-m-d')}}">
                                        <span class="help-block date-error">
                                            <strong class="text-danger"> @lang('strings.Message_date')</strong>
                                        </span>
                                        <span class="help-block date-error2">
                                            <strong class="text-danger2"> @lang('strings.no_times_available')</strong>
                                        </span>
                                    </div>
                                </div>

                                {{-- <div class="col-md-4 col-xs-12">
                                    <div class="form-group" id="time_form">
                                        <label class="control-label" for="time">@lang('strings.Time')</label>
                                        <p id="date-text"></p>
                                        <div class="timeline_new">

                                        </div>
                                        <select class="form-control js-select" name="time" id="time">
                                            {!! times(old('time')) !!}
                                        </select>
                                        @if (session('time_error'))
                                            <span class="help-block">
                                                <strong class="text-danger">{{ session('time_error') }}</strong>
                                            </span>
                                        @endif
                                    </div>
                                </div> --}}
                                 <div class="col-md-4 col-xs-12">
                                    <div class="form-group" id="time_form">
                                        <label class="control-label" for="time">@lang('strings.Time')</label>
                                        <p id="date-text"></p>
                                        <div class="timeline_new">
                                          <ul id="times" class="times"></ul>
                                        </div>

                                        @if (session('time_error'))
                                            <span class="help-block">
                                                <strong class="text-danger">{{ session('time_error') }}</strong>
                                            </span>
                                        @endif
                                    </div>
                                </div>

                            </div>


                            <div class="form-group">
                              <label for="comment">@lang('strings.add_comment')</label>
                              <textarea class="form-control" rows="5" name="comment" id="comment"></textarea>
                            </div>
                       <div class="form-group">
                            <button id="add_check_button" onclick="validateform(event)"  type="submit" class="btn btn-primary"><i
                                        class="fas fa-save"></i> @lang('strings.Save')</button>
                                        </div>
                            {{-- <div id="myModal" class="modal modalmy">
                                <!-- Modal content -->
                                <div class="modal-content">
                                    <button type="button" class="close" data-dismiss="modal" onclick="closemodal()"
                                            aria-hidden="true">&times;
                                    </button>
                                    <div class="form-group">
                                        <label for="comment">@lang('strings.add_comment')</label>
                                        <textarea class="form-control" rows="5" name="comment" id="comment"></textarea>
                                    </div>
                                    <button id="add_check_button" type="submit" class="btn btn-primary"><i
                                                class="fas fa-save"></i> @lang('strings.Save')</button>
                                </div>
                            </div> --}}
                            {{-- <div id="myModal2" class="modal modalmy">
                                <!-- Modal content -->
                                <div class="modal-content">
                                    <button type="button" class="close" onclick="closemodal2()">&times;</button>
                                    <div class="form-group">
                                        <label id="confirmation" for="radios" style="margin-bottom: 10px"></label>
                                        <div class="custom-radio" id="radios">
                                            <label class="radio-inline">نعم</label><input type="radio" name="confirm"
                                                                                          id="confirm" value="y"
                                                                                          checked>
                                            <label class="radio-inline">لا</label><input type="radio" name="confirm"
                                                                                         id="confirm" value="n">
                                        </div>
                                    </div>
                                    <button type="submit" class="btn btn-primary" onclick="closemodal2()"><i
                                                class="fas fa-check"></i> @lang('strings.Confirm')</button>
                                </div>
                            </div> --}}

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>




        function validateDate() {
            var del_date = document.getElementById('date').value;
            var yesterday = (function () {
                this.setDate(this.getDate() - 1);
                return this;
            }).call(new Date);

            if (Date.parse(del_date) < yesterday) {
                return false;
            } else {
                return true;
            }
        };


        $("#date").change(function () {
            $check = validateDate();
            if ($check === false) {
            $('#times').empty();

                if ($('span.help-block.date-error').css('display') == 'none') {
                    $('span.help-block.date-error').css({"display": "block"});
                    $('span.help-block.date-error2').css({"display": "none"});
                    $('.panel .panel-white').css({"display": "none"});
                }
                return;
            } else {

                $('span.help-block.date-error').css({"display": "none"});
                $('span.date-captain-error').css({"display": "none"});
                var captainElement = document.getElementById('captain');
                var captainID = captainElement.options[captainElement.selectedIndex].value;

                var dateElement = document.getElementById('date').value;
                $.get("{{ url('/admin/reservations/captains') }}/" + captainID + "/" + this.value, function (data) {
                    $("#time").empty();


                     timeSlotsHtml = '';
                    console.log(data);
                    if(!Object.keys(data).length >=1){
                      $('#times').empty();
                      if ($('span.help-block.date-error2').css('display') == 'none') {
                          $('span.help-block.date-error2').css({"display": "block"});
                          $('.panel .panel-white').css({"display": "none"});
                      }
                      return;

                    }
                    else{
                      $('span.help-block.date-error2').css({"display": "none"});
                      $('span.date-captain-error2').css({"display": "none"});
                      var j=0;
                      $.each(data, function (key, value) {
                                           if(j==0){
                                             timeSlotsHtml += `<li class="staff-time">
                                                   <input   class='start-time' type="radio" name="time" value="${key}" checked> <span>${value}</span>
                                             </li>`;
                                           }
                                           else{
                                             timeSlotsHtml += `<li class="staff-time">
                                                   <input   class='start-time' type="radio" name="time" value="${key}" > <span>${value}</span>
                                             </li>`;
                                           }

                        $('#times').html(timeSlotsHtml);
                        j++;
                      });
                    }

                });
            }

        });





    </script>
@endsection

@section('scripts')
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/16.0.0/js/intlTelInput.js"></script>
    <script>


    var input = document.querySelector("#phone"),
        errorMsg = document.querySelector("#error-msg"),
        validMsg = document.querySelector("#valid-msg");

    var errorMap = ["☓ رقم غير صالح", "☓ رمز البلد غير صالح", "☓ قصير جدا", "☓ طويل جدا", "☓ رقم غير صالح"];

    var iti = window.intlTelInput(input, {
        initialCountry: "auto",
        geoIpLookup: function(callback) {
            $.get('https://ipinfo.io', function() {}, "jsonp").always(function(resp) {
                var countryCode = (resp && resp.country) ? resp.country : "";
                callback(countryCode);
            });
        },
        utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/16.0.0/js/utils.js"
    });

        $("#category_types").change(function () {

            $.get("{{ url('/admin/reservations/getCategories') }}/" + this.value, function (data) {
                $("#categoriess").empty();
                $.each(data, function (key, value) {
                    if ({{app()->getLocale() == 'ar'?0:1}} == 0)
                    $("#categoriess").append("<option value='" + value.id + "'>" + value.name + "</option>");
                else
                    $("#categoriess").append("<option value='" + value.id + "'>" + value.name_en + "</option>");
                });
            });
        });



               function validateform(e){


                 var i=0;
                 if ($('#customer').val() == 0) {

                   i--;
                     alert('برجاء اختيار العميل');
                     e.preventDefault();
                   }else{
                       i++;
                       e.preventDefault();
                     }

                 if ($('#category_types').val() == 0) {

                   i--;
                     alert('برجاء اختيار فئة الخدمة');
                     e.preventDefault();
                 }
                 else{
                   i++;
                   e.preventDefault();
                 }
                 if ($('#categoriess').val() == 0) {

                   i--;

                     alert('برجاء اختيار الخدمة');
                     e.preventDefault();
                 }
                 else{
                   i++;
                   e.preventDefault();
                 }
                 if($('#date').val() == ''){

                   i--;

                     alert('برجاء اختيار التاريخ');

                        e.preventDefault();
                 }
                 else{
                   i++;
                   e.preventDefault();
                 }
                  if ($('#captain').val() == null) {

                   i--;
                     alert('برجاء اختيار الكابتن');
                     e.preventDefault();
                 }
                 else{
                   i++;
                   e.preventDefault();
                 }
                  if ($('input[name="time"]').val() ==null || $('input[name="time"]').val() =='') {
                   alert('برجاء اختيار الوقت');
                   i--;


                     e.preventDefault();
                  }
                  else{
                    i++;
                    e.preventDefault();
                  }

                  if(i==6){
                     $('#reservation_form').submit();
                  }
               }
               var captainElement = document.getElementById('captain');
               var captainID = captainElement.options[captainElement.selectedIndex].value;
               $.get("{{ url('/admin/reservations/captains') }}/" + captainID + "/" +$('#date').val() , function (data) {
                   $("#time").empty();


                    timeSlotsHtml = '';
                   console.log(data);
                   if(!Object.keys(data).length >=1){
                     $('#times').empty();
                     if ($('span.help-block.date-error2').css('display') == 'none') {
                         $('span.help-block.date-error2').css({"display": "block"});
                         $('.panel .panel-white').css({"display": "none"});
                     }
                     return;

                   }
                   else{
                     $('span.help-block.date-error2').css({"display": "none"});
                     $('span.date-captain-error2').css({"display": "none"});
                     var j=0;
                     $.each(data, function (key, value) {
                                          if(j==0){
                                            timeSlotsHtml += `<li class="staff-time">
                                                  <input   class='start-time' type="radio" name="time" value="${key}" checked> <span>${value}</span>
                                            </li>`;
                                          }
                                          else{
                                            timeSlotsHtml += `<li class="staff-time">
                                                  <input   class='start-time' type="radio" name="time" value="${key}" > <span>${value}</span>
                                            </li>`;
                                          }

                       $('#times').html(timeSlotsHtml);
                       j++;
                     });
                   }

               });
               $('#add_customer_submit').click(function() {
                   $("#add_customer_store").ajaxForm({
                       url: '{{ url('admin/ajax/add_customer') }}', type: 'post',
                       beforeSubmit: function (response) {
                           if(iti.isValidNumber() == false) {
                               alert("Please check your phone again");
                               return false;
                           }
                       },
                       success: function (response) {
                           $('#addclient').modal('toggle');

                           $("#customers").append("<option selected value='" + response.data.id + "'>" + @if(app()->getLocale() == 'ar') response.data.name
                           @else response.data.name_en @endif + "</option>"
                       );
                       },
                       error: function (response) {
                           alert("Please check your entry date again");
                       }
                   })
               });


    </script>
@endsection

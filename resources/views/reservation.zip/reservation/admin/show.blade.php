@extends('layouts.admin', ['title' =>__('strings.dashboard')])
<!-- Last Modified  02/05/2019 15:14:17  -->
@section('content')


  <div class="panel panel-white">
      <div class="panel-heading clearfix">
          <h4 class="panel-title">@lang('strings.details')</h4>
      </div>
      <div class="panel-body">
        <div class="row">
          <div class="col-md-12">
          <div class="col-md-3">
          <h3 class="head-bar theme-color-a">
								<span class="details-info">{{__('strings.customer_information')}}</span>
							</h3>
              <span>{{$reservation->name}}</span>
            </div>
            <div class="col-md-6">
            <div class="col-md-6">
              <h3 class="head-bar theme-color-a">
						<span class="details-info">{{__('strings.services')}}</span>
					</h3>
          <table width="100%" border="0" cellspacing="0" cellpadding="0" class="view-table">
										<tbody>
                      @foreach($reservation_details as $reservation_detail)
                      <tr>
                        <td width="160">
                          <strong>{{$reservation_detail->name}}</strong>
												</td>
                        <td>{{$reservation_detail->required_time}}M</td>
                      </tr>
                    @endforeach
                      <tr>
                        <td width="160">
                          <strong>{{__('strings.total_time')}}</strong>
                        </td>
                        <td>{{$total}}M</td>
											</tr>
                      <tr>
                        <td><i class="fa fa-calendar icon-sum"></i></td>
                        <td>{{$reservation->reservation_date	}}</td>
                      </tr>
                      <tr>
                        <td><i class="fa fa-clock-o icon-sum"></i></td>
                        <td>{{time_from_id($start_time)}}</td>
											</tr>
									</tbody>
									</table>
            </div>
          </div>
            <div class="col-md-3">
									<h3>{{__('strings.opservations')}}</h3>
									<div class="booking-notes">
                    @foreach($reservation_details as $reservation_detail)
                  {{$reservation_detail->name}}
                     <br>
                   @endforeach
                   </div>
											</div>
</div>
        </div>
      </div>
    </div>
@endsection

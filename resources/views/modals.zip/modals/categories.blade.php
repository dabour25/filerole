<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.7/css/select2.min.css" rel="stylesheet" />
<link href="{{ asset('plugins/summernote-master/summernote.css') }}" rel="stylesheet" type="text/css"/>

<form method="post" action="#" enctype="multipart/form-data" id="categories_store">
    {{csrf_field()}}
    <div class="col-md-12">
        <div class="panel panel-white">
            <div class="panel-heading clearfix">
                <div class="col-md-12">
                    <h4 class="panel-title">{{ $type == 1 ? __('strings.Categories_add') : __('strings.Categories_add_service') }}</h4>
                </div>
            </div>
            <div class="panel-body">
                <input type="hidden" name="type" value="{{ $type }}">
                <input name="active" type="hidden" value="1">
                <div class="col-md-6 add_f2a form-group{{$errors->has('categories_type') ? ' has-error' : ''}}"> <strong class="text-danger">*</strong>
                    <label class="control-label" for="categories_type">{{ __('strings.Categories_type') }}</label>
                    <select class="form-control js-select" name="categories_type" id="categories_types" required>
                        <option value="">@lang('strings.select')</option>
                        @foreach(App\CategoriesType::where(['type' => $type, 'active' => 1, 'org_id' => Auth::user()->org_id])->get() as $value)
                            <option {{ old('categories_type') == $value->id ? 'selected' : ''}} value="{{ $value->id }}">{{ app()->getLocale() == 'ar' ? $value->name : $value->name_en }}</option>
                        @endforeach
                    </select>
                    @if ($errors->has('categories_type'))
                        <span class="help-block">
                                            <strong class="text-danger">{{ $errors->first('categories_type') }}</strong>
                                        </span>
                    @endif
                </div>
                <div class="col-md-6 form-group">
                    <label for="photo_id" class="control-label">@lang('strings.Tax')</label>
                    <select class="form-control js-select" name="tax" id="select-tax">
                        <option value="0">@lang('strings.select')</option>
                        @foreach(App\Tax::where(['active' => 1, 'org_id' => Auth::user()->org_id])->get() as $value)
                            <option {{ old('tax') == $value->id ? 'selected' : ''}} value="{{ $value->id }}">{{ app()->getLocale() == 'ar' ? $value->name : $value->name_en }}</option>
                        @endforeach
                    </select>
                </div>

                <div class="col-md-6 form-group{{$errors->has('name') ? ' has-error' : ''}}"> <strong class="text-danger">*</strong>
                    <label class="control-label" for="name">{{ __('strings.Arabic_name') }}</label>
                    <input type="text" class="form-control" name="name" value="{{ old('name') }}" required>
                    @if ($errors->has('name'))
                        <span class="help-block">
                                            <strong class="text-danger">{{ $errors->first('name') }}</strong>
                                        </span>
                    @endif
                </div>

                <div class="col-md-6 form-group{{$errors->has('name_en') ? ' has-error' : ''}}"> <strong class="text-danger">*</strong>
                    <label class="control-label" for="name_en">{{ __('strings.English_name') }}</label>
                    <input type="text" class="form-control" name="name_en" value="{{old('name_en') }}" required>
                    @if ($errors->has('name_en'))
                        <span class="help-block">
                                            <strong class="text-danger">{{ $errors->first('name_en') }}</strong>
                                        </span>
                    @endif
                </div>

                <div class="col-md-6 form-group{{$errors->has('barcode') ? ' has-error' : ''}}">
                    <label class="control-label" for="barcode">{{ __('strings.Barcode') }}</label>
                    <input type="text" class="form-control" name="barcode" value="{{ old('barcode') }}">
                    @if ($errors->has('barcode'))
                        <span class="help-block">
                            <strong class="text-danger">{{ $errors->first('barcode') }}</strong>
                        </span>
                    @endif
                </div>
                @if($type == 2)
                    <div class="col-md-12"></div>
                @endif
                @if($type == 1)
                <div class="items col-md-6 form-group{{$errors->has('limit') ? ' has-error' : ''}}" required>
                    <label class="control-label" for="limit">@lang('strings.Demand_limit')</label>
                    <input type="number" class="form-control" name="limit" value="{{ old('limit') }}">
                    @if ($errors->has('limit'))
                        <span class="help-block">
                            <strong class="text-danger">{{ $errors->first('limit') }}</strong>
                        </span>
                    @endif
                </div>

                <div class="col-md-6 form-group">
                    <label for="selling" class="control-label">@lang('strings.selling_price')</label>
                    <input type="text" class="form-control" name="selling" value="{{ old('selling') }}">
                </div>

                <div class="items col-md-6 form-group{{$errors->has('unit') ? ' has-error' : ''}}"> <strong class="text-danger">*</strong>
                    <label class="control-label" for="unit">@lang('strings.Unit')</label>
                    <select class="form-control js-select" name="unit" required>
                        <option {{ old('unit') == 0 ? 'selected' : ''}}  value="0">@lang('strings.Unit_select')</option>
                        <option {{ old('unit') == 1 ? 'selected' : 'selected'}} value="1">@lang('strings.Units')</option>
                        <option {{ old('unit') == 2 ? 'selected' : ''}}  value="2">@lang('strings.Count')</option>
                        <option {{ old('unit') == 3 ? 'selected' : ''}}  value="3">@lang('strings.Kg')</option>
                        <option {{ old('unit') == 4 ? 'selected' : ''}}  value="4">@lang('strings.G')</option>
                        <option {{ old('unit') == 5 ? 'selected' : ''}}  value="5">@lang('strings.Meter')</option>
                        <option {{ old('unit') == 6 ? 'selected' : ''}}  value="6">@lang('strings.CM')</option>
                        <option {{ old('unit') == 7 ? 'selected' : ''}}  value="7">@lang('strings.Liter')</option>
                        <option {{ old('unit') == 8 ? 'selected' : ''}}  value="8">@lang('strings.Box')</option>
                        <option {{ old('unit') == 9 ? 'selected' : ''}}  value="9">@lang('strings.Ton')</option>
                        <option {{ old('unit') == 10 ? 'selected' : ''}}  value="10">@lang('strings.Else')</option>
                    </select>
                    @if ($errors->has('unit'))
                        <span class="help-block">
                            <strong class="text-danger">{{ $errors->first('unit') }}</strong>
                        </span>
                    @endif
                </div>
                @endif
                <div class="col-md-6 desk_New form-group{{$errors->has('description') ? ' has-error' : ''}}">
                    <label class="control-label" for="description">@lang('strings.description_ar')</label>
                    <textarea type="text" class="summernote" name="description">{{old('description')}}</textarea>
                    @if ($errors->has('description'))
                        <span class="help-block">
                            <strong class="text-danger">{{ $errors->first('description') }}</strong>
                        </span>
                    @endif
                </div>

                <div class="col-md-6 desk_New form-group{{$errors->has('description_en') ? ' has-error' : ''}}">
                    <label class="control-label" for="description">@lang('strings.description_en')</label>
                    <textarea type="text" class="summernote" name="description_en">{{old('description_en')}}</textarea>
                    @if ($errors->has('description_en'))
                        <span class="help-block">
                            <strong class="text-danger">{{ $errors->first('description_en') }}</strong>
                        </span>
                    @endif
                </div>

                <div class="col-md-12 form-group text-right">
                    <button type="submit" class="btn btn-primary btn-lg" id="categories_submit"> @lang('strings.Save') </button>
                </div>
            </div>
        </div>
    </div>
</form>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.7/js/select2.min.js"></script>
<script src="{{ asset('plugins/summernote-master/summernote.min.js') }}"></script>

<script>
    $(".summernote").summernote({
        styleWithSpan: false,
        toolbar: [
            ['style', ['bold', 'italic', 'underline']],
            ['color', ['color']],
            ['para', ['ul', 'ol']]
        ],
    });

    $('#categories_submit').click(function() {
        $("#categories_store").ajaxForm({url: '{{ url('admin/ajax/add_categories') }}', type: 'post',
            success: function (response) {
                $('#open-modal').modal('toggle');
                $(".products").append("<option selected value='" + response.data.id + "'>" + @if(app()->getLocale() == 'ar') response.data.name @else response.data.name_en @endif + "</option>");
            },
            error: function (response) {
                alert("Please check your entry date again");
            }
        })
    });

</script>

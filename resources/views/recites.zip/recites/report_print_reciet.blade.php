<!--
Author: FileRole
Author URL: http://filerole.com
-->

<!DOCTYPE html>
<html lang="ar">

<head>

    <!-- CSRF Token -->
    <meta name="csrf-token" content="e3zycRu8BXA0Bcwvlw8bLx1YKjXtWWLnELQLApn3">

    <!-- Title -->
    <title> الطلبات قيد الإنتظار </title>

    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

    <meta charset="UTF-8">
    <meta name="title" content="قائمة المنتجات">
    <meta name="description" content="Admin Panel for .">
    <meta name="keywords" content="">
    <meta name="author" content="Pharaoh">

    <link rel="icon" href="http://ayman3li.filerolesys.com/favicon.png">

    <!-- datatabel files -->
    <link href="http://ayman3li.filerolesys.com/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.bootstrap4.min.css">

    <!-- Styles -->
    <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Droid+Sans">

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,300,600" rel="stylesheet" type="text/css">


    <!-- Theme Styles -->
    <link href="http://ayman3li.filerolesys.com/css/backend_rtl.min.css" rel="stylesheet" type="text/css">

    <style>
        .buttons_tabel button {
            display: inline-block;
            width: auto;
            margin: 0 0 0 5px;
            padding: 5px 15px;
            border-radius: 3px;
        }
        .buttons_tabel .btn-close-regust {
            background: #e20e0e;
        }
        .buttons_tabel .btn-close-regust2 {
            color: #e20e0e;
        }
        #myRadioGroup .input-group {
            display: inline-block;
            width: auto;
            overflow: hidden;
            margin: 0 0 10px 50px;
        }
        #myRadioGroup .input-group label {
            display: inline-block;
            width: auto;
            margin: 0 0 15px 0;
        }
        #myRadioGroup .input-group input {
            float: right;
            margin: 4px 0 0 10px;
        }
        form label {
        font-size: 13px;
        font-weight: 400;
        }
        textarea {
            padding: 15px !important;
        }
        .btn-Show-regust {
            background: #007bff;
        }
        .modal-footer .btn-default {
            padding: 8px 55px 8px 40px;
            margin-right:10px;
            background: #e20e0e;
        }
        .modal-footer .btn-default:hover {
            background: #e20e0e !important;
        }
        .modal-footer .btn-default i {
            background: #b50c0c;
        }
    </style>

</head>
<body>


    <div class="page-inner" id="allbg">

    <div id="main-wrapper">
      <div class="row text" style="margin: 15px 0 0 0">
          <div class="col-md-4 col-xs-12">
              <p>{{__('strings.org_name')}} : <span> {{ app()->getLocale() == 'ar' ?$org->name:$org->name_en}} </span> </p>
          </div>
          <div class="col-md-4 col-xs-12">
              <p>{{__('strings.address')}} : <span> {{$org->address}} </span> </p>
          </div>
          <div class="col-md-4 col-xs-12">
            @if(!empty(App\Photo::find($org->image_id)))
        <img src="{{ App\Photo::findOrFail($org->image_id)->file }}"
             style="width:100%; max-width:100px;">
             @endif
          </div>
          <div class="col-md-4 col-xs-12">
              <p>{{__('strings.telephone')}} : <span> {{$org->phone}} </span> </p>
          </div>

      </div>
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-white">
                    <div class="panel-heading clearfix">
                        <h4 class="panel-title"> بيانات الطلب </h4>
                    </div>
                    <div class="panel-body">
                        <form>
                            <div class="col-md-4 col-xs-12 form-group">
                                <label class="control-label">رقم الطلب</label>
                                <input type="text" class="form-control" value="{{$id}}" disabled>
                            </div>
                            <div class="col-md-4 col-xs-12 form-group">
                                <label class="control-label">الحالة </label>
                                <input type="text" class="form-control" value="استلام" disabled>
                            </div>

                            <div class="col-md-4 col-xs-12 form-group">
                                <label class="control-label"> تاريخ الاستلام</label>
                                <input type="input" class="form-control" value="{{$delivery_date}}" disabled>
                            </div>
                            <div class="col-md-4 col-xs-12 form-group">
                                <label class="control-label"> تاريخ الانتهاء </label>
                                <input type="input" class="form-control" value="{{$due_date}}" disabled>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="panel panel-white">
                    <div class="panel-heading clearfix">
                        <h4 class="panel-title">الطلبات قيد الإنتظار</h4>
                    </div>
                    <div class="panel-body">
          <form>
        <table id="xtreme-table" class="table table-striped table-bordered" style="width:100%">
                <thead>
                    <tr>
                         <th> الخدمة المطلوبة </th>
                         <th> الكمية </th>
                         <th> السعر </th>
                         <th> الضريبة </th>
                         <th> الإجمالي </th>


                    </tr>
                </thead>
                <tbody id="clonetr">
                  @foreach($services as $service)
                    <tr id="firsttr">

                        <td> {{$service->cat_name}}</td>
                        <td>{{$service->quantity}}</td>
                        <td>ِ{{$service->price}}</td>
                        <td>{{$service->tax_val}}</td>
                        <td>{{$service->total_price}}</td>
                    </tr>
                  @endforeach
                </tbody>
            </table>
            <div class="totalPriceDiv text-left">
              {{ app()->getLocale() == 'ar' ? 'السعر الاجمالى' : 'total price'}} :  <span class="finalTotalPrice">{{$total}}</span>
            </div>
            <div class="modal-footer">

            </div>
          </form>
                    </div>
                </div>

            </div>
        </div>
    </div>
    {{-- <button name="save" type="submit" class="btn btn-primary btn-lg" id="print"> @lang('strings.Print') </button>
    <a class="btn btn-info btn-lg" href="{{ URL::previous() }}" role="button" id="back">{{__('strings.Back')}}</a> --}}

    <!-- Main Wrapper -->
    <div class="page-footer">
        <p class="no-s">
            حقوق التأليف والنشر. © 2019. جميع الحقوق محفوظة لشركة فايل رول.
        </p>
    </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
    <script>

            window.print();


    </script>
</body>

</html>

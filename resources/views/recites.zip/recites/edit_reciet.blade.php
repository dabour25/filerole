@extends('layouts.admin', ['title' => __('strings.external_req_wait')])
@section('styles')
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.7/css/select2.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.css" />
<style>
    .buttons_tabel button {
        display: inline-block;
        width: auto;
        margin: 0 0 0 5px;
        padding: 5px 15px;
        border-radius: 3px;
    }
    .buttons_tabel .btn-close-regust {
        background: #e20e0e;
    }
    .buttons_tabel .btn-close-regust2 {
        color: #e20e0e;
    }
    #myRadioGroup .input-group {
        display: inline-block;
        width: auto;
        overflow: hidden;
        margin: 0 0 10px 50px;
    }
    #myRadioGroup .input-group label {
        display: inline-block;
        width: auto;
        margin: 0 0 15px 0;
    }
    #myRadioGroup .input-group input {
        float: right;
        margin: 4px 0 0 10px;
    }
    form label {
    font-size: 13px;
    font-weight: 400;
    }
    textarea {
        padding: 15px !important;
    }
    .btn-Show-regust {
        background: #007bff;
    }
    .modal-footer .btn-default {
        padding: 8px 55px 8px 40px;
        margin-right:10px;
        background: #e20e0e;
    }
    .modal-footer .btn-default:hover {
        background: #e20e0e !important;
        color: #fff;
    }
    .modal-footer .btn-default {
        color: #fff;
    }
    .modal-footer .btn-default i {
        background: #b50c0c;
    }
    .modal1 {
        background: rgba(0,0,0,0.7);
    }
    .modal1 input,.modal1 select {
        width: 100%;
        border: 1px solid #ccc;
        padding: 8px 8px;
    }
    .modal1 label {
        margin: 20px 0 10px 0;
        font-weight: 600;
    }
    #myModal1 {
        display: none;
        position: fixed;
        width: 100%;
        height: 100%;
        z-index: 99999;
    }
    .modal2 {
        background: rgba(0,0,0,0.7);
    }
    .modal2 input,.modal1 select {
        width: 100%;
        border: 1px solid #ccc;
        padding: 8px 8px;
    }
    .modal2 label {
        margin: 20px 0 10px 0;
        font-weight: 600;
    }
    #myModal2 {
        display: none;
        position: fixed;
        width: 100%;
        height: 100%;
        z-index: 99999;
    }
</style>
<script>

function calcTotal(thisBtn) {
  var total = 0,reg_1 = 0,reg = 0;
  var total1 = 0;

console.log($('.finalTotalPrice').text());

    $(".fPrice span").each(function() {
      reg += parseFloat($(this).text());
       //return
    });

    $(".fprice_1 span").each(function() {
      reg_1 += parseFloat($(this).text()); //ex
    });
    console.log(reg_1);
    if (thisBtn.parents('tr').find('.reg_flagg select').val()  == -1) {
      total =  reg_1  - reg  ; //ex
    }
    else if (thisBtn.parents('tr').find('.reg_flagg select').val()  == 1) {
      total =   reg_1 -  reg ; //Return
    }
    $('.finalTotalPrice').text(total.toFixed(2));


}
</script>
@endsection
@section('content')
  <div class="modal1" id="myModal1">
    <div class="modal-dialog">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" onclick="closemod()">&times;</button>
        </div>
        <div class="modal-body">
          <div class="row">
            {{-- <form  action="{{ Route('payServiceamount') }}" method="post" enctype="multipart/form-data"> --}}

              <div class="col-xs-12">
                <label>{{__('strings.invoice_no')}} </label>
                <input type="text"  name="invoice_no1" disabled>
                <input type="hidden" name="invoice_no" >
              </div>
              <div class="col-xs-12">
                <label> {{__('strings.paid')}} </label>
                <input type="text"  name="paid1" disabled>
                <input type="hidden" name="paid" >
                <input type="hidden" name="customer_id">
                <input type="hidden" name="customer_head">
                <input type="hidden" name="total_amount">
              </div>
              <div class="col-xs-12">
                <label> {{__('strings.payment_type')}}</label>
                  <select name="payment_type">
                    <option value="1">{{__('strings.external_req_ex')}}</option>
                    <option value="-1">{{__('strings.external_req_ret')}}</option>
                  </select>
              </div>
              <div class="col-xs-12">
                <label> {{__('strings.payment_method')}} </label>
                  <select name="payment_method">
                  </select>
              </div>
              <div class="col-xs-12">
                <label> {{__('strings.amount')}} </label>
                <input type="text" placeholder="" name="amount">
              </div>
            </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-primary" onclick="pay_method()"><i class="fas fa-plus"></i>{{__('strings.save')}} </button>
          <button type="button" class="btn btn-primary btn-default" onclick="closemod()"><i class="fas fa-times"></i>{{__('strings.close')}} </button>
        {{-- </form> --}}
        </div>
      </div>

    </div>
  </div>
  <div class="modal2" id="myModal2">
    <div class="modal-dialog">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" onclick="closemod2()">&times;</button>
        </div>
        <div class="modal-body">
          <div class="row">
            {{-- <form  action="{{ Route('payServiceamount') }}" method="post" enctype="multipart/form-data"> --}}

              <div class="col-xs-12">
                <label>{{__('strings.invoice_no')}} </label>
                <input type="text"  name="invoice_no3" disabled>
                <input type="hidden" name="invoice_no4" >
              </div>
              <div class="col-xs-12">
                <label> {{__('strings.delivered_name')}} </label>
                <input type="text"  name="delivered_name">
                {{-- <input type="hidden" name="paid3"> --}}
                <input type="hidden" name="customer_id3">
                <input type="hidden" name="customer_head3">
                {{-- <input type="hidden" name="total_amount3"> --}}
              </div>
            </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-primary" onclick="deliver_method()"><i class="fas fa-plus"></i>{{__('strings.save')}} </button>
          <button type="button" class="btn btn-primary btn-default" onclick="closemod2()"><i class="fas fa-times"></i>{{__('strings.close')}} </button>
        {{-- </form> --}}
        </div>
      </div>

    </div>
  </div>
  <div class="page-inner" id="allbg">

  <div id="main-wrapper">
      <div class="row">
          <div class="col-md-12">
              <div class="alert_new">
                  <span class="alertIcon">
                      <i class="fas fa-exclamation-circle"></i>
                   </span>
                   <p>

                  </p>
                  <a href="#" onclick="close_alert()" class="close_alert"> <i class="fas fa-times-circle"></i> </a>
              </div>

              <div class="panel panel-white">
                  <div class="panel-heading clearfix">
                      <h4 class="panel-title">{{__('strings.request_information')}} </h4>
                  </div>
                  <div class="panel-body">
                      <form id="newRequests" action="{{ Route('addNewServiceRequest') }}" method="post" enctype="multipart/form-data">
                          {{-- <div class="col-md-4 col-xs-12 form-group">
                              <label class="control-label">رقم الطلب</label>
                              <input type="text" class="form-control" value="12" disabled>
                          </div> --}}

                            @csrf
                            <input type="hidden" name="customer_req_head" value={{$customer_req_head}}>
                            <input type="hidden" name="redirect" value="0">
                          <div class="col-md-4 col-xs-12 form-group">
                              <label class="control-label">{{__('strings.status')}}</label>
                              <input type="text" class="form-control" value="استلام" disabled>
                          </div>
                          <div class="col-md-4 col-xs-12 form-group">
                              <label class="control-label"> {{__('strings.customer')}} </label>
                              {{-- <select class="form-control js-select" name="cust_id">
                                @foreach($customers as $customer)
                                  <option value="{{$customer->id}}">{{ app()->getLocale() == 'ar' ? $customer->name : $customer->name_en}}</option>
                                @endforeach
                                </select> --}}
                                <input type="text" class="form-control" name="cust" value="{{$customer->name}}">
                                <input type="hidden" class="form-control" name="cust_id" value="{{$customer->id}}">

                          </div>
                          <div class="col-md-4 col-xs-12 form-group">
                              <label class="control-label"> {{__('strings.delivery_time')}}</label>
                              <input type="date" class="form-control" value="{{$delivery_date}}"  placeholder="{{$delivery_date}}" name="delivery_date" id="delivery_date" diasbled>
                          </div>
                          <div class="col-md-4 col-xs-12 form-group">
                              <label class="control-label"> {{__('strings.end_date')}} </label>
                              <input type="input" class="form-control" value="{{$due_date}}" name="end_date" id="end_date">
                          </div>

                  </div>
              </div>

              <div class="panel panel-white">
                  <div class="panel-heading clearfix">
                      <h4 class="panel-title">الطلبات قيد الإنتظار</h4>
                  </div>
                  <div class="panel-body">

      <table id="xtreme-table" class="table table-striped table-bordered" style="width:100%">
              <thead>
                  <tr>
                    <th> {{ __('strings.external_req_motionType') }} </th>
                       <th> {{__('strings.required_service')}} </th>
                       <th>{{__('strings.quantity')}} </th>
                       <th> {{('strings.price')}} </th>
                       <th> {{('strings.tax')}} </th>
                       <th> {{('strings.total')}} </th>
                       <th> {{__('strings.cancel')}} </th>

                  </tr>
              </thead>
              <tbody id="clonetr">
                @foreach($services as $service)
                  <tr id="firsttr">

                        <td class="reg_flagg">
                        <span class=" " style="display:none;"></span>
                        <select name="reqFlag[]" form="newRequests" class="reg_flag_select form-control">
                        <option value="-1" {{$service['motion_type']==-1?'selected':''}}>{{  __('strings.external_req_ex') }}</option>
                        <option value="1" {{$service['motion_type']==1?'selected':''}}>{{ __('strings.external_req_ret')}}</option>
                        </select>

                      <td>  <select name="cat_id[]" form="newRequests" class="cat_id_select form-control" required>
                        <option class="btnTest" style="display:none"></option>
                        @foreach ($services2 as  $value)

                        <option class="btnTest" value="{{$service['cat_id']}}" {{$service['cat_id']==$value->id ?'selected':''}}> {{$value->name }}</option>
                        @endforeach
                        </select></td>
                      <td><input class="form-control qnyNum" name="qny[]" value="{{$service['quantity']}}" form="newRequests" type="number"  required></td>
                      <td >ِ<span class="cat_price">{{$service['price']}}</span>
                        <input class="cat_price_input"  form="newRequests" type="hidden" value="{{$service['price']}}" name="cat_price[]">


                      </td>
                      <td><span class="tax">{{$service['tax_val']}}</span>
                        <input class="tax_val" type="hidden"  form="newRequests" value="{{$service['tax_val']}}" name="tax_val[]" required>
                         <input class="taxId" name="taxId[]" value="{{$service['taxId']}}" type="hidden"   form="newRequests" required>
                      </td>
                      <td class="fprice_1">
                        <span class="total">{{$service['total_price']}}</span>
                        </td>
                  </tr>
                @endforeach
              </tbody>
          </table>
          <div class="totalPriceDiv text-left">
            {{ app()->getLocale() == 'ar' ? 'السعر الاجمالى' : 'total price'}} :  <span class="finalTotalPrice" id="spanID">{{$total}}</span>
          </div>
          <div class="modal-footer">
              <button type="submit" name="action" value="2" class="btn btn-primary"><i class="fas fa-check-circle"></i> {{__('strings.save_print')}} </button>
              <button type="button" class="btn btn-primary" id="addRow"><i class="fas fa-plus"></i> {{__('strings.add_item')}}</button>
              <button type="button" class="btn btn-primary" onclick="showmod()"><i class="fas fa-eye"></i>{{__('strings.pay')}}</button>
              <button type="button" class="btn btn-primary" onclick="deliver()"><i class="fas fa-eye"></i>{{__('strings.deliver')}}</button>
              <button type="submit" name="action" value="3" class="btn btn-primary"><i class="fas fa-eye"></i>{{__('strings.save')}}</button>

          </div>
        </form>
                  </div>
              </div>

          </div>
      </div>
  </div>

  <!-- Main Wrapper -->

  </div>

  <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
  <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>

  <script>

  $(document).ready(function() {
      $("input[name$='delev']").click(function() {
          var test = $(this).val();

          $("div.desc").hide();
          $("#delev" + test).show();
      });
  });

  $(document).ready(function() {
  $('#main-wrapper').on('click','#addRow',function(){
         var data = `
     <tr>
     <td class="reg_flagg">
     <span class=" " style="display:none;"></span>
     <select name="reqFlag[]" form="newRequests" class="reg_flag_select form-control">
     <option value="-1">{{  __('strings.external_req_ex') }}</option>
     <option value="1">{{ __('strings.external_req_ret')}}</option>
     </select>
     </td>
    <td>
      <select name="cat_id[]" form="newRequests" class="cat_id_select form-control" required>
      <option class="btnTest" style="display:none"></option>
      @foreach ($services2 as  $value)
      <option class="btnTest" value="{{ $value->id }}">  {{ $value->name }} </option>
      @endforeach
      </select>
    </td>
    <td>
      <input class="form-control qnyNum" name="qny[]" form="newRequests" type="number" disabled required>
    </td>
    <td>
      <span class="cat_price"></span>
      <input class="cat_price_input"  form="newRequests" type="hidden" name="cat_price[]">
      <input class="tax_val" type="hidden"  form="newRequests" name="tax_val[]" required>
       <input class="taxId" name="taxId[]" type="hidden"   form="newRequests" required>

    </td>
    <td>
      <span class="tax"></span>
    </td>
    <td class="fprice_1">
      <span class="total"></span>
    </td>
    <td>
      <button type="button" id="deltr" style="color: red;"   class="btn btn-defult btn-close-regust2"><i class="fas fa-times"></i></button>
    </td>
     </tr>

  `;
      $('#xtreme-table tbody').append(data);
     });
    // $('#addRow').click();


      $('#delete_req').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget) // Button that triggered the modal
        var id = button.data('id') // Extract info from data-* attributes
        var cust = button.data('cust') // Extract info from data-* attributes
        var req = button.data('req') // Extract info from data-* attributes
        // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
        // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
        var modal = $(this)
        modal.find('.modal-body #trans_id').val(id)
        modal.find('.modal-body #cust_id').val(cust)
        modal.find('.modal-body #req_id').val(req)

      })
      $("#xtreme-table").on('click', '.btn-close-regust2', function () {
        var minus = 0,plus = 0;
        if ($(this).parents('tr').find('.reg_flagg select').val()  == -1) {
          minus = $('.finalTotalPrice').text()  -  $(this).parents('tr').find('.fPrice').text()  ;
          $('.finalTotalPrice').text(minus);
        }
        else if ($(this).parents('tr').find('.reg_flagg select').val()  == 1) {
          plus = $('.finalTotalPrice').text()  +  $(this).parents('tr').find('.fprice_1').text()  ;
          $('.finalTotalPrice').text(plus);
        }
        $(this).parents('tr').remove();
      });
  });

  </script>
  <script >
    $(document).ready(function() {

      $('#xtreme-table').on('change', '.cat_id_select' , function () {
        var url = "{{ Route('getServiceDetails') }}";

        var selected = $(this);
        // alert($('#menu_id').val());
        // Start Ajax
        $.ajaxSetup({
          headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }

        });
        $.ajax({
          url: url,
          dataType: 'json',
          data: {
            cat_id: $(this).find('option:selected').val(),
            flag_req: $(this).parents('tr').find('.reg_flagg option:selected').val(),

          },
          type: 'POST',

          beforeSend: function() {


            selected.parents('tr').find('.qnyNum').attr('disabled',true);
            selected.parents('tr').find('.tax').empty();
            selected.parents('tr').find('.cat_price').empty();
            selected.parents('tr').find('.qnyNum').empty();
            // selected.parents('tr').find('.id_hidden').empty();
            selected.parents('tr').find('.total').empty();
            selected.parents('tr').find('.taxId').empty();
            selected.parents('tr').find('.tax_val').empty();
            // selected.parents('tr').find('.invoice_no').empty();
            // selected.parents('tr').find('.invoice_date').empty();

          },
          success: function(msg) {
            if (msg.data == 'successGetPice') {
              // selected.find('option').val(msg.catId).attr('selected',true);
              selected.parents('tr').find('.tax_val').val(msg.catTax);
              selected.parents('tr').find('.tax').text(msg.catTax);
              selected.parents('tr').find('.cat_price_input').val(msg.catPrice);
              selected.parents('tr').find('.cat_price').text(msg.catPrice);
              selected.parents('tr').find('.qnyNum').attr('disabled',false);
              // selected.parents('tr').find('.id_hidden').val(msg.catId);
              selected.parents('tr').find('.qnyNum').val(1);
              selected.parents('tr').find('.total').text(msg.catPrice * selected.parents('tr').find('.qnyNum').val());
              selected.parents('tr').find('.taxId').val(msg.taxId);
              calcTotal(selected);
              var flag_req = 0

              if (selected.parents('tr').find('.reg_flag_select option:selected').val() == 1) {
                  selected.parents('tr').find('.qnyNum').attr('min',0);
                  selected.parents('tr').find('.qnyNum').val(1);

                  selected.parents('tr').find('.qnyNum').attr('max',msg.flag);
              }
              // flag
            ;
              // selected.parents('tr').find('.invoice_no').val(msg.invoice_date);
              // selected.parents('tr').find('.invoice_date').val(msg.invoice_date);

            }else{
              selected.parents('tr').find('.qnyNum').empty();
              selected.parents('tr').find('.reg_flag_select').html(
                ` <option value="-1">{{  __('strings.external_req_ex') }}</option>
                 <option value="1">{{ __('strings.external_req_ret')}}</option>`
              );

                selected.parents('td').html(
                  `
                  <select name="cat_id[]" form="newRequests" class="cat_id_select form-control" required>
                  <option class="btnTest" style="display:none"></option>
                  @foreach ($iterable as  $value)
                  <option class="btnTest" value="{{ $value->id }}"  >  {{ $value->name }} </option>
                  @endforeach
                  </select>
                  `);
                alert('هذا المنتج ليس له سعر');
            }

            }
          });
        return false;

      });

    });
    $('#confirm_Req').on('show.bs.modal', function (event) {
    var button = $(event.relatedTarget) // Button that triggered the modal
    var recipient = button.data('cust') // Extract info from data-* attributes
    var req = button.data('req') // Extract info from data-* attributes
        var payType = button.data('type') // Extract info from data-* attributes
    // console.log()

    // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
    // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
    var modal = $(this)
    modal.find('.modal-body .confirmCustId').val(recipient)
    modal.find('.modal-body .req_id_confrim').val(req)
    modal.find('.modal-body .payType').val(payType)
  });

  var allPrice  = 0;
  var allPrice2  = 0;
  // $(".fPrice span").each(function() {
  //   if ($(this).parents('tr').find('.reg_flagg span').text() == -1) {
  //     pri = parseFloat($(this).text())
  //     allPrice -= pri;
  //   }
  // });
  // $(".fprice_1 span").each(function() {
  //   var minus = parseFloat($(this).text());
  //   allPrice2 += minus;
  // });
    // var dd = allPrice - allPrice2;
    // $('.finalTotalPrice').text(dd.toFixed(2));

      $('#xtreme-table').on('change', '.reg_flagg select' , function () {
        if ($(this).parents('tr').find('.reg_flagg select').val() == -1) {
          var total = $(this).parents('tr').find('.fPrice').addClass('fprice_1') ;
          var total = $(this).parents('tr').find('.fPrice').removeClass('fPrice') ;
            $(this).parents('tr').find('.qnyNum').val(null);
            $(this).parents('tr').find('.cat_id_select').html(
              `
              <option class="btnTest" style="display:none"></option>
              @foreach ($services as  $value)
              <option class="btnTest" value="{{ $value->id }}"  >  {{ $value->name }} </option>
              @endforeach
              `);
        }else{
          var total = $(this).parents('tr').find('.fprice_1').addClass('fPrice') ;
          var total = $(this).parents('tr').find('.fprice_1').removeClass('fprice_1') ;
          var url = "{{ Route('getServiceReturn') }}";
          var selected = $(this);
          // alert($('#menu_id').val());
          // Start Ajax
          $.ajaxSetup({
            headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
          });
          $.ajax({
            url:  url,
            dataType: 'json',
            data: {
              reg_flag: selected.find('option:selected').val(),
              req_id: $('#request_id_span input').val(),
            },
            type: 'POST',

            beforeSend: function() {
              selected.parents('tr').find('.qnyNum').val(null);
              selected.parents('tr').find('.tax').empty();
              selected.parents('tr').find('.cat_price').empty();
              selected.parents('tr').find('.qnyNum').empty();
              selected.parents('tr').find('.total').empty();
              selected.parents('tr').find('.taxId').empty();
              selected.parents('tr').find('.tax_val').empty();

            },
            success: function(msg) {

              if (msg.returnMsg == 'successGitCats') {
                // console.log(msg.data);
                var data2 = `<option class="btnTest" style="display:none"></option>`;

                for(p in msg.data) {
                   data2 += `
                    <option value="`+ msg.data[p][0].id +`" >`+ msg.data[p][0].name +`</option>
                    `;
                  selected.parents('tr').find('.cat_id_select').html(data2);
                }
              }

              }
            });
          return false;
        }

        calcTotal($(this));
      });
      $('#xtreme-table').on('change', '.qnyNum' , function () {
        var total = $(this).val() * $(this).parents('tr').find('.cat_price').text() ;
        $(this).parents('tr').find('.total').text(total.toFixed(2));
        calcTotal($(this));
      });

      document.getElementById('serachExternalReqForm').addEventListener('keypress', function(event) {
          if (event.keyCode == 13) {
              $("#serachExternalReqForm").submit()
          }



      });

  </script>
  <script type="text/javascript">
    $(document).ready(function() {

              $('#close_reguest').on('show.bs.modal', function (event) {
              var button = $(event.relatedTarget) // Button that triggered the modal
              var req = button.data('req') // Extract info from data-* attributes
              var cust_id = button.data('cust') // Extract info from data-* attributes
              var total = button.data('total') // Extract info from data-* attributes
              var emp = button.data('emp') // Extract info from data-* attributes
              var status = button.data('status') // Extract info from data-* attributes
              // console.log()
              if (status == 'yx') {
                $('#bankSelect').hide();
                $('#selectId').attr('disabled',true);
                $('#selectId').attr('name','online_bank');
              }else{
                $('#bankSelect').show();
                $('#selectId').attr('disabled',false);
                $('#selectId').attr('name','bank_id');

              }
              // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
              // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
              var modal = $(this)
              modal.find('.modal-body #req_id_Confirm').val(req)
              modal.find('.modal-body #cust_id').val(cust_id)
              modal.find('.modal-body #total').val(total)
              modal.find('.modal-body #emp').val(emp)
          });
    });

    $('#due_date').on('change', function (event) {
      var tt = document.getElementById('delivery_date').value;

     var date = new Date(tt);

     var newdate = new Date(date);

     newdate.setDate(newdate.getDate() + parseInt(document.getElementById('due_date').value));

     var dd = newdate.getDate();
     var mm = newdate.getMonth()+1;
     var y = newdate.getFullYear();

     var someFormattedDate = mm + '/' + dd + '/' + y;
     document.getElementById('end_date').value = someFormattedDate;
    });

    function showmod() {
      var cat_id=[];
      $('select[name="cat_id[]"]').each(function(){
            cat_id.push(this.value);

        });
        var qny=[];
        $('input[name="qny[]"]').each(function(){
              qny.push(this.value);

          });
          var reqFlag=[];
          $('select[name="reqFlag[]"]').each(function(){
                reqFlag.push(this.value);

            });
            var taxId=[];
            $('input[name="taxId[]"]').each(function(){
                  taxId.push(this.value);

              });
              var tax_val=[];
              $('input[name="tax_val[]"]').each(function(){
                    tax_val.push(this.value);

                });
                var cat_price=[];
                $('input[name="cat_price[]"]').each(function(){
                      cat_price.push(this.value);

                  });

        console.log(cat_id);
      $.ajaxSetup({
        headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }

      });
      $.ajax({
url: "{{url('/admin/getpaymentdata')}}",
 type: "GET",
data: {
"cust_id": $('input[name="cust_id"]').val(),
"customer_req_head":$('input[name="customer_req_head"]').val(),
"cat_id":cat_id,
"qny":qny,
"reqFlag":reqFlag,
"cat_price":cat_price,
"taxId":taxId,
"tax_val":tax_val,
},
success: function (data){
  $('input[name="invoice_no"]').val(data.invoice_no);
  $('input[name="invoice_no1"]').val(data.invoice_no);
  $('input[name="paid"]').val(data.paid_amount);
  $('input[name="paid1"]').val(data.paid_amount);
  $('input[name="customer_id"]').val(data.cust_id);
  $('input[name="customer_head"]').val(data.customer_head);


  $.each(data.payment_method, function(key, value) {
      $('select[name="payment_method"]').append('<option value="'+ key +'">'+ value +'</option>');
      });
$(".modal1").show();


    }
  });
  }

    function closemod() {
        $(".modal1").hide();
    };
    function closemod2() {
        $(".modal2").hide();
    };
    function pay_method() {
      $.ajaxSetup({
        headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }

      });
      $.ajax({
url: "{{url('/admin/payServiceamount')}}",
 type: "post",
data: {
"cust_id": $('input[name="cust_id"]').val(),
"customer_req_head":$('input[name="customer_req_head"]').val(),
"amount":$('input[name="amount"]').val(),
"payment_method":$('select[name="payment_method"]').val(),
"payment_type":$('select[name="payment_type"]').val(),
"customer_head":$('input[name="customer_head"]').val(),
"customer_id":$('input[name="customer_id"]').val(),
"invoice_no":$('input[name="invoice_no"]').val(),
"total_amount":$('.finalTotalPrice').text()
},
success: function (data){


  closemod();
$('.alert_new').append('<a href="#" onclick="close_alert()" class="close_alert"> <i class="fas fa-times-circle">تم الدفع بنجاح</i> </a>')


    }
  });

    };
    function deliver_method() {
      $.ajaxSetup({
        headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }

      });
      $.ajax({
url: "{{url('/admin/deliverservice')}}",
 type: "post",
data: {
"cust_id": $('input[name="cust_id"]').val(),
"customer_req_head":$('input[name="customer_req_head"]').val(),
"customer_head":$('input[name="customer_head3"]').val(),
"customer_id":$('input[name="customer_id3"]').val(),
"invoice_no":$('input[name="invoice_no3"]').val(),
"delivered_name":$('input[name="delivered_name"]').val(),
"total_amount":$('.finalTotalPrice').text()
},
success: function (data){


  closemod2();
$('.alert_new').append('<a href="#" onclick="close_alert()" class="close_alert"> <i class="fas fa-times-circle">تم التسليم بنجاح</i> </a>')


    }
  });

    };
    function deliver() {
      var cat_id=[];
      $('select[name="cat_id[]"]').each(function(){
            cat_id.push(this.value);

        });
        var qny=[];
        $('input[name="qny[]"]').each(function(){
              qny.push(this.value);

          });
          var reqFlag=[];
          $('select[name="reqFlag[]"]').each(function(){
                reqFlag.push(this.value);

            });
            var taxId=[];
            $('input[name="taxId[]"]').each(function(){
                  taxId.push(this.value);

              });
              var tax_val=[];
              $('input[name="tax_val[]"]').each(function(){
                    tax_val.push(this.value);

                });
                var cat_price=[];
                $('input[name="cat_price[]"]').each(function(){
                      cat_price.push(this.value);

                  });

        console.log(cat_id);
        console.log($('input[name="customer_req_head"]').val());
      $.ajaxSetup({
        headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }

      });
      $.ajax({
url: "{{url('/admin/getdeliverydata')}}",
 type: "GET",
data: {
"cust_id": $('input[name="cust_id"]').val(),
"customer_req_head":$('input[name="customer_req_head"]').val(),
"cat_id":cat_id,
"qny":qny,
"reqFlag":reqFlag,
"cat_price":cat_price,
"taxId":taxId,
"tax_val":tax_val,
"total_amount":$('.finalTotalPrice').text()
},
success: function (data){
  if(data.msg!='notpaid'){
    $('input[name="invoice_no3"]').val(data.invoice_no);
    $('input[name="invoice_no3"]').val(data.invoice_no);
    $('input[name="customer_id3"]').val(data.cust_id);
    $('input[name="customer_head3"]').val(data.customer_head);
    $(".modal2").show();
  }

else {
  $('.alert_new').append('<a href="#" onclick="close_alert()" class="close_alert"> <i class="fas fa-times-circle">لايمكن التسليم قبل دفع المبلغ كاملا </i> </a>')
}


    }
  });
  }
  </script>




@endsection

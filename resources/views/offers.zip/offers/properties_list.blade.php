@extends('layouts.admin', ['title' => __('strings.Offers_properties_list') ])
@section('styles')
    <style>
        .service_button {
            background-color: white;
            color: black;
            border: 2px solid #555555;
        }
    </style>
@endsection
@section('content')
    <div id="main-wrapper">
        <div class="row">
            <div class="col-md-12">
                @include('alerts.index')
                <div class="btn-group">
                    <a class="btn btn-primary btn-lg btn-add" href="{{ url('admin/offers/properties/create') }}"><i class="fa fa-plus"></i>&nbsp;&nbsp;@lang('strings.add_properties_offer')</a>
                </div>
                <div role="tabpanel">
                    <div class="panel panel-white">
                        <div class="panel-heading clearfix">
                            <h4 class="panel-title">@lang('strings.Offers_list')</h4>
                        </div>
                        <div class="panel-body">
                            <div class="container">
                                <article class="panel-group bs-accordion" id="accordion" role="tablist" aria-multiselectable="true">
                                    @foreach($list as $value)
                                        <section class="panel panel-default">
                                            <div class="panel-heading" role="tab" id="headingOne">
                                                <h4 class="panel-title">
                                                    <a role="button" data-toggle="collapse" data-parent="#accordion" href="#item-{{ $value->id }}" aria-expanded="true" aria-controls="collapseOne">
                                                        <span style="padding: 0px 50px 0px 0px;"> {{ app()->getLocale() == 'ar' ? $value->name : $value->name_en }} </span>
                                                        <a class="btn pull-left" href="{{ url('admin/offers/properties', $value->id) }}/edit">
                                                            <i class="fa fa-edit"></i>&nbsp;&nbsp; {{ __('strings.edit') }}
                                                        </a>
                                                        <a class="btn pull-left" href="{{ url('admin/offers/properties', $value->id) }}/delete">
                                                            <i class="fa fa-close"></i>&nbsp;&nbsp; {{ __('strings.Delete') }}
                                                        </a>
                                                        <span class="glyphicon glyphicon-chevron-down pull-right" aria-hidden="true"></span>
                                                    </a>
                                                </h4>
                                            </div>
                                            <div id="item-{{ $value->id }}" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
                                                <div class="panel-body">
                                                    <div class="col-lg-4">
                                                        <h4 class="panel-title"> {{ __('strings.properties_offers') }} </h4>
                                                        <br>
                                                        <ul>
                                                            @php $minutes = 0; @endphp
                                                            @foreach(App\OfferDetails::where('offer_id', $value->id)->get() as $v)
                                                                @php
                                                                    $minutes += App\Category::where('id', $v->cat_id)->value('required_time') * 30;
                                                                @endphp
                                                            <li><p>{{ app()->getLocale() == 'ar' ? App\Category::where('id', $v->cat_id)->value('name') : App\Category::where('id', $v->cat_id)->value('name_en') }}</p></li>
                                                            @endforeach
                                                        </ul>

                                                    </div>
                                                    <div class="col-lg-4">
                                                        <h4 class="panel-title"> {{ __('strings.offer_days') }} </h4>
                                                        <br>
                                                        <ul>
                                                            @foreach(App\OfferDays::where('offer_id', $value->id)->orderBy('day', 'ASC')->get() as $v2)
                                                                <li><p> {{ $v2->day == 1 ? __('strings.saturday') : '' }} {{ $v2->day == 2 ? __('strings.sunday') : '' }} {{ $v2->day == 3 ? __('strings.monday') : '' }} {{ $v2->day == 4 ? __('strings.tuesday') : '' }}  {{ $v2->day == 5 ? __('strings.wednesday') : '' }}  {{ $v2->day == 6 ? __('strings.thursday') : '' }} {{ $v2->day == 7 ? __('strings.friday') : '' }} : @lang('strings.from') {{ !empty($v2->time_from) ? date('h:i A', strtotime($v2->time_from)) : ''}}  @lang('strings.to') {{ !empty($v2->time_to) ? date('h:i A', strtotime($v2->time_to)) : '' }} </p></li>
                                                            @endforeach
                                                        </ul>
                                                    </div>
                                                    <div class="col-lg-4">

                                                        <ul>
                                                            <li><p>{{ __('strings.properties_usage_price') }} : {{ Decimalplace($value->orig_price) }}</p> </li>
                                                            <li><p>{{ __('strings.offer_price') }} : {{ Decimalplace($value->offer_price) }}</p> </li>
                                                            <li><p>{{ __('strings.service_offer_expiry_date') }} : @lang('strings.from') {{ $value->date_from }}  @lang('strings.to') {{ $value->date_to }}</p> </li>
                                                        </ul>
                                                    </div>


                                                </div>
                                            </div>
                                        </section>
                                    @endforeach
                                </article>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('scripts')
<script>
    $(document).ready(function(){
        $('.collapsible').collapsible();
    });
</script>
@endsection
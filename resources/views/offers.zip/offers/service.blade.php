@extends('layouts.admin', ['title' => Request::is('admin/offers/service/create') ? __('strings.add_offer') : __('strings.edit_offer')])

@section('styles')
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.7/css/select2.min.css" rel="stylesheet" />
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.10/css/bootstrap-select.min.css" rel="stylesheet">
@endsection

@section('content')
    @include('alerts.index')
    @if(Request::is('admin/offers/service/create'))
    <div id="main-wrapper">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-white">
                <div class="panel-heading clearfix">
                    <div class="col-md-12">
                        <h4 class="panel-title"> {{ __('strings.add_offer') }} </h4>
                    </div>
                </div>
                <div class="panel-body">
                    @if(Session::has('message'))
                        <div class="row">
                            <div class="col-md-12">
                                <div class="alert alert-danger">
                                    {{Session::get('message')}}
                                </div>
                            </div>
                        </div>
                    @endif
                    <form method="post" action="{{ route('offers.service_store') }}" enctype="multipart/form-data" id="form">

                        {{csrf_field()}}
                        <div class="col-md-4 form-group{{$errors->has('offer_name') ? ' has-error' : ''}}">
                            <label class="control-label" for="offer_name">@lang('strings.Offer_name')</label>
                            <input type="text" class="form-control" name="offer_name" value="{{old('offer_name')}}" required>
                        </div>
                        
                        <div class="col-md-4 form-group{{$errors->has('offer_desc') ? ' has-error' : ''}}">
                            <label class="control-label" for="offer_desc">@lang('strings.offer_desc')</label>
                            <textarea class="form-control" name="offer_desc"></textarea>
                        </div>
                        
                        <div class="col-md-4 form-group{{$errors->has('photo_id') ? ' has-error' : ''}}">
                            <label for="photo_id" class="control-label">@lang('strings.Upload_photo')</label>
                            <input type="file" id="photo_id" name="photo_id" data-min-width="300" data-min-height="200">
                              <span class="help-block">
                                 <strong class="text-danger" style="font-size:12px;">ابعاد الصوره لا تقل عن 300*200</strong>
                              </span>
                              <hr>
                            @if ($errors->has('photo_id'))
                                <span class="help-block">
                                <strong class="text-danger">{{ $errors->first('photo_id') }}</strong>
                            </span>
                            @endif
                        </div>
                        
                        <div class="col-md-12"></div>
                        <!--div class="col-md-4 form-group{{$errors->has('categories') ? ' has-error' : ''}}">
                            <label class="control-label" for="categories">@lang('strings.service_offers')</label>
                            <select name="categories[]" class="form-control selectpicker" multiple title="@lang('strings.select_service_offers')" data-live-search="true" data-actions-box="true">
                                @foreach($services_list as $v)
                                    <option {{ old('categories') == $v->id ? 'selected' : '' }} value="{{ $v->id }}">{{ app()->getLocale() == 'ar' ? $v->name : $v->name_en }}</option>
                                @endforeach
                            </select>
                            @if ($errors->has('categories'))
                                <span class="help-block">
                                    <strong class="text-danger">{{ $errors->first('categories') }}</strong>
                                </span>
                            @endif
                        </div-->

                        <div class="col-md-4 form-group{{$errors->has('tax') ? ' has-error' : ''}}">
                            <label class="control-label" for="tax">@lang('strings.tax')</label>
                            <select name="tax" class="form-control js-select">
                                <option value="0">@lang('strings.select')</option>
                                @foreach(App\Tax::where([ 'active' => 1, 'org_id' => Auth::user()->org_id])->get() as $v)
                                    <option {{ old('tax') == $v->id ? 'selected' : '' }} value="{{ $v->id }}">{{ app()->getLocale() == 'ar' ? $v->name : $v->name_en }}</option>
                                @endforeach
                            </select>
                            @if ($errors->has('tax'))
                                <span class="help-block">
                                    <strong class="text-danger">{{ $errors->first('tax') }}</strong>
                                </span>
                            @endif
                        </div>

                        <div class="col-md-4 form-group{{$errors->has('date_from') ? ' has-error' : ''}}">
                            <label class="control-label" for="date_from">@lang('strings.Date_fromm')</label>
                            <input type="date" class="form-control" name="date_from" value="{{old('date_from', date('Y-m-d'))}}" required>
                            @if ($errors->has('date_from'))
                                <span class="help-block">
                                    <strong class="text-danger">{{ $errors->first('date_from') }}</strong>
                                </span>
                            @endif
                        </div>

                        <div class="col-md-4 form-group{{$errors->has('date_to') ? ' has-error' : ''}}">
                            <label class="control-label" for="date_to">@lang('strings.Date_too')</label>
                            <input type="date" class="form-control" name="date_to" value="{{old('date_to', date('Y-m-d'))}}" required>
                            @if ($errors->has('date_to'))
                                <span class="help-block">
                                    <strong class="text-danger">{{ $errors->first('date_to') }}</strong>
                                </span>
                            @endif
                        </div>

                        <div class="col-md-12">
                            <div class="panel-heading clearfix">
                                <div class="col-md-12">
                                    <h4 class="panel-title"> {{ __('strings.service_offers') }} </h4>
                                </div>
                            </div>
                            <div class="col-md-6 form-group{{$errors->has('categories') ? ' has-error' : ''}}">
                                <select class="form-control selectpicker" name="categories[]" required multiple title="@lang('strings.Service_list')" data-live-search="true" data-actions-box="true">
                                    @foreach($services_list as $v)
                                        @if($v->grouped == 1)
                                        @else
                                            <option value="{{ $v->id }}">{{ app()->getLocale() == 'ar' ? $v->name : $v->name_en }}</option>
                                        @endif
                                    @endforeach
                                </select>
                                @if ($errors->has('categories'))
                                    <span class="help-block">
                                        <strong class="text-danger">{{ $errors->first('categories') }}</strong>
                                    </span>
                                @endif
                            </div>
                            <!--<table id="tab_items" class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th width="15%">#</th>
                                        <th>@lang('strings.Service_list')</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr id='row-1'>
                                        <td>
                                            <a href="#" class="delete_row" data-toggle="tooltip" data-placement="bottom" data-original-title="حذف السطر">
                                                <i class="fa fa-close"></i>
                                            </a>
                                        </td>
                                        <td>
                                            <select class="form-control services_list" id="categories-1" name="categories[]" required>
                                                <option value="0">@lang('strings.select')</option>
                                                @foreach($services_list as $v)
                                                    @if($v->grouped == 1)
                                                    @else
                                                    <option value="{{ $v->id }}">{{ app()->getLocale() == 'ar' ? $v->name : $v->name_en }}</option>
                                                    @endif
                                                @endforeach
                                            </select>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="row clearfix">
                                <div class="col-md-12">
                                    <a href="#" onclick="additem(this)" class="btn btn-default pull-left">@lang('strings.add_file')</a>
                                </div>
                            </div>-->
                        </div>

                        <div class="col-md-12">
                            <br>
                            <div class="panel-heading clearfix">
                                <div class="col-md-12">
                                    <h4 class="panel-title"> {{ __('strings.days_offer') }} </h4>
                                </div>
                            </div>
                            <table id="" class="table table-bordered table-hover">
                                <thead>
                                <tr>
                                    <th>@lang('strings.Select_all') <input type="checkbox" id="checkAll"> </th>
                                    <th>@lang('strings.day')</th>
                                    <th>@lang('strings.time_from')</th>
                                    <th>@lang('strings.time_to')</th>
                                </tr>
                                </thead>
                                <tbody>
                                    <tr id='row-1'>
                                        <td> <input type="checkbox" name="selected[]" value="1" {{$shiftDays[6]->shift_day==1?'checked':''}}></td>
                                        <td> @lang('strings.saturday') </td>
                                        <td> <input name="time_from[]" type="time" class="form-control" value="{{time_from_id2($shiftDays[6]->time_from)}}"></td>
                                        <td> <input name="time_to[]" type="time" class="form-control" value="{{time_from_id2($shiftDays[6]->time_to)}}"></td>
                                    </tr>
                                    <tr id='row-2'>
                                        <td> <input type="checkbox" name="selected[]" value="2" {{$shiftDays[0]->shift_day==2?'checked':''}}></td>
                                        <td> @lang('strings.sunday')</td>
                                        <td> <input name="time_from[]" type="time" class="form-control" value="{{time_from_id2($shiftDays[0]->time_from)}}"></td>
                                        <td> <input name="time_to[]" type="time" class="form-control" value="{{time_from_id2($shiftDays[0]->time_to)}}"></td>
                                    </tr>
                                    <tr id='row-3'>
                                        <td> <input type="checkbox" name="selected[]" value="3" {{$shiftDays[1]->shift_day==3?'checked':''}}></td>
                                        <td> @lang('strings.monday')</td>
                                        <td> <input name="time_from[]" type="time" class="form-control" value="{{time_from_id2($shiftDays[1]->time_from)}}"></td>
                                        <td> <input name="time_to[]" type="time" class="form-control" value="{{time_from_id2($shiftDays[1]->time_to)}}"></td>
                                    </tr>
                                    <tr id='row-4'>
                                        <td> <input type="checkbox" name="selected[]" value="4" {{$shiftDays[2]->shift_day==4?'checked':''}}></td>
                                        <td> @lang('strings.tuesday')</td>
                                        <td> <input name="time_from[]" type="time" class="form-control" value="{{time_from_id2($shiftDays[2]->time_from)}}"></td>
                                        <td> <input name="time_to[]" type="time" class="form-control" value="{{time_from_id2($shiftDays[2]->time_to)}}"></td>
                                    </tr>
                                    <tr id='row-5'>
                                        <td> <input type="checkbox" name="selected[]" value="5" {{$shiftDays[3]->shift_day==5?'checked':''}}></td>
                                        <td> @lang('strings.wednesday')</td>
                                        <td> <input name="time_from[]" type="time" class="form-control" value="{{time_from_id2($shiftDays[3]->time_from)}}"></td>
                                        <td> <input name="time_to[]" type="time" class="form-control" value="{{time_from_id2($shiftDays[3]->time_to)}}"></td>
                                    </tr>
                                    <tr id='row-6'>
                                        <td> <input type="checkbox" name="selected[]" value="6" {{$shiftDays[4]->shift_day==6?'checked':''}}></td>
                                        <td> @lang('strings.thursday')</td>
                                        <td> <input name="time_from[]" type="time" class="form-control" value="{{time_from_id2($shiftDays[4]->time_from)}}"></td>
                                        <td> <input name="time_to[]" type="time" class="form-control" value="{{time_from_id2($shiftDays[4]->time_to)}}"></td>
                                    </tr>
                                    <tr id='row-7'>
                                        <td> <input type="checkbox" name="selected[]" value="7" {{$shiftDays[5]->shift_day==7?'checked':''}}></td>
                                        <td> @lang('strings.friday')</td>
                                        <td> <input name="time_from[]" type="time" class="form-control" value="{{time_from_id2($shiftDays[5]->time_from)}}"></td>
                                        <td> <input name="time_to[]" type="time" class="form-control" value="{{time_from_id2($shiftDays[5]->time_to)}}"></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <div class="col-md-6 form-group{{$errors->has('total_price') ? ' has-error' : ''}}">
                            <label class="control-label" for="total_price">@lang('strings.offer_total_price_without_tax')</label>
                            <input type="number" step="any" class="form-control" name="total_price" value="{{old('total_price')}}" required>
                        </div>

                        <div class="col-md-6 form-group{{$errors->has('offer_price') ? ' has-error' : ''}}">
                            <label class="control-label" for="offer_price">@lang('strings.offer_price_without_tax')</label>
                            <input type="number" step="any" class="form-control" name="offer_price" value="{{old('offer_price')}}" required>
                        </div>

                        <div class="col-md-12 form-group text-right">
                            <button type="submit" class="btn btn-primary btn-lg" id="submit"> @lang('strings.Save') </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
    @endif
    @if(Request::is('admin/offers/service/*/edit'))
        <div id="main-wrapper">
            <div class="row">
                <div class="col-md-12">
                    <div class="panel panel-white">
                        <div class="panel-heading clearfix">
                            <div class="col-md-12">
                                <h4 class="panel-title"> {{ __('strings.edit_offer') }} </h4>
                            </div>
                        </div>
                        <div class="panel-body">
                            @if(Session::has('message'))
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="alert alert-danger">
                                            {{Session::get('message')}}
                                        </div>
                                    </div>
                                </div>
                            @endif
                            <form method="post" action="{{ route('offers.service_edit', $offer->id) }}" enctype="multipart/form-data" id="form">
                                {{csrf_field()}}
                                {{ method_field('PATCH') }}
                                @php
                                    $category = App\Category::where('id', $offer->cat_id)->first();
                                @endphp
                                
                                <div class="col-md-4 form-group{{$errors->has('offer_name') ? ' has-error' : ''}}">
                                    <label class="control-label" for="offer_name">@lang('strings.Offer_name')</label>
                                    <input type="text" class="form-control" name="offer_name" value="{{ app()->getLocale() == 'ar' ? $offer->name : $offer->name_en }}" required>
                                </div>
                                <div class="col-md-4 form-group{{$errors->has('offer_desc') ? ' has-error' : ''}}">
                                    <label class="control-label" for="offer_desc">@lang('strings.offer_desc')</label>
                                    <textarea class="form-control" name="offer_desc">{{ app()->getLocale() == 'ar' ? $offer->description : $offer->description_en }}</textarea>
                                </div>
                                <div class="col-md-4 form-group{{$errors->has('photo_id') ? ' has-error' : ''}}">
                                    <label for="photo_id" class="control-label">@lang('strings.Upload_photo')</label>
                                    <input type="file" id="photo_id" name="photo_id" data-min-width="300" data-min-height="200">
                                    <span class="help-block">
                                         <strong class="text-danger" style="font-size:12px;">ابعاد الصوره لا تقل عن 300*200</strong>
                                     </span>
                                    <hr>
                                    @if ($errors->has('photo_id'))
                                        <span class="help-block">
                                        <strong class="text-danger">{{ $errors->first('photo_id') }}</strong>
                                    </span>
                                    @else
                                        <img src="{{ $category->photo_id !== null ? asset($category->photo->file) : asset('images/profile-placeholder.png') }}" class="img-responsive">
                                    @endif
                                </div>
                                <div class="col-md-12"></div>
                                <div class="col-md-4 form-group{{$errors->has('tax') ? ' has-error' : ''}}">
                                    <label class="control-label" for="tax">@lang('strings.tax')</label>
                                    <select name="tax" class="form-control js-select">
                                        <option value="0">@lang('strings.select')</option>
                                        @foreach(App\Tax::where([ 'active' => 1, 'org_id' => Auth::user()->org_id])->get() as $v)
                                            <option {{ App\PriceList::where('cat_id', $offer->cat_id)->value('tax') == $v->id ? 'selected' : '' }} value="{{ $v->id }}">{{ app()->getLocale() == 'ar' ? $v->name : $v->name_en }}</option>
                                        @endforeach
                                    </select>
                                    @if ($errors->has('tax'))
                                        <span class="help-block">
                                            <strong class="text-danger">{{ $errors->first('tax') }}</strong>
                                        </span>
                                    @endif
                                </div>

                                <div class="col-md-4 form-group{{$errors->has('date_from') ? ' has-error' : ''}}">
                                    <label class="control-label" for="date_from">@lang('strings.Date_fromm')</label>
                                    <input type="date" class="form-control" name="date_from" value="{{ $offer->date_from }}" required>
                                    @if ($errors->has('date_from'))
                                        <span class="help-block">
                                            <strong class="text-danger">{{ $errors->first('date_from') }}</strong>
                                        </span>
                                    @endif
                                </div>

                                <div class="col-md-4 form-group{{$errors->has('date_to') ? ' has-error' : ''}}">
                                    <label class="control-label" for="date_to">@lang('strings.Date_too')</label>
                                    <input type="date" class="form-control" name="date_to" value="{{ $offer->date_to }}" required>
                                    @if ($errors->has('date_to'))
                                        <span class="help-block">
                                            <strong class="text-danger">{{ $errors->first('date_to') }}</strong>
                                        </span>
                                    @endif
                                </div>

                                <div class="col-md-12">
                                    <div class="panel-heading clearfix">
                                        <div class="col-md-12">
                                            <h4 class="panel-title"> {{ __('strings.service_offers') }} </h4>
                                        </div>
                                    </div>
                                    <div class="col-md-6 form-group{{$errors->has('categories') ? ' has-error' : ''}}">
                                        <select class="form-control selectpicker" name="categories[]" required multiple title="@lang('strings.Service_list')" data-live-search="true" data-actions-box="true">
                                            @foreach($services_list as $v)
                                                @if($v->grouped == 1)
                                                @else
                                                    <option {{ App\OfferDetails::where(['offer_id' => $offer->id, 'cat_id' => $v->id])->exists() ? 'selected' : '' }} value="{{ $v->id }}">{{ app()->getLocale() == 'ar' ? $v->name : $v->name_en }}</option>
                                                @endif
                                            @endforeach
                                        </select>
                                        @if ($errors->has('categories'))
                                            <span class="help-block">
                                                <strong class="text-danger">{{ $errors->first('categories') }}</strong>
                                            </span>
                                        @endif
                                    </div>
                                    <!--<table id="tab_items" class="table table-bordered table-hover">
                                        <thead>
                                            <tr>
                                                <th width="15%">#</th>
                                                <th>@lang('strings.Service_list')</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @php $count = 1; @endphp
                                            @foreach(App\OfferDetails::where('offer_id', $offer->id)->get() as $value)
                                                <tr id='row-{{ $count }}'>
                                                    <td>
                                                        <a href="#" class="delete_row" data-toggle="tooltip" data-placement="bottom" data-original-title="حذف السطر">
                                                            <i class="fa fa-close"></i>
                                                        </a>
                                                    </td>
                                                    <td>
                                                        <select class="form-control services_list" id="categories-{{ $count }}" name="categories[]" required>
                                                            <option value="0">@lang('strings.select')</option>
                                                            @foreach($services_list as $v)
                                                                
                                                                @if($v->grouped == 1)
                                                                @else
                                                                <option {{ $value->cat_id == $v->id ? 'selected' : '' }}  value="{{ $v->id }}">{{ app()->getLocale() == 'ar' ? $v->name : $v->name_en }}</option>
                                                                @endif
                                                            @endforeach
                                                        </select>
                                                    </td>
                                                </tr>
                                                @php $count++; @endphp
                                            @endforeach
                                        </tbody>
                                    </table>
                                    <div class="row clearfix">
                                        <div class="col-md-12">
                                            <a href="#" onclick="additem(this)" class="btn btn-default pull-left">@lang('strings.add_file')</a>
                                        </div>
                                    </div>-->
                                </div>

                                <div class="col-md-12">
                                    <br>
                                    <div class="panel-heading clearfix">
                                        <div class="col-md-12">
                                            <h4 class="panel-title"> {{ __('strings.days_offer') }} </h4>
                                        </div>
                                    </div>
                                    <table id="" class="table table-bordered table-hover">
                                        <thead>
                                            <tr>
                                                <th>@lang('strings.Select_all') <input type="checkbox" id="checkAll"> </th>
                                                <th>@lang('strings.day')</th>
                                                <th>@lang('strings.time_from')</th>
                                                <th>@lang('strings.time_to')</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr id='row-1'>
                                                <td> <input type="checkbox" name="selected[]" value="1" {{ App\OfferDays::where(['offer_id' => $offer->id, 'day' => 1])->exists() ? 'checked' : '' }} ></td>
                                                <td> @lang('strings.saturday') </td>
                                                <td> <input name="time_from[]" type="time" class="form-control" value="{{ App\OfferDays::where(['offer_id' => $offer->id, 'day' => 1])->value('time_from') }}"></td>
                                                <td> <input name="time_to[]" type="time" class="form-control" value="{{ App\OfferDays::where(['offer_id' => $offer->id, 'day' => 1])->value('time_to') }}"></td>
                                            </tr>
                                            <tr id='row-2'>
                                                <td> <input type="checkbox" name="selected[]" value="2" {{ App\OfferDays::where(['offer_id' => $offer->id, 'day' => 2])->exists() ? 'checked' : '' }}></td>
                                                <td> @lang('strings.sunday')</td>
                                                <td> <input name="time_from[]" type="time" class="form-control" value="{{ App\OfferDays::where(['offer_id' => $offer->id, 'day' => 2])->value('time_from') }}"></td>
                                                <td> <input name="time_to[]" type="time" class="form-control" value="{{ App\OfferDays::where(['offer_id' => $offer->id, 'day' => 2])->value('time_to') }}"></td>
                                            </tr>
                                            <tr id='row-3'>
                                                <td> <input type="checkbox" name="selected[]" value="3" {{ App\OfferDays::where(['offer_id' => $offer->id, 'day' => 3])->exists() ? 'checked' : '' }}></td>
                                                <td> @lang('strings.monday')</td>
                                                <td> <input name="time_from[]" type="time" class="form-control" value="{{ App\OfferDays::where(['offer_id' => $offer->id, 'day' => 3])->value('time_from') }}"></td>
                                                <td> <input name="time_to[]" type="time" class="form-control" value="{{ App\OfferDays::where(['offer_id' => $offer->id, 'day' => 3])->value('time_to') }}"></td>
                                            </tr>
                                            <tr id='row-4'>
                                                <td> <input type="checkbox" name="selected[]" value="4" {{ App\OfferDays::where(['offer_id' => $offer->id, 'day' => 4])->exists() ? 'checked' : '' }}></td>
                                                <td> @lang('strings.tuesday')</td>
                                                <td> <input name="time_from[]" type="time" class="form-control" value="{{ App\OfferDays::where(['offer_id' => $offer->id, 'day' => 4])->value('time_from') }}"></td>
                                                <td> <input name="time_to[]" type="time" class="form-control" value="{{ App\OfferDays::where(['offer_id' => $offer->id, 'day' => 4])->value('time_to') }}"></td>
                                            </tr>
                                            <tr id='row-5'>
                                                <td> <input type="checkbox" name="selected[]" value="5" {{ App\OfferDays::where(['offer_id' => $offer->id, 'day' => 5])->exists() ? 'checked' : '' }}></td>
                                                <td> @lang('strings.wednesday')</td>
                                                <td> <input name="time_from[]" type="time" class="form-control" value="{{ App\OfferDays::where(['offer_id' => $offer->id, 'day' => 5])->value('time_from') }}"></td>
                                                <td> <input name="time_to[]" type="time" class="form-control" value="{{ App\OfferDays::where(['offer_id' => $offer->id, 'day' => 5])->value('time_to') }}"></td>
                                            </tr>
                                            <tr id='row-6'>
                                                <td> <input type="checkbox" name="selected[]" value="6" {{ App\OfferDays::where(['offer_id' => $offer->id, 'day' => 6])->exists() ? 'checked' : '' }}></td>
                                                <td> @lang('strings.thursday')</td>
                                                <td> <input name="time_from[]" type="time" class="form-control" value="{{ App\OfferDays::where(['offer_id' => $offer->id, 'day' => 6])->value('time_from') }}"></td>
                                                <td> <input name="time_to[]" type="time" class="form-control" value="{{ App\OfferDays::where(['offer_id' => $offer->id, 'day' => 6])->value('time_to') }}"></td>
                                            </tr>
                                            <tr id='row-7'>
                                                <td> <input type="checkbox" name="selected[]" value="7" {{ App\OfferDays::where(['offer_id' => $offer->id, 'day' => 7])->exists() ? 'checked' : '' }}></td>
                                                <td> @lang('strings.friday')</td>
                                                <td> <input name="time_from[]" type="time" class="form-control" value="{{ App\OfferDays::where(['offer_id' => $offer->id, 'day' => 7])->value('time_from') }}"></td>
                                                <td> <input name="time_to[]" type="time" class="form-control" value="{{ App\OfferDays::where(['offer_id' => $offer->id, 'day' => 7])->value('time_to') }}"></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>

                                <div class="col-md-4 form-group{{$errors->has('total_price') ? ' has-error' : ''}}">
                                    <label class="control-label" for="total_price">@lang('strings.offer_total_price_without_tax')</label>
                                    <input type="number" step="any" class="form-control" name="total_price" value="{{ $offer->orig_price }}" required>
                                </div>

                                <div class="col-md-4 form-group{{$errors->has('offer_price') ? ' has-error' : ''}}">
                                    <label class="control-label" for="offer_price">@lang('strings.offer_price_without_tax')</label>
                                    <input type="number" step="any" class="form-control" name="offer_price" value="{{ $offer->discount_price }}" required>
                                </div>

                                <div class="col-md-4 form-group{{$errors->has('offer_price') ? ' has-error' : ''}}">
                                    <label class="control-label" for="offer_price">@lang('strings.offer_price_with_tax')</label>
                                    <input type="number" step="any" class="form-control" name="a" value="{{ $offer->offer_price }}" readonly>
                                </div>

                                <div class="col-md-12 form-group text-right">
                                    <button type="submit" class="btn btn-primary btn-lg" id="submit"> @lang('strings.Save') </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    @endif
@endsection

@section('scripts')
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.7/js/select2.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.10/js/bootstrap-select.min.js"></script>
 <script src="{{asset('js/jquery.checkImageSize.min.js')}}"></script>
<script>


       $("input[type='file']").checkImageSize({
              minWidth: $(this).data('min-width'),
              minHeight: $(this).data('min-height'),
            showError:true,
            ignoreError:false
        });
        
      


    $('.services_list').select2();
    function additem(){
        $('.services_list').select2('destroy');

        var row = $("#tab_items tr").last().clone();
        var oldId = Number(row.attr('id').slice(-1));
        var id = 1 + oldId;

        row.attr('id', 'row-' + id );
        row.find('#categories-' + oldId).attr('id', 'categories-' + id).attr('data-select2-id', 'categories-' + id);

        $('#tab_items').append(row);
        $('.services_list').select2();

    }
    
    $('.selectpicker').selectpicker({
        selectAllText: 'اختر الكل',
        deselectAllText: 'الغاء الكل'
    });
    
    $(document).on('click', '.delete_row', function () {
        if($('#tab_items tbody tr').length != 1 && $(this).closest('tr').attr('id') != 'row-1') {
            $(this).closest('tr').remove();
            return false;
        }
    });
    $("#checkAll").click(function(){
        $('input:checkbox').not(this).prop('checked', this.checked);
    });

</script>
@endsection
@extends('layouts.admin', ['title' => __('strings.add_offer') ])
@section('styles')
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.7/css/select2.min.css" rel="stylesheet" />
@endsection
@section('content')
    <!--<div class="page-title">-->
    <!--    <h3> @lang('strings.Offers_list_add') </h3>-->
    <!--    <div class="page-breadcrumb">-->
    <!--        <ol class="breadcrumb">-->
    <!--            <li><a href="{{ route('home') }}">@lang('strings.Home')</a></li>-->
    <!--            <li><a href="{{ route('offers.index') }}"> @lang('strings.Offers_list')</a></li>-->
    <!--            <li class="active"> {{ $type == 1 ? __('strings.Offers_list_add') : __('strings.Offers_list_add_service') }}</li>-->
    <!--        </ol>-->
    <!--    </div>-->
    <!--</div>-->

    <div id="main-wrapper">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-white">
                    <div class="panel-heading clearfix">
                        <div class="col-md-12">
                            <h4 class="panel-title"> {{ __('strings.add_offer') }} </h4>
                        </div>
                    </div>
                    <div class="panel-body">
                        @if(Session::has('message'))
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="alert alert-danger">
                                        {{Session::get('message')}}
                                    </div>
                                </div>
                            </div>
                        @endif
                        <form method="post" action="{{route('offers.store')}}" enctype="multipart/form-data" id="form">

                            {{csrf_field()}}
                            <input value="{{ $type }}" name="type" type="hidden">

                            <div class="col-md-4 form-group{{$errors->has('categories_type') ? ' has-error' : ''}}"> <strong class="text-danger">*</strong>
                                <label class="control-label" for="categories_type">@lang('strings.Categories_type')</label>
                                <select class="form-control js-select" name="categories_type" id="categories_types_offerss" required>
                                    <option value="0">@lang('strings.select')</option>
                                    @foreach(App\CategoriesType::where(['type' => $type, 'org_id' => Auth::user()->org_id])->get() as $v)
                                        <option {{ old('categories_type') == $v->id ? 'selected' : '' }} value="{{ $v->id }}">{{   app()->getLocale() == 'ar' ? $v->name : $v->name_en }}</option>
                                    @endforeach
                                </select>
                                <input type="hidden" id="select_categories_types" name="select_categories_types" value="{{ old('select_categories_types') }}">
                            @if ($errors->has('categories_type'))
                                    <span class="help-block">
                                        <strong class="text-danger">{{ $errors->first('categories_type') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="col-md-4 form-group{{$errors->has('categories') ? ' has-error' : ''}}"> <strong class="text-danger">*</strong>
                                <label class="control-label" for="categories">@lang('strings.Item')</label>
                                <select class="form-control js-select" name="categories" id="categoriess" required>

                                </select>
                                <input type="hidden" id="select_categories" name="select_categories" value="{{ old('select_categories') }}">

                                @if ($errors->has('categories'))
                                    <span class="help-block">
                                        <strong class="text-danger">{{ $errors->first('categories') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="col-md-4 form-group{{$errors->has('discount_type') ? ' has-error' : ''}}">
                                <label class="control-label" for="discount_type">@lang('strings.Discount_type')</label>
                                <select class="form-control" name="discount_type" id="discount_type" required>
                                    <option {{ old('discount_type') == 0 ? 'selected' : '' }} value="0">@lang('strings.Select_discount_type')</option>
                                    <option {{ old('discount_type') == 1 ? 'selected' : '' }} value="1">@lang('strings.Percentage')</option>
                                    <option {{ old('discount_type') == 2 ? 'selected' : '' }} value="2">@lang('strings.Value')</option>
                                </select>
                                @if ($errors->has('discount_type'))
                                    <span class="help-block">
                                        <strong class="text-danger">{{ $errors->first('discount_type') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="col-md-4 form-group{{$errors->has('discount_value') ? ' has-error' : ''}}" @if($errors->has('discount_value')) @else style="display: none" @endif id="discountsss">
                                <label class="control-label" for="discount_value">@lang('strings.Discount')</label>
                                <input type="number" class="form-control" name="discount_value" value="{{old('discount_value')}}" id="discount_value" min="1">
                                @if ($errors->has('discount_value'))
                                    <span class="help-block">
                                        <strong class="text-danger">{{ $errors->first('discount_value') }}</strong>
                                    </span>
                                @endif
                            </div>
                            <div class="col-md-4 form-group{{$errors->has('active') ? ' has-error' : ''}}"> <strong class="text-danger">*</strong>
                                <label class="control-label" for="active">@lang('strings.Status')</label>
                                <select class="form-control" name="active">
                                    <option value="1">@lang('strings.Active')</option>
                                    <option value="0">@lang('strings.Deactivate')</option>
                                </select>
                                @if ($errors->has('active'))
                                    <span class="help-block">
                                        <strong class="text-danger">{{ $errors->first('active') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="col-md-4 form-group{{$errors->has('date_from') ? ' has-error' : ''}}">
                                <label class="control-label" for="date_from">@lang('strings.Date_fromm')</label>
                                <input type="date" class="form-control" name="date_from" value="{{old('date_from', date('Y-m-d'))}}" required>
                                @if ($errors->has('date_from'))
                                    <span class="help-block">
                                        <strong class="text-danger">{{ $errors->first('date_from') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="col-md-4 form-group{{$errors->has('date_to') ? ' has-error' : ''}}">
                                <label class="control-label" for="date_to">@lang('strings.Date_too')</label>
                                <input type="date" class="form-control" name="date_to" value="{{old('date_to', date('Y-m-d'))}}" required>
                                @if ($errors->has('date_to'))
                                    <span class="help-block">
                                        <strong class="text-danger">{{ $errors->first('date_to') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="col-md-4 form-group{{$errors->has('infrontpage') ? ' has-error' : ''}}">
                                <label class="control-label" for="infrontpage">@lang('strings.Infrontpage')</label>
                                <input type="checkbox" name="infrontpage" checked>
                            </div>

                            <input type="hidden" id="org-price">
                            <input type="hidden" id="discount-prices" value="0">
                            <input type="hidden" id="org-tax">
                            
                            <div class="col-md-12">
                                <h2>@lang('strings.Total')</h2>

                                <ul style="list-style-type:disc" id="clac">
                                    <li id="tax">@lang('strings.Tax_value') : 0 </li>
                                    <li id="discount">@lang('strings.Discount_value')  : 0</li>
                                    <li id="discount-price">@lang('strings.Discount_price')  : 0</li>
                                    <li id="offer-price"> @lang('strings.Offer_price') : 0</li>
                                </ul>
                            </div>


                            <div class="col-md-12 form-group text-right">
                                <button type="submit" class="btn btn-primary btn-lg" id="submit"> @lang('strings.Save') </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        
        

        
    </script>
@endsection
@section('scripts')
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.7/js/select2.min.js"></script>
    <script>
        $( document ).ready(function() {
            $.get("{{ url('admin/offers/get-categories/') }}/" + $('#select_categories_types').val(), function (data) {
                $("#categoriess").empty();
                $("#categoriess").append("<option value='0'> @lang('strings.Select_item')</option>");
                $.each(data, function (key, value) {
                    $("#categoriess").append("<option value='" + value.id + "'>" + @if(app()->getLocale() == 'ar') value.name @else value.name_en @endif + "</option>");
                });
                $("#categoriess").val($("#select_categories").val());
            });
        });

        $("#categories_types_offerss").change(function () {
            $("#select_categories_types").val(this.value);
        });

        $("#categoriess").change(function () {
            $("#select_categories").val(this.value);
        });

        $("#categories_types_offerss").change(function () {
            $.get("{{ url('admin/offers/get-categories/') }}/" + this.value, function (data) {
                $("#categoriess").empty();
                $("#categoriess").append("<option value='0'> @lang('strings.Select_item')</option>");
                $.each(data, function (key, value) {
                    $("#categoriess").append("<option value='" + value.id + "'>" + @if(app()->getLocale() == 'ar') value.name @else value.name_en @endif + "</option>");
                });
                alert("@lang('strings.categories_types_all')");
            });
        });

        $("#categoriess").change(function () {
            $.get("{{ url('admin/offers/get-price/') }}/" + this.value, function (data) {
                $("#org-price").val(data.price);
                if(data.tax_value == null){
                    $("#org-tax").val(0);
                    $("#tax").html("<li>@lang('strings.Tax_value')  : " +  0  + "</li>");
                }else{
                    $("#org-tax").val(data.tax_value);
                    $("#tax").html("<li>@lang('strings.Tax_value')  :" +  data.tax_value + "</li>");
                }
                console.log(data);    
                if(data.price == 0){
                    alert("@lang('strings.Price_doesntExist')")
                }
            });
            $("#categories").val($("#select_categories").val());

        });

        $("#discount_type").change(function () {
            if(this.value == 1 || this.value == 2) {
                $("#discountsss").show();
            }else{
                $("#discountsss").hide();
            }
        });

        $("#discount_value").change(function () {
            if(parseFloat($('#org-tax').val()) <= 100){
                var tax = parseFloat($('#org-tax').val()) / 100 * (parseFloat($('#org-price').val()) - parseFloat($('#discount_value').val()) / 100 * parseFloat($('#org-price').val()));
            }else{
                var tax = parseFloat($('#org-tax').val());
            }
            if($("#discount_type").val() == 1){
                $("#discount").html("<li>@lang('strings.Discount')  : % " +  parseFloat($('#discount_value').val()) + "</li>");
                $("#discount-price").html("<li>@lang('strings.Discount_price')  :" +  (parseFloat($('#org-price').val()) - parseFloat($('#discount_value').val()) / 100 * parseFloat($('#org-price').val())).toFixed(2)  + "</li>");
                $("#offer-price").html("<li>@lang('strings.Offer_price')  :" +  ((parseFloat($('#org-price').val()) - parseFloat($('#discount_value').val()) / 100 * parseFloat($('#org-price').val()))  +  tax).toFixed(2) + "</li>");
            }else{
                $("#discount").html("<li>@lang('strings.Discount')  :" +  parseFloat($('#discount_value').val()) + "</li>");
                $("#discount-price").html("<li>@lang('strings.Discount_price')  :" +  (parseFloat($('#org-price').val()) - parseFloat($('#discount_value').val())).toFixed(2)  + "</li>");
                $("#offer-price").html("<li>@lang('strings.Offer_price')  :" +  ((parseFloat($('#org-price').val()) - parseFloat($('#discount_value').val())) +  tax).toFixed(2) + "</li>");
            }

        });
    </script>
@endsection
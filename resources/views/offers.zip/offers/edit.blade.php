@extends('layouts.admin', ['title' => __('strings.edit') ])
@section('styles')
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.7/css/select2.min.css" rel="stylesheet" />
@endsection
@section('content')
    <!--<div class="page-title">-->
    <!--    <h3> {{ $type == 1 ? __('strings.Offers_list_edit') : __('strings.Offers_list_edit_service') }} </h3>-->
    <!--    <div class="page-breadcrumb">-->
    <!--        <ol class="breadcrumb">-->
    <!--            <li><a href="{{ route('home') }}">@lang('strings.Home')</a></li>-->
    <!--            <li><a href="{{ route('offers.index') }}"> @lang('strings.Offers_list')</a></li>-->
    <!--            <li class="active">{{ $type == 1 ? __('strings.Offers_list_edit') : __('strings.Offers_list_edit_service') }}</li>-->
    <!--        </ol>-->
    <!--    </div>-->
    <!--</div>-->

    <div id="main-wrapper">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-white">
                    <div class="panel-heading clearfix">
                        <h4 class="panel-title"> {{ __('strings.edit') }} </h4>
                    </div>
                    <div class="panel-body">

                        <form method="POST" action="{{ route('offers.update', $list->id) }}" enctype="multipart/form-data">

                            {{csrf_field()}}
                            {{ method_field('PATCH') }}
                            <input value="{{ $list->cat_id }}" type="hidden" name="categories">


                            <div class="col-md-6 form-group{{$errors->has('categories') ? ' has-error' : ''}}"> <strong class="text-danger">*</strong>
                                <label class="control-label" for="categories">@lang('strings.Item')</label>
                                <input type="text" class="form-control"  value="{{app()->getLocale()=='ar'?App\Category::findOrFail($list->cat_id)->name:App\Category::findOrFail($list->cat_id)->name_en}}" disabled>
                                @if ($errors->has('categories'))
                                    <span class="help-block">
                                        <strong class="text-danger">{{ $errors->first('categories') }}</strong>
                                    </span>
                                @endif
                            </div>
                            <div class="col-md-6 form-group{{$errors->has('discount_type') ? ' has-error' : ''}}">
                                <label class="control-label" for="discount_type">@lang('strings.Discount_type')</label>
                                <select class="form-control js-select" name="discount_type" id="discount_type">
                                    <option value="0">@lang('strings.Select_discount_type')</option>
                                    <option {{ $list->discount_type == 1 ? 'selected' : '' }} value="1">@lang('strings.Percentage')</option>
                                    <option {{ $list->discount_type == 2 ? 'selected' : '' }} value="2">@lang('strings.Value')</option>
                                </select>
                                @if ($errors->has('discount_type'))
                                    <span class="help-block">
                                        <strong class="text-danger">{{ $errors->first('discount_type') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="col-md-6 form-group{{$errors->has('discount_value') ? ' has-error' : ''}}" @if(isset($list->discount_type) && isset($list->discount_value))  @else style="display: none" @endif id="discountsss">
                                <label class="control-label" for="discount_value">@lang('strings.Discount')</label>
                                <input type="number" class="form-control" name="discount_value" value="{{  $list->discount_value }}" id="discount_value">
                                @if ($errors->has('discount_value'))
                                    <span class="help-block">
                                        <strong class="text-danger">{{ $errors->first('discount_value') }}</strong>
                                    </span>
                                @endif
                            </div>


                            <div class="col-md-6 form-group{{$errors->has('date_from') ? ' has-error' : ''}}">
                                <label class="control-label" for="date_from">@lang('strings.Date_fromm')</label>
                                <input type="date" class="form-control" name="date_from" value="{{ $list->date_from }}">
                                @if ($errors->has('date_from'))
                                    <span class="help-block">
                                        <strong class="text-danger">{{ $errors->first('date_from') }}</strong>
                                    </span>
                                @endif
                            </div>


                            <div class="col-md-6 form-group{{$errors->has('date_to') ? ' has-error' : ''}}">
                                <label class="control-label" for="date_to">@lang('strings.Date_too')</label>
                                <input type="date" class="form-control" name="date_to" value="{{ $list->date_to }}">
                                @if ($errors->has('date_to'))
                                    <span class="help-block">
                                        <strong class="text-danger">{{ $errors->first('date_to') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="col-md-6 form-group{{$errors->has('active') ? ' has-error' : ''}}"> <strong class="text-danger">*</strong>
                                <label class="control-label" for="active">@lang('strings.Status')</label>
                                <select class="form-control" name="active">
                                    <option {{ $list->active == 1 ? 'selected' : '' }} value="1">@lang('strings.Active')</option>
                                    <option {{ $list->active == 0 ? 'selected' : '' }} value="0">@lang('strings.Deactivate')</option>
                                </select>
                                @if ($errors->has('active'))
                                    <span class="help-block">
                                        <strong class="text-danger">{{ $errors->first('active') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="col-md-6 form-group{{$errors->has('infrontpage') ? ' has-error' : ''}}">
                                <label class="control-label" for="infrontpage">@lang('strings.Infrontpage')</label>
                                <input type="checkbox" name="infrontpage" {{ $list->infrontpage == 1 ? 'checked' : '' }}>
                            </div>

                            <input type="hidden" id="org-price" value="{{ $list->orig_price }}">
                            <input type="hidden" id="org-tax" value="{{ $list->tax != null ? $list->tax : 0  }}">
                            <div class="col-md-12">
                                <h2>@lang('strings.Total')</h2>

                                <ul style="list-style-type:disc" id="clac">
                                    <li id="tax">@lang('strings.original_price')  : {{ $list->orig_price != null ? $list->orig_price : 0 }} </li>
                                    <li id="tax">@lang('strings.Tax_value') : {{ $list->tax != null ? $list->tax : 0 }} </li>
                                    <li id="discount"> @lang('strings.Discount_value')  : {{ $list->discount_value }}</li>
                                    <li id="discount-price">@lang('strings.Discount_price')  : {{ $list->discount_price }}</li>
                                    <li id="offer-price"> @lang('strings.Offer_price') : {{ $list->offer_price }}</li>
                                </ul>
                            </div>

                            <div class="col-md-12">
                                <div class="col-md-11"></div>
                                <div class="form-group col-md-1">
                                    <button type="submit" class="btn btn-primary btn-lg">@lang('strings.Save')</button>
                                </div>
                            </div>


                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection
@section('scripts')
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.7/js/select2.min.js"></script>
    <script>
        $("#discount_type").change(function () {
            if(this.value == 1 || this.value == 2) {
                $("#discountsss").show();
            }else{
                $("#discountsss").hide();
            }
        });
        $("#discount_value").change(function () {
            if(parseInt($('#org-tax').val()) <= 100){
                var tax = parseFloat($('#org-tax').val()) / 100 * (parseFloat($('#org-price').val()) - parseFloat($('#discount_value').val()) / 100 * parseFloat($('#org-price').val()));
            }else{
                var tax = parseFloat($('#org-tax').val());
            }
            if($("#discount_type").val() == 1){
                $("#discount").html("<li>@lang('strings.Discount')  : % " +  parseFloat($('#discount_value').val()) + "</li>");
                $("#discount-price").html("<li>@lang('strings.Discount_price')  :" +  (parseFloat($('#org-price').val()) - parseFloat($('#discount_value').val()) / 100 * parseFloat($('#org-price').val()))  + "</li>");
                $("#offer-price").html("<li>@lang('strings.Offer_price')  :" +  ((parseFloat($('#org-price').val()) - parseFloat($('#discount_value').val()) / 100 * parseFloat($('#org-price').val()))  +  tax) + "</li>");

            }else{
                $("#discount").html("<li>@lang('strings.Discount')  :" +  parseFloat($('#discount_value').val()) + "</li>");
                $("#discount-price").html("<li>@lang('strings.Discount_price')  :" +  (parseFloat($('#org-price').val()) - parseFloat($('#discount_value').val()))  + "</li>");
                $("#offer-price").html("<li>@lang('strings.Offer_price')  :" +  ((parseFloat($('#org-price').val()) - parseFloat($('#discount_value').val())) +  tax) + "</li>");
            }

        });


    </script>
@endsection
@extends('layouts.admin', ['title' => __('strings.Price_list') ])

@section('content')

    <div class="page-title">
        <h3> @lang('strings.Offers_list') </h3>
        <div class="page-breadcrumb">
            <ol class="breadcrumb">
                <li><a href="{{ route('home') }}">@lang('strings.Home')</a></li>
                <li class="active">@lang('strings.Offers_list')</li>
            </ol>
        </div>
    </div>

    <div id="main-wrapper">
        <div class="row">
            <div class="col-md-12">
                @include('alerts.index')
                <a class="btn btn-primary btn-lg btn-add" href="{{ route('offers.create') }}" ><i class="fa fa-plus"></i>&nbsp;&nbsp;@lang('strings.Offers_list_add')</a>
                <div role="tabpanel">
                    <div class="panel panel-white">
                        <div class="panel-heading clearfix">
                            <h4 class="panel-title">@lang('strings.Offers_list')</h4>
                        </div>
                        <div class="panel-body">

                            <table id="xtreme-table" class="display table" style="width: 100%; cellspacing: 0;">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>@lang('strings.Item_name')</th>
                                    <th>@lang('strings.Offer_price')</th>
                                    <th>@lang('strings.Date_fromm')</th>
                                    <th>@lang('strings.Date_too')</th>
                                    <th>@lang('strings.Status')</th>
                                    <th>@lang('strings.Settings')</th>
                                </tr>
                                </thead>
                                <tbody>
                                @foreach($list as $value)
                                    <tr>
                                        <td>{{ $value->id }}</td>
                                        <td>{{ app()->getLocale() == 'ar' ? $value->name : $value->name_en }}</td>
                                        <td>{{ round($value->offer_price, 2) }}</td>
                                        <td>{{ $value->date_from }}</td>
                                        <td>{{ $value->date_to }}</td>
                                        <td>
                                            @if($value->active)
                                                <span class="label label-success" style="font-size:12px;">{{ __('strings.Active') }}</span>
                                            @else
                                                <span class="label label-danger" style="font-size:12px;">{{ __('strings.Deactivate') }}</span>
                                            @endif
                                        </td>
                                        <td>
                                            <a href="{{ route('offers.edit', $value->id) }}" class="btn btn-primary btn-xs" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="تعديل" ><i class="fa fa-pencil"></i></a>
                                            {{--<a class="btn btn-danger btn-xs" data-toggle="modal" data-target="#{{ $value->id }}"><i class="fa fa-trash-o"></i></a>--}}
                                            <!-- Category Delete Modal -->
                                            <div id="{{ $value->id }}" class="modal fade" role="dialog" data-keyboard="false" data-backdrop="static">
                                                <div class="modal-dialog">
                                                    <!-- Modal content-->
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                            <h4 class="modal-title">{{ __('backend.confirm') }}</h4>
                                                        </div>
                                                        <div class="modal-body">
                                                            <p>{{ __('backend.delete_category_message') }}</p>
                                                        </div>
                                                        <form method="post" action="{{ route('offers.destroy', $value->id) }}">
                                                            <div class="modal-footer">
                                                                {{csrf_field()}}
                                                                {{ method_field('DELETE') }}
                                                                <button type="submit" class="btn btn-danger">{{ __('backend.delete_btn') }}</button>
                                                                <button type="button" class="btn btn-primary" data-dismiss="modal">{{ __('backend.no') }}</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                            {{ $list->links() }}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection